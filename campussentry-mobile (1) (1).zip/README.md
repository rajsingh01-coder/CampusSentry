# CampusSentry Staff (React Native + Expo, Android)

Frontend-only staff/security app that mirrors the **CampusSentry Admin Web App**. The backend is not included: the backend
developer implements `docs/BACKEND_CONTRACT.md`, and the app talks to it through `src/services`.

## Run it
```bash
npm install
npx expo install --fix      # aligns every Expo package to your SDK version (package.json uses "*" placeholders)
npx expo start              # then press "a" for an Android emulator, or scan the QR code in Expo Go
```
`.env` ships with `EXPO_PUBLIC_DEMO_MODE=true`: the app runs on an in-app fake backend with invented data and a red
**DEMO MODE** banner. Demo accounts (password `demo1234`): `SEC-101` Security/Staff, `SUP-201` Supervisor, `ADM-001` Admin.
Demo OTP code: `123456` (5 wrong codes lock for 30 s). Camera identification cycles Known / Unknown / Verification Required.
The camera needs a real device or an emulator with a camera.

## Connect the real backend
1. Set `EXPO_PUBLIC_DEMO_MODE=false` and `EXPO_PUBLIC_API_BASE_URL=https://...` in `.env`.
2. Adjust paths in `src/services/endpoints.ts` and field names in `src/services/parsers*.ts` to the real API.
3. Run `npm test` (the demo tests double as an executable contract).

## Screens
Tabs: **Home** (summary, recent activity), **Identify** (camera -> Known / Unknown / Verification Required),
**Register** (visit request, admin fields), **Records** (search + filters, visitor detail, check-in/out), **Profile** (theme, sign out).
Other: Requests (list, detail, review for permitted roles), OTP, Notifications, AI assistant.

## Principles
- No fabricated data or success states: every success shown comes from a backend response; lists never invent rows.
- "Unknown" is neutral. An AI match never authorizes access.
- Actions follow permissions from the server (`user.permissions`), with role defaults only as a flagged fallback.
- Tokens in SecureStore; theme preference in AsyncStorage; sensitive screens block screenshots (Android); captured photos are deleted right after upload.
- Light / Dark / System theme, persisted, no flash (splash stays until theme and session are known).

## Checks available without installing dependencies
`npm test` (39 unit tests: domain rules, parsers, demo backend contract), `npm run syntax`, `npm run typecheck:pure`.
Full `npm run typecheck` needs the installed Expo/React Native types.

## Honest status
Written and checked in a sandbox that could not install npm packages, so the app has **not been run** on a device or emulator
and full TypeScript checking against React Native types has **not** been done. Expect small first-run fixes (package versions,
a typing issue or two). Backend routes are proposed, not confirmed (see contract doc).

## Layout
`src/domain` pure rules + types (tested) · `src/services` typed API client, parsers, one service per area · `src/demo` fake backend ·
`src/features` auth, config, identification · `src/components` UI kit · `src/app` expo-router screens · `src/theme` tokens.
