# How the staff app follows the Admin Web App

Source reviewed: the supplied `admin.zip` (Next.js 15, Zustand, localStorage; frontend-only demo with no REST API).
The admin is the source of truth for vocabulary, rules and look. Where it differed from the original requirements document, the admin won.

| Topic | Admin web app | Staff app |
|---|---|---|
| Visitor categories | 8 (Student ... Not specified), from Settings | same 8, from `GET /api/config`, admin defaults as fallback |
| Request status | 7 values, separate from identity | same 7, `StatusBadge` colours copied from `badge-status.tsx` |
| Identity | Known / Unknown / Verification Required, set by staff at submission; "Unknown" never implies malicious intent | same; neutral badge and explanatory text; Registration has a classification field |
| OTP | only Guest/External Visitor when `requireOtpForGuests`; starts at Pending Verification; success -> Pending Approval; failed stays | `domain/workflow.ts` ports these rules; OTP screen succeeds only on server `{verified:true}` |
| Review | Admin approves/rejects/asks for info; terminal decisions can't be reversed; rejection needs a reason | review UI shown only with `request.review`, same guards, reason required |
| Check-in / out | by visitorId; needs Approved and not Inside; re-entry after Exited allowed; check-out needs Inside | `domain/presence.ts` (differs from the original spec, which blocked re-entry) |
| Notifications | `StaffNotification`, mark read / mark all read / archive | list + mark read + mark all (archive is admin-only) |
| Pagination | `{data,total,page,pageSize,totalPages}` | same, page-number based |
| Date ranges | Monday-start week, local day | `getLocalDateRange` |
| Design tokens | CSS variables (light + dark), radius 16 card / 10 control, shield brand mark | `theme/colors.ts`, `theme/spacing.ts`, `BrandMark` |

## Not taken from the admin (and why)
- **Routes / auth / permissions**: the admin has none (client-side demo). Proposed in `BACKEND_CONTRACT.md`.
- **Simulated gate scanner / AI confidence**: the admin fakes these. The app shows a confidence number only if the server sends one, labelled "indicative".
- **Approving from the phone for gate staff**: the admin README treats approval as an admin workflow, so it is permission-gated.
