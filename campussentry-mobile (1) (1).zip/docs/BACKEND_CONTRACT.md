# Backend contract (for the backend developer)

**Status: PROPOSED.** The Admin Web App is a frontend-only demo (Zustand + localStorage). It has no REST API, so there were no
real routes to copy. What *is* fixed is the admin's **data model and business rules** (`admin/src/types/index.ts`,
`src/lib/workflow.ts`, `src/store/demo-store.ts`); this document maps them to HTTP so the mobile app can call them.

You can change any path in one file: `src/services/endpoints.ts`. Field names are parsed in `src/services/parsers*.ts`
(hand-written; anything that doesn't match is rejected, never guessed). The in-app demo backend
(`src/demo/demo-backend.ts`) is a working reference implementation of everything below, and `src/demo/__tests__` shows the
exact request/response pairs.

## Conventions
- JSON, `Authorization: Bearer <accessToken>` on everything except login. Optional `Idempotency-Key` header on create/decision/check-in/out (only sent if `EXPO_PUBLIC_SEND_IDEMPOTENCY_KEY=true`).
- Errors: HTTP status + `{ "message": string, "code"?: string, "retryAfterSeconds"?: number }`. `message` is shown to the user.
  `400/422` validation, `401` session invalid (app signs out), `403` not permitted, `404`, `409` state conflict, `429` rate limit.
- Lists use the admin `PaginatedResult`: `{ "data": T[], "total", "page" (1-based), "pageSize", "totalPages" }`, query `?page=&pageSize=`.
- Timestamps ISO-8601 UTC. `requestedDate` is `YYYY-MM-DD`, `requestedTime` is `HH:mm` or `"Now"`.
- **The server is the authority.** The app hides actions it thinks are not allowed, but every rule below must be enforced server-side.

## Enums (exact strings, from the admin)
| Name | Values |
|---|---|
| visitorCategory | Student, Parent/Guardian, Guest/External Visitor, Teaching Staff, Non-Teaching Staff, Vendor, Other, Not specified |
| identityClassification | Known, Unknown, Verification Required (`Unknown` is neutral, never "dangerous") |
| requestStatus | Pending Verification, Pending Approval, Approved, Rejected, Cancelled, Expired, Additional Information Required |
| otpStatus | Verified, Pending, Failed, Not Applicable |
| visitMode | Walk-in, Scheduled |
| presence | Inside Campus, Exited, Not Checked In |
| priority | Normal, High, Urgent |
| role | Admin, Security/Staff, Supervisor |
| permission | request.create, request.review, visitor.checkin, visitor.checkout, visitor.search_phone, history.view |

## Routes
| Route | Notes |
|---|---|
| `POST /api/auth/login` | body `{identifier, password}` -> `{accessToken, refreshToken?, user}`. `user`: `{staffId, name, email?, department?, role, assignedGate?, permissions?: Permission[]}`. If `permissions` is omitted the app falls back to role defaults (`src/domain/role-permissions.ts`, **please confirm**). Wrong credentials: `401`. |
| `POST /api/auth/logout` | optional revoke |
| `GET /api/me` | same `user` object. Called at app start to refresh permissions. `401` signs the user out. |
| `GET /api/config` | `{visitorCategories: string[], authorizedMeetingAuthorities: string[], requireOtpForGuests: boolean, gates: string[]}` = admin "System Settings". Missing -> app uses admin defaults and says so. |
| `GET /api/dashboard` | `{totalToday, insideNow, pendingApproval, recent: [{id, visitorName, kind: check_in\|check_out\|registered\|status_changed, at, requestStatus?}]}` |
| `GET /api/requests` | query `status, q, classification, page, pageSize` -> page of `{requestId, visitorId?, visitorName, visitorCategory, identityClassification, requestStatus, otpStatus, createdAt, personToMeet?, priority?}` |
| `POST /api/requests` | body = admin `SimulateRequestInput`: `{visitorName, phoneNumber?, visitorCategory, identityClassification, personToMeet, department?, reasonForMeeting, visitMode, requestedDate?, requestedTime, appointmentDetails?, submittingStaffId, gateOrLocation, staffNotes?}` -> `201 {requestId, visitorId?, requestStatus, otpStatus}`. **Server issues `requestId` and decides status.** Rule: OTP required only if `visitorCategory = Guest/External Visitor` and `requireOtpForGuests` -> `Pending Verification` + otp `Pending` (phone mandatory, else 422); otherwise `Pending Approval` + `Not Applicable`. Admin auto-sets `Known` when the name matches a registered identity; the server may override `identityClassification`. |
| `GET /api/requests/:requestId` | summary fields + `phoneNumber?, department?, reasonForMeeting, visitMode?, requestedDate?, requestedTime?, appointmentDetails?, gateOrLocation?, submittedBy?, staffNotes?, presence?, reviews: [{decision, by?, at?, notes?}]`. Review `notes` should only be sent to users with `request.review`. |
| `POST /api/requests/:requestId/decision` | body `{decision: Approved\|Rejected\|Additional Information Required, notes?}`. Requires `request.review`. Only `Pending Approval` / `Additional Information Required` are reviewable, terminal decisions can't be reversed (`409`). `Rejected` needs `notes` (`422`). |
| `POST /api/requests/:requestId/otp/verify` | body `{code}`. Allowed only when status `Pending Verification` and otp `Pending`/`Failed` (else `409`). Success `200 {verified: true, requestStatus}` and the request moves to `Pending Approval`. Wrong code: `400` with `code: "otp_incorrect"` (otp -> `Failed`, stays `Pending Verification`). Expired: `code: "otp_expired"`. Too many tries: `429` + `retryAfterSeconds`. The app treats **only** `{verified:true}` as success. |
| `POST /api/requests/:requestId/otp/resend` | `200`; `429` when throttled |
| `GET /api/visitors` | query `q, field (name\|phone\|id), category, classification, status, presence, from, to, page, pageSize`. Searching `field=phone` requires `visitor.search_phone` (`403`). Row: `{visitorId, visitorName, phoneNumber?, visitorCategory, identityClassification, latestRequestId?, requestStatus?, presence?, lastActivityAt?}` |
| `GET /api/visitors/:visitorId` | row + `requests: [request summary]` |
| `POST /api/visitors/:visitorId/check-in` | body `{gate}`. Allowed only if the latest request is `Approved` and presence is not `Inside Campus` (re-entry after `Exited` is allowed). Else `409` with a readable `message`. Requires `visitor.checkin`. Log source should be "Staff Mobile". |
| `POST /api/visitors/:visitorId/check-out` | body `{gate}`. Allowed only when `Inside Campus` (`409` otherwise). Requires `visitor.checkout`. |
| `GET /api/visitors/:visitorId/history` | requires `history.view`. page of `{id, kind: check_in\|check_out, at, gate?, staffName?, source?}` |
| `GET /api/notifications` | page of admin `StaffNotification`: `{id, requestId, visitorName, visitorCategory?, identityClassification?, personToMeet?, reasonForMeeting?, requestStatus?, otpStatus?, priority, createdAt, isRead}` |
| `POST /api/notifications/:notificationId/read`, `POST /api/notifications/read-all` | mark read |
| `POST /api/recognition` | multipart field `image` (JPEG) -> `{classification: Known\|Unknown\|Verification Required, sessionId?, match?: {visitorId?, name?, photoUrl?, confidence? (0..1)}}`. The app deletes its local copy of the photo right after the call. **Do not retain the image unless your privacy policy allows it.** A result never authorizes entry; it only prefills a visit request. |
| `POST /api/assistant/chat` | body `{message, conversationId?}` -> `{conversationId?, reply, proposal?: {id, title, description}}` |
| `POST /api/assistant/confirm` | body `{proposalId, conversationId?}` -> `{reply}`. Anything that changes data must happen only here, with the caller's own permissions. |

## Open questions for the backend / admin owner
1. Real route paths and auth scheme (bearer assumed). Refresh-token flow is not implemented: a `401` signs the user out.
2. Permission list per role (defaults in `role-permissions.ts` are least-privilege guesses; the admin only enforces roles client-side).
3. Phone number rule (digits 10-15, `+91` accepted, configurable by env).
4. OTP: length (4-8 digits accepted), expiry, delivery channel, lockout policy (the demo uses 5 tries / 30 s).
5. Is the face-recognition service part of this backend? Retention policy for photos and embeddings?
6. Should staff be able to review requests from mobile? The admin README makes approval an admin workflow, so the app only shows approve/reject to users with `request.review`.
