// Syntax-only check (no type information: React Native types are not installed in every environment).
const ts = require(process.env.TS_PATH || 'typescript');
const fs = require('fs'); const path = require('path');
let bad = 0, n = 0;
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    if (['node_modules', '.expo', 'dist', 'scripts'].includes(e.name)) continue;
    const p = path.join(d, e.name);
    if (e.isDirectory()) walk(p);
    else if (/\.(ts|tsx)$/.test(e.name)) {
      n++;
      const out = ts.transpileModule(fs.readFileSync(p, 'utf8'), { fileName: p, reportDiagnostics: true,
        compilerOptions: { jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext, allowImportingTsExtensions: true } });
      for (const dgn of out.diagnostics || []) { bad++; console.log(p + ': ' + ts.flattenDiagnosticMessageText(dgn.messageText, '\n')); }
    }
  }
})('.');
console.log(`${n} files checked, ${bad} syntax errors`);
process.exit(bad ? 1 : 0);
