#!/bin/sh
# Strict typecheck of framework-free modules (no React Native types needed).
cd "$(dirname "$0")/.." && cat > /tmp/tsconfig.pure.json <<JSON
{ "compilerOptions": { "strict": true, "noUncheckedIndexedAccess": true, "allowImportingTsExtensions": true, "noEmit": true, "target": "ES2022", "module": "ESNext", "moduleResolution": "Bundler", "lib": ["ES2022", "DOM"], "skipLibCheck": true, "types": [] },
  "files": ["$PWD/src/domain/validation.ts","$PWD/src/domain/otp.ts","$PWD/src/domain/presence.ts","$PWD/src/domain/recognition.ts","$PWD/src/domain/records-filters.ts","$PWD/src/domain/pagination.ts","$PWD/src/domain/permissions.ts","$PWD/src/services/parsers.ts","$PWD/src/services/parsers-ops.ts","$PWD/src/demo/demo-backend.ts","$PWD/scripts/process.d.ts"] }
JSON
tsc -p /tmp/tsconfig.pure.json
