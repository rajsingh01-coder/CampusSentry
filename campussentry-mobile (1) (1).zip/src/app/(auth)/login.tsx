import React, { useRef, useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import { BrandMark } from '../../components/ui/BrandMark';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { FormField } from '../../components/ui/FormField';
import { Screen } from '../../components/ui/Screen';
import { DEMO_ACCOUNTS, DEMO_PASSWORD } from '../../demo/demo-backend';
import { useAuth } from '../../features/auth/AuthProvider';
import { ApiError, describeError } from '../../services/errors';
import { DEMO_MODE } from '../../services/endpoints';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export default function Login() {
  const { colors } = useTheme();
  const { signIn, notice } = useAuth();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pwRef = useRef<TextInput>(null);

  async function submit(id = identifier, pw = password) {
    if (busy) return;
    if (!id.trim() || !pw) { setError('Enter your staff ID (or email) and password.'); return; }
    setBusy(true); setError(null);
    try { await signIn(id, pw); } // on success the root gate navigates away
    catch (e) { setError(e instanceof ApiError && e.kind === 'unauthorized' ? e.message : describeError(e).detail); setBusy(false); }
  }

  return (
    <Screen>
      <View style={{ gap: spacing.xl, paddingTop: spacing.xl }}>
        <BrandMark size={52} />
        <View style={{ gap: spacing.xs }}>
          <Text accessibilityRole="header" style={[t.screenTitle, { color: colors.text }]}>Staff sign in</Text>
          <Text style={[t.body, { color: colors.textSecondary }]}>Gate and security staff only.</Text>
        </View>
        {notice ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.warning.fg }]}>{notice}</Text> : null}
        <FormField label="Staff ID or email" value={identifier} onChangeText={setIdentifier} autoCapitalize="none" autoCorrect={false} textContentType="username" returnKeyType="next" onSubmitEditing={() => pwRef.current?.focus()} />
        <FormField ref={pwRef} label="Password" value={password} onChangeText={setPassword} secureToggle autoCapitalize="none" textContentType="password" returnKeyType="go" onSubmitEditing={() => { void submit(); }} error={error ?? undefined} />
        <PrimaryButton label="Sign in" onPress={() => { void submit(); }} loading={busy} />
        {DEMO_MODE ? (
          <View style={{ gap: spacing.sm }}>
            <Text style={[t.support, { color: colors.textSecondary }]}>Demo accounts (password {DEMO_PASSWORD}):</Text>
            {DEMO_ACCOUNTS.map((a) => <SecondaryButton key={a.identifier} label={`${a.label} (${a.identifier})`} disabled={busy} onPress={() => { setIdentifier(a.identifier); setPassword(DEMO_PASSWORD); void submit(a.identifier, DEMO_PASSWORD); }} />)}
          </View>
        ) : null}
      </View>
    </Screen>
  );
}
