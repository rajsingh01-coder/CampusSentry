import { IdentifyFlow } from '../../features/identification/IdentifyFlow';
export default function Identify() { return <IdentifyFlow />; }
