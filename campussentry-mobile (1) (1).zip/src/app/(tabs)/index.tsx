import { useRouter } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ActivityItem } from '../../components/visitors/ActivityItem';
import { AppHeader } from '../../components/ui/AppHeader';
import { Card } from '../../components/ui/Card';
import { EmptyState, ErrorState, LoadingView } from '../../components/ui/States';
import { Screen } from '../../components/ui/Screen';
import { SecondaryButton } from '../../components/ui/Buttons';
import { can } from '../../domain/permissions';
import { useStaff } from '../../features/auth/AuthProvider';
import { useAsync } from '../../hooks/useAsync';
import { usePollWhileFocused } from '../../hooks/usePollWhileFocused';
import { visitorService } from '../../services/visitor.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

function Metric({ label, value }: { label: string; value: number }) {
  const { colors } = useTheme();
  return (
    <Card style={styles.metric}>
      <Text accessibilityLabel={`${label}: ${value}`} style={[t.metric, { color: colors.text }]}>{value}</Text>
      <Text style={[t.support, { color: colors.textSecondary }]}>{label}</Text>
    </Card>
  );
}

export default function Home() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const dash = useAsync((signal) => visitorService.getDashboard(signal));
  usePollWhileFocused(dash.silent, 30000, true);
  const d = dash.data;

  return (
    <Screen refreshing={dash.refreshing} onRefresh={dash.refresh}>
      <AppHeader title="Home" actions={[{ icon: 'notifications-outline', label: 'Notifications', onPress: () => router.push('/notifications') }]} />
      <View style={{ gap: 2 }}>
        <Text style={[t.sectionTitle, { color: colors.text }]}>Hello, {user.name}</Text>
        <Text style={[t.support, { color: colors.textSecondary }]}>{[user.assignedGate, user.role].filter(Boolean).join(' • ')}</Text>
      </View>

      {dash.loading && !d ? <LoadingView label="Loading today’s summary" /> : null}
      {dash.error && !d ? <ErrorState error={dash.error} onRetry={dash.reload} /> : null}
      {d ? (
        <>
          <View style={styles.metrics}>
            <Metric label="Requests today" value={d.totalToday} />
            <Metric label="Inside campus" value={d.insideNow} />
            <Metric label="Awaiting approval" value={d.pendingApproval} />
          </View>
          <View style={{ gap: spacing.sm }}>
            <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Recent activity</Text>
            <Card>
              {d.recent.length === 0 ? <EmptyState icon="time-outline" title="No activity yet today" /> : d.recent.map((a) => <ActivityItem key={a.id} item={a} />)}
            </Card>
          </View>
        </>
      ) : null}

      <View style={{ gap: spacing.sm }}>
        <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Quick actions</Text>
        <SecondaryButton label="Identify a visitor" icon="scan-outline" onPress={() => router.push('/(tabs)/identify')} />
        {can(user, 'request.create') ? <SecondaryButton label="Register a visitor" icon="person-add-outline" onPress={() => router.push('/(tabs)/register')} /> : null}
        <SecondaryButton label="Visit requests" icon="documents-outline" onPress={() => router.push('/requests')} />
        <SecondaryButton label="AI assistant" icon="sparkles-outline" onPress={() => router.push('/assistant')} />
      </View>
    </Screen>
  );
}
const styles = StyleSheet.create({ metrics: { flexDirection: 'row', gap: spacing.sm }, metric: { flex: 1, padding: spacing.md, gap: 2 } });
