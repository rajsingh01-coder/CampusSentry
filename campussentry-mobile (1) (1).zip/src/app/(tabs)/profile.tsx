import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { BrandMark } from '../../components/ui/BrandMark';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { ConfirmationSheet } from '../../components/ui/ConfirmationSheet';
import { InfoRow } from '../../components/ui/InfoRow';
import { Screen } from '../../components/ui/Screen';
import { SegmentedControl } from '../../components/ui/SegmentedControl';
import { useAuth, useStaff } from '../../features/auth/AuthProvider';
import { spacing } from '../../theme/spacing';
import { useTheme, type ThemePreference } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export default function Profile() {
  const { colors, preference, setPreference } = useTheme();
  const { signOut } = useAuth();
  const user = useStaff();
  const router = useRouter();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);

  return (
    <Screen>
      <AppHeader title="Profile" />
      <Card>
        <Text style={[t.sectionTitle, { color: colors.text }]}>{user.name}</Text>
        <InfoRow label="Role" value={user.role} />
        <InfoRow label="Staff ID" value={user.staffId} />
        <InfoRow label="Department" value={user.department} />
        <InfoRow label="Assigned gate" value={user.assignedGate} />
        <InfoRow label="Email" value={user.email} />
        {user.permissionSource === 'role-default' ? <Text style={[t.support, { color: colors.textSecondary }]}>Permissions are the app’s defaults for your role until the server sends an explicit list.</Text> : null}
      </Card>
      <View style={{ gap: spacing.sm }}>
        <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Appearance</Text>
        <SegmentedControl<ThemePreference> label="Theme" value={preference} onChange={setPreference} options={[{ value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }, { value: 'system', label: 'System' }]} />
      </View>
      <SecondaryButton label="Notifications" icon="notifications-outline" onPress={() => router.push('/notifications')} />
      <PrimaryButton label="Sign out" icon="log-out-outline" onPress={() => setConfirm(true)} />
      <ConfirmationSheet visible={confirm} title="Sign out?" message="You will need your staff ID and password to sign in again." confirmLabel="Sign out" busy={busy}
        onCancel={() => setConfirm(false)} onConfirm={() => { setBusy(true); void signOut(); }} />
      <View style={{ alignItems: 'center', paddingTop: spacing.lg }}><BrandMark size={28} /></View>
    </Screen>
  );
}
