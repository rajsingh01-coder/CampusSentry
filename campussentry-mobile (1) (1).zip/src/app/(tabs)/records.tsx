import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { SecondaryButton } from '../../components/ui/Buttons';
import { Chips } from '../../components/ui/Chips';
import { FormField } from '../../components/ui/FormField';
import { EmptyState, ErrorState, LoadingView } from '../../components/ui/States';
import { VisitorCard } from '../../components/visitors/VisitorCard';
import { can } from '../../domain/permissions';
import { DEFAULT_FILTERS, filtersAreDefault, type RecordFilters, type RecordSearchField } from '../../domain/records-filters';
import { IDENTITY_CLASSIFICATIONS, PRESENCE_STATES, REQUEST_STATUSES, VISITOR_CATEGORIES } from '../../domain/types';
import { maskPhone } from '../../domain/validation';
import type { DatePeriod } from '../../domain/workflow';
import { useStaff } from '../../features/auth/AuthProvider';
import { useDebounced } from '../../hooks/useDebounced';
import { usePagedList } from '../../hooks/usePagedList';
import type { VisitorRecord } from '../../services/parsers-ops';
import { visitorService } from '../../services/visitor.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

const all = <T extends string>(l: readonly T[]) => [{ value: null as T | null, label: 'All' }, ...l.map((v) => ({ value: v as T | null, label: v }))];
const PERIODS: { value: DatePeriod; label: string }[] = [{ value: 'all', label: 'All time' }, { value: 'today', label: 'Today' }, { value: 'week', label: 'This week' }, { value: 'month', label: 'This month' }];

export default function Records() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const [filters, setFilters] = useState<RecordFilters>(DEFAULT_FILTERS);
  const [showFilters, setShowFilters] = useState(false);
  const canPhone = can(user, 'visitor.search_phone');
  const debounced = useDebounced(filters.query, 350);
  const effective = useMemo(() => ({ ...filters, query: debounced }), [filters, debounced]);
  const key = JSON.stringify(effective);
  const list = usePagedList<VisitorRecord>((page, signal) => visitorService.search(effective, page, signal), (v) => v.visitorId, key);
  const set = <K extends keyof RecordFilters>(k: K, v: RecordFilters[K]) => setFilters((f) => ({ ...f, [k]: v }));
  const fields: { value: RecordSearchField; label: string }[] = [{ value: 'name', label: 'Name' }, { value: 'id', label: 'ID' }, ...(canPhone ? [{ value: 'phone' as const, label: 'Phone' }] : [])];

  const header = (
    <View style={{ gap: spacing.md, paddingBottom: spacing.md }}>
      <AppHeader title="Records" />
      <FormField label="Search" value={filters.query} onChangeText={(v) => set('query', v)} placeholder={filters.field === 'phone' ? 'Mobile number' : filters.field === 'id' ? 'Visitor or request ID' : 'Visitor name'} autoCapitalize="none" returnKeyType="search" />
      <Chips<RecordSearchField> label="Search by" options={fields} value={filters.field} onChange={(v) => v && set('field', v)} />
      <SecondaryButton label={showFilters ? 'Hide filters' : 'Filters'} icon="options-outline" onPress={() => setShowFilters((s) => !s)} />
      {showFilters ? (
        <View style={{ gap: spacing.md }}>
          <Chips label="Category" options={all(VISITOR_CATEGORIES)} value={filters.category} onChange={(v) => set('category', v)} />
          <Chips label="Identity" options={all(IDENTITY_CLASSIFICATIONS)} value={filters.classification} onChange={(v) => set('classification', v)} />
          <Chips label="Request status" options={all(REQUEST_STATUSES)} value={filters.status} onChange={(v) => set('status', v)} />
          <Chips label="Presence" options={all(PRESENCE_STATES)} value={filters.presence} onChange={(v) => set('presence', v)} />
          <Chips<DatePeriod> label="Period" options={PERIODS} value={filters.period} onChange={(v) => set('period', v ?? 'all')} />
        </View>
      ) : null}
      {!filtersAreDefault(filters) ? <SecondaryButton label="Clear search and filters" icon="close-circle-outline" onPress={() => setFilters(DEFAULT_FILTERS)} /> : null}
      {!list.loading && !list.error ? <Text style={[t.support, { color: colors.textSecondary }]}>{list.total} record{list.total === 1 ? '' : 's'}</Text> : null}
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, paddingTop: 48, paddingHorizontal: spacing.lg }}>
      <FlatList
        data={list.items} keyExtractor={(v) => v.visitorId} ListHeaderComponent={header} keyboardShouldPersistTaps="handled"
        refreshing={list.refreshing} onRefresh={list.refresh} onEndReached={list.loadMore} onEndReachedThreshold={0.4}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        renderItem={({ item }) => (
          <VisitorCard name={item.visitorName} category={item.visitorCategory} classification={item.identityClassification} status={item.requestStatus} presence={item.presence}
            subtitle={item.phoneNumber ? (canPhone ? item.phoneNumber : maskPhone(item.phoneNumber)) : undefined}
            onPress={() => router.push({ pathname: '/visitors/[visitorId]', params: { visitorId: item.visitorId } })} />
        )}
        ListEmptyComponent={list.loading ? <LoadingView label="Loading records" /> : list.error ? <ErrorState error={list.error} onRetry={list.reload} /> : <EmptyState icon="search-outline" title="No records found" detail={filtersAreDefault(filters) ? 'Registered visitors will appear here.' : 'Try a different search or clear the filters.'} />}
        ListFooterComponent={list.loadingMore ? <ActivityIndicator color={colors.primary} style={{ margin: spacing.lg }} /> : list.loadMoreError ? <ErrorState error={list.loadMoreError} onRetry={list.loadMore} /> : <View style={{ height: spacing.xxl }} />}
      />
    </View>
  );
}
