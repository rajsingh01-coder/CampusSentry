import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { FormField } from '../../components/ui/FormField';
import { Screen } from '../../components/ui/Screen';
import { SelectField } from '../../components/ui/SelectField';
import { OtpBadge, StatusBadge } from '../../components/ui/StatusBadge';
import { EmptyState } from '../../components/ui/States';
import { can } from '../../domain/permissions';
import { CONFIRM_MATCH_NOTICE } from '../../domain/recognition';
import { IDENTITY_CLASSIFICATIONS, VISIT_MODES, type IdentityClassification, type VisitorCategory } from '../../domain/types';
import { hasErrors, validateRegistration, type RegistrationErrors, type RegistrationInput } from '../../domain/validation';
import { canVerifyOtp, getLocalDateInputValue, requiresOtp } from '../../domain/workflow';
import { useStaff } from '../../features/auth/AuthProvider';
import { useAppConfig } from '../../features/config/ConfigProvider';
import { config } from '../../services/config';
import { describeError, ApiError } from '../../services/errors';
import type { CreatedRequest } from '../../services/parsers';
import { requestsService } from '../../services/requests.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { newKey } from '../../utils/ids';

const blank = (gate: string, classification: IdentityClassification = 'Unknown', name = ''): RegistrationInput => ({
  fullName: name, phone: '', category: null, classification, personToMeet: '', department: '', reason: '', visitMode: 'Walk-in',
  requestedDate: getLocalDateInputValue(), requestedTime: '', appointmentDetails: '', gate, staffNotes: '',
});

export default function Register() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const cfg = useAppConfig();
  const params = useLocalSearchParams<{ name?: string; classification?: string }>();
  const fromIdentify = IDENTITY_CLASSIFICATIONS.find((c) => c === params.classification);
  const [form, setForm] = useState<RegistrationInput>(() => blank(user.assignedGate ?? '', fromIdentify, params.name ?? ''));
  const [errors, setErrors] = useState<RegistrationErrors>({});
  const [busy, setBusy] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [created, setCreated] = useState<CreatedRequest | null>(null);
  const key = useRef(newKey()); // one logical submission: reused on retry, regenerated after success

  // Prefill from the Identify flow (screen stays mounted in tabs, so react to param changes).
  useEffect(() => {
    if (params.name || fromIdentify) setForm((f) => ({ ...f, fullName: params.name ?? f.fullName, classification: fromIdentify ?? f.classification }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.name, params.classification]);

  if (!can(user, 'request.create')) return <Screen><AppHeader title="Register" /><EmptyState icon="lock-closed-outline" title="Not permitted" detail="Your account cannot register visitors." /></Screen>;

  const otpRequired = requiresOtp(form.category, cfg.requireOtpForGuests);
  const set = <K extends keyof RegistrationInput>(k: K, v: RegistrationInput[K]) => { setForm((f) => ({ ...f, [k]: v })); setErrors((e) => ({ ...e, [k]: undefined })); };

  async function submit() {
    if (busy) return;
    const errs = validateRegistration(form, { phoneRule: config.phoneRule, otpRequired });
    setErrors(errs);
    if (hasErrors(errs)) { setSubmitError('Fix the highlighted fields.'); return; }
    setBusy(true); setSubmitError(null);
    try { setCreated(await requestsService.create(form, user, key.current)); key.current = newKey(); }
    catch (e) {
      if (e instanceof ApiError && e.kind === 'validation') setSubmitError(e.message);
      else { const d = describeError(e); setSubmitError(`${d.title}. ${d.detail}`); }
    } finally { setBusy(false); }
  }
  function reset() { setCreated(null); setErrors({}); setSubmitError(null); setForm(blank(user.assignedGate ?? '')); router.setParams({ name: undefined, classification: undefined }); }

  if (created) {
    const needsOtp = canVerifyOtp(created.requestStatus, created.otpStatus);
    return (
      <Screen>
        <AppHeader title="Request submitted" />
        <Card>
          <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Request {created.requestId}</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs }}>
            <StatusBadge status={created.requestStatus} /><OtpBadge value={created.otpStatus} />
          </View>
          <Text style={[t.body, { color: colors.textSecondary }]}>
            {needsOtp ? 'Ask the visitor for the OTP sent to their phone, then verify it. The request goes for approval only after that.' : 'The request is with the approving authority. The visitor can enter once it is Approved.'}
          </Text>
        </Card>
        {needsOtp ? <PrimaryButton label="Enter OTP" icon="keypad-outline" onPress={() => router.push({ pathname: '/otp/[requestId]', params: { requestId: created.requestId } })} /> : null}
        <SecondaryButton label="View request" onPress={() => router.push({ pathname: '/requests/[requestId]', params: { requestId: created.requestId } })} />
        <SecondaryButton label="Register another visitor" onPress={reset} />
      </Screen>
    );
  }

  return (
    <Screen>
      <AppHeader title="Register visitor" />
      {fromIdentify ? <Text style={[t.support, { color: colors.textSecondary }]}>Prefilled from identification. {CONFIRM_MATCH_NOTICE}</Text> : null}
      {cfg.source === 'admin-defaults' ? <Text style={[t.support, { color: colors.textSecondary }]}>Using the admin default lists (the server configuration was not available).</Text> : null}

      <FormField label="Visitor full name" value={form.fullName} onChangeText={(v) => set('fullName', v)} error={errors.fullName} autoCapitalize="words" textContentType="name" />
      <SelectField label="Visitor category" options={cfg.visitorCategories as VisitorCategory[]} value={form.category} onChange={(v) => set('category', v)} error={errors.category} />
      <SelectField label="Identity classification" options={IDENTITY_CLASSIFICATIONS} value={form.classification} onChange={(v) => set('classification', v)} error={errors.classification} />
      {form.classification === 'Unknown' ? <Text style={[t.support, { color: colors.textSecondary }]}>“Unknown” only means the visitor is not yet on record. It does not imply unauthorized or malicious intent.</Text> : null}
      <FormField label={otpRequired ? 'Mobile number (OTP will be sent)' : 'Mobile number (optional)'} value={form.phone} onChangeText={(v) => set('phone', v)} error={errors.phone} keyboardType="phone-pad" textContentType="telephoneNumber" placeholder="+91 98765 43210" />
      {otpRequired ? <Text style={[t.support, { color: colors.textSecondary }]}>External guests must verify an OTP before the request can be approved.</Text> : null}

      <SelectField label="Person / authority to meet" options={cfg.authorizedMeetingAuthorities} value={form.personToMeet || null} onChange={(v) => set('personToMeet', v)} error={errors.personToMeet} />
      <FormField label="Department (optional)" value={form.department} onChangeText={(v) => set('department', v)} />
      <FormField label="Reason for meeting" value={form.reason} onChangeText={(v) => set('reason', v)} error={errors.reason} multiline />
      <SelectField label="Visit mode" options={VISIT_MODES} value={form.visitMode} onChange={(v) => set('visitMode', v)} error={errors.visitMode} />
      {form.visitMode === 'Scheduled' ? (
        <>
          <FormField label="Requested date (YYYY-MM-DD)" value={form.requestedDate} onChangeText={(v) => set('requestedDate', v)} error={errors.requestedDate} keyboardType="numbers-and-punctuation" />
          <FormField label="Requested time (24-hour, e.g. 14:30)" value={form.requestedTime} onChangeText={(v) => set('requestedTime', v)} error={errors.requestedTime} keyboardType="numbers-and-punctuation" />
          <FormField label="Appointment details (optional)" value={form.appointmentDetails} onChangeText={(v) => set('appointmentDetails', v)} multiline />
        </>
      ) : <Text style={[t.support, { color: colors.textSecondary }]}>Walk-in: requested for today, now.</Text>}
      {cfg.gates.length > 0
        ? <SelectField label="Gate / entry location" options={cfg.gates} value={form.gate || null} onChange={(v) => set('gate', v)} error={errors.gate} />
        : <FormField label="Gate / entry location" value={form.gate} onChangeText={(v) => set('gate', v)} error={errors.gate} />}
      <FormField label="Staff notes (gate remarks, optional)" value={form.staffNotes} onChangeText={(v) => set('staffNotes', v)} multiline />

      {submitError ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.critical.fg }]}>{submitError}</Text> : null}
      <PrimaryButton label="Submit request" icon="paper-plane-outline" onPress={() => { void submit(); }} loading={busy} />
    </Screen>
  );
}
