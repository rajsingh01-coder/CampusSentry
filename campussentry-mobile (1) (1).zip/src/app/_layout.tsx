import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import React, { useEffect } from 'react';
import { View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { DemoBanner } from '../components/ui/DemoBanner';
import { OfflineBanner } from '../components/ui/OfflineBanner';
import { AuthProvider, useAuth } from '../features/auth/AuthProvider';
import { ConfigProvider } from '../features/config/ConfigProvider';
import { ThemeProvider, useTheme } from '../theme/ThemeProvider';

void SplashScreen.preventAutoHideAsync().catch(() => undefined);

function Gate() {
  const { status } = useAuth();
  const { colors, scheme, ready } = useTheme();
  const segments = useSegments();
  const router = useRouter();

  // Hide the splash only after the saved theme and the session are known, so there is no light/dark flash.
  useEffect(() => { if (ready && status !== 'loading') void SplashScreen.hideAsync().catch(() => undefined); }, [ready, status]);
  useEffect(() => {
    if (status === 'loading') return;
    const inAuth = segments[0] === '(auth)';
    if (status === 'signedOut' && !inAuth) router.replace('/(auth)/login');
    else if (status === 'signedIn' && inAuth) router.replace('/(tabs)');
  }, [status, segments, router]);

  if (!ready || status === 'loading') return <View style={{ flex: 1, backgroundColor: colors.background }} />;
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
      <DemoBanner />
      <OfflineBanner />
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }} />
    </View>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AuthProvider>
          <ConfigProvider>
            <Gate />
          </ConfigProvider>
        </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
