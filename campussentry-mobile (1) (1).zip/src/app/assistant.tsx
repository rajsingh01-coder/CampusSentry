import React, { useRef, useState } from 'react';
import { FlatList, Text, View } from 'react-native';
import { AppHeader } from '../components/ui/AppHeader';
import { PrimaryButton } from '../components/ui/Buttons';
import { ConfirmationSheet } from '../components/ui/ConfirmationSheet';
import { FormField } from '../components/ui/FormField';
import { describeError } from '../services/errors';
import { assistantService } from '../services/assistant.service';
import type { AssistantReply } from '../services/parsers-ops';
import { radius, spacing } from '../theme/spacing';
import { useTheme } from '../theme/ThemeProvider';
import { type as t } from '../theme/typography';
import { newKey } from '../utils/ids';

interface Msg { id: string; from: 'me' | 'assistant' | 'error'; text: string }

export default function Assistant() {
  const { colors } = useTheme();
  const [msgs, setMsgs] = useState<Msg[]>([{ id: 'hello', from: 'assistant', text: 'Ask about visitors or requests. I act with your own permissions, and I always ask you to confirm before changing anything.' }]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [proposal, setProposal] = useState<NonNullable<AssistantReply['proposal']> | null>(null);
  const conv = useRef<string | undefined>(undefined);
  const key = useRef(newKey());
  const add = (m: Omit<Msg, 'id'>) => setMsgs((l) => [...l, { ...m, id: `${l.length}-${Date.now()}` }]);

  async function send() {
    const message = text.trim();
    if (!message || busy) return;
    setText(''); add({ from: 'me', text: message }); setBusy(true);
    try {
      const r = await assistantService.send(message, conv.current);
      conv.current = r.conversationId ?? conv.current;
      add({ from: 'assistant', text: r.reply });
      if (r.proposal) setProposal(r.proposal);
    } catch (e) { const d = describeError(e); add({ from: 'error', text: `${d.title}. ${d.detail}` }); }
    finally { setBusy(false); }
  }
  async function confirm() {
    if (!proposal || busy) return;
    setBusy(true);
    try { const r = await assistantService.confirm(proposal.id, conv.current, key.current); key.current = newKey(); add({ from: 'assistant', text: r.reply }); setProposal(null); }
    catch (e) { const d = describeError(e); add({ from: 'error', text: `${d.title}. ${d.detail}` }); setProposal(null); }
    finally { setBusy(false); }
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, paddingTop: 48, paddingHorizontal: spacing.lg }}>
      <AppHeader title="AI assistant" back />
      <FlatList data={msgs} keyExtractor={(m) => m.id} contentContainerStyle={{ gap: spacing.sm, paddingVertical: spacing.md }}
        renderItem={({ item }) => (
          <View style={{ alignSelf: item.from === 'me' ? 'flex-end' : 'flex-start', maxWidth: '85%', padding: spacing.md, borderRadius: radius.lg, backgroundColor: item.from === 'me' ? colors.primary : item.from === 'error' ? colors.status.critical.bg : colors.surface, borderWidth: item.from === 'me' ? 0 : 1, borderColor: colors.border }}>
            <Text style={[t.body, { color: item.from === 'me' ? colors.onPrimary : item.from === 'error' ? colors.status.critical.fg : colors.text }]}>{item.text}</Text>
          </View>
        )} />
      <View style={{ gap: spacing.sm, paddingBottom: spacing.lg }}>
        <FormField label="Message" value={text} onChangeText={setText} placeholder="How many visitors are inside?" returnKeyType="send" onSubmitEditing={() => { void send(); }} />
        <PrimaryButton label="Send" icon="send-outline" onPress={() => { void send(); }} loading={busy && !proposal} disabled={!text.trim()} />
      </View>
      <ConfirmationSheet visible={!!proposal} busy={busy} title={proposal?.title ?? ''} message={proposal?.description} confirmLabel="Confirm" onCancel={() => setProposal(null)} onConfirm={() => { void confirm(); }} />
    </View>
  );
}
