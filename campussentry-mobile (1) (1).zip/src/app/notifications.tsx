import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, Text, View } from 'react-native';
import { AppHeader } from '../components/ui/AppHeader';
import { SecondaryButton } from '../components/ui/Buttons';
import { Badge, ClassificationBadge, StatusBadge } from '../components/ui/StatusBadge';
import { EmptyState, ErrorState, LoadingView } from '../components/ui/States';
import { usePagedList } from '../hooks/usePagedList';
import { notificationService } from '../services/notification.service';
import type { AppNotification } from '../services/parsers-ops';
import { radius, spacing } from '../theme/spacing';
import { useTheme } from '../theme/ThemeProvider';
import { type as t } from '../theme/typography';
import { formatDateTime } from '../utils/ids';

export default function Notifications() {
  const { colors } = useTheme();
  const router = useRouter();
  const list = usePagedList<AppNotification>((page, signal) => notificationService.list(page, signal), (n) => n.id, 'notifications');
  const [readIds, setReadIds] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const isRead = (n: AppNotification) => n.isRead || readIds.has(n.id);
  const unread = list.items.filter((n) => !isRead(n)).length;

  async function open(n: AppNotification) {
    if (!isRead(n)) { try { await notificationService.markRead(n.id); setReadIds((s) => new Set(s).add(n.id)); } catch { /* opening still works; stays unread */ } }
    router.push({ pathname: '/requests/[requestId]', params: { requestId: n.requestId } });
  }
  async function markAll() { setBusy(true); try { await notificationService.markAllRead(); list.refresh(); setReadIds(new Set()); } catch { /* stay as is; the list shows server state */ } finally { setBusy(false); } }

  const header = (
    <View style={{ gap: spacing.md, paddingBottom: spacing.md }}>
      <AppHeader title="Notifications" back />
      {unread > 0 ? <SecondaryButton label={`Mark all as read (${unread})`} icon="checkmark-done-outline" onPress={() => { void markAll(); }} loading={busy} /> : null}
    </View>
  );
  return (
    <View style={{ flex: 1, backgroundColor: colors.background, paddingTop: 48, paddingHorizontal: spacing.lg }}>
      <FlatList
        data={list.items} keyExtractor={(n) => n.id} ListHeaderComponent={header}
        refreshing={list.refreshing} onRefresh={list.refresh} onEndReached={list.loadMore} onEndReachedThreshold={0.4}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        renderItem={({ item: n }) => (
          <Pressable onPress={() => { void open(n); }} accessibilityRole="button" accessibilityLabel={`${isRead(n) ? '' : 'Unread. '}${n.visitorName}, ${n.requestStatus ?? ''}`}
            style={{ backgroundColor: colors.surface, borderColor: isRead(n) ? colors.border : colors.primary, borderWidth: 1, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.xs }}>
            <Text style={[t.cardTitle, { color: colors.text }]}>{n.visitorName}</Text>
            <Text style={[t.support, { color: colors.textSecondary }]}>{[n.personToMeet && `To meet ${n.personToMeet}`, n.reasonForMeeting].filter(Boolean).join('  •  ')}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs }}>
              {n.priority !== 'Normal' ? <Badge label={n.priority} tone={n.priority === 'Urgent' ? 'critical' : 'warning'} icon="flag-outline" prefix="Priority" /> : null}
              {n.requestStatus ? <StatusBadge status={n.requestStatus} /> : null}
              {n.identityClassification ? <ClassificationBadge value={n.identityClassification} /> : null}
            </View>
            <Text style={[t.support, { color: colors.textSecondary }]}>{formatDateTime(n.createdAt)}{isRead(n) ? '' : '  •  Unread'}</Text>
          </Pressable>
        )}
        ListEmptyComponent={list.loading ? <LoadingView label="Loading notifications" /> : list.error ? <ErrorState error={list.error} onRetry={list.reload} /> : <EmptyState icon="notifications-off-outline" title="No notifications" />}
        ListFooterComponent={list.loadingMore ? <ActivityIndicator color={colors.primary} style={{ margin: spacing.lg }} /> : <View style={{ height: spacing.xxl }} />}
      />
    </View>
  );
}
