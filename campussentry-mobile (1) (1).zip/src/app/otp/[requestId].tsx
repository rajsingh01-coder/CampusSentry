import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { FormField } from '../../components/ui/FormField';
import { Screen } from '../../components/ui/Screen';
import { StatusBadge } from '../../components/ui/StatusBadge';
import { classifyOtpError, isOtpSubmittable, sanitizeOtp } from '../../domain/otp';
import { describeError } from '../../services/errors';
import { requestsService } from '../../services/requests.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export default function OtpScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const { requestId } = useLocalSearchParams<{ requestId: string }>();
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [verified, setVerified] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const id = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(id);
  }, [cooldown]);

  function fail(e: unknown) {
    const f = classifyOtpError(e);
    if (f.kind === 'incorrect') setError('That code is incorrect. Check it and try again.');
    else if (f.kind === 'expired') setError('That code has expired. Send a new one.');
    else if (f.kind === 'rate_limited') { setError('Too many attempts. Wait before trying again.'); setCooldown(f.retryAfterSeconds ?? 30); }
    else { const d = describeError(f.error); setError(`${d.title}. ${d.detail}`); }
  }
  async function verify() {
    if (busy || !isOtpSubmittable(code) || cooldown > 0) return;
    setBusy(true); setError(null); setInfo(null);
    try { await requestsService.verifyOtp(requestId, code); setVerified(true); } // success only after the server confirms
    catch (e) { fail(e); } finally { setBusy(false); }
  }
  async function resend() {
    if (busy || cooldown > 0) return;
    setBusy(true); setError(null); setInfo(null);
    try { await requestsService.resendOtp(requestId); setInfo('A new OTP was sent.'); setCode(''); setCooldown(30); }
    catch (e) { fail(e); } finally { setBusy(false); }
  }

  if (verified) {
    return (
      <Screen>
        <AppHeader title="OTP verified" />
        <Card>
          <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Verified</Text>
          <Text style={[t.body, { color: colors.textSecondary }]}>The request now moves to Pending Approval.</Text>
          <StatusBadge status="Pending Approval" />
        </Card>
        <PrimaryButton label="View request" onPress={() => router.replace({ pathname: '/requests/[requestId]', params: { requestId } })} />
      </Screen>
    );
  }
  return (
    <Screen>
      <AppHeader title="Verify OTP" back />
      <Text style={[t.body, { color: colors.textSecondary }]}>Ask the visitor for the code sent to their phone. Request {requestId}.</Text>
      <FormField label="One-time code" value={code} onChangeText={(v) => setCode(sanitizeOtp(v))} keyboardType="number-pad" maxLength={8} textContentType="oneTimeCode" autoComplete="sms-otp" error={error ?? undefined} />
      {info ? <Text accessibilityLiveRegion="polite" style={[t.support, { color: colors.status.success.fg }]}>{info}</Text> : null}
      <View style={{ gap: spacing.sm }}>
        <PrimaryButton label={cooldown > 0 ? `Wait ${cooldown}s` : 'Verify'} onPress={() => { void verify(); }} loading={busy} disabled={!isOtpSubmittable(code) || cooldown > 0} />
        <SecondaryButton label="Send a new code" icon="refresh-outline" onPress={() => { void resend(); }} disabled={busy || cooldown > 0} />
      </View>
    </Screen>
  );
}
