import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { ConfirmationSheet } from '../../components/ui/ConfirmationSheet';
import { FormField } from '../../components/ui/FormField';
import { InfoRow } from '../../components/ui/InfoRow';
import { Screen } from '../../components/ui/Screen';
import { ScreenCaptureGuard } from '../../components/ui/ScreenCaptureGuard';
import { CategoryBadge, ClassificationBadge, OtpBadge, PresenceBadge, StatusBadge } from '../../components/ui/StatusBadge';
import { ErrorState, LoadingView } from '../../components/ui/States';
import { can } from '../../domain/permissions';
import { maskPhone } from '../../domain/validation';
import { canReviewRequest, canVerifyOtp, type RequestDecision } from '../../domain/workflow';
import { useStaff } from '../../features/auth/AuthProvider';
import { useAsync } from '../../hooks/useAsync';
import { describeError } from '../../services/errors';
import { requestsService } from '../../services/requests.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { formatDateTime, newKey } from '../../utils/ids';

export default function RequestDetailScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const { requestId } = useLocalSearchParams<{ requestId: string }>();
  const detail = useAsync((signal) => requestsService.detail(requestId, signal));
  const [pending, setPending] = useState<RequestDecision | null>(null);
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const keyRef = useRef(newKey());
  const r = detail.data;
  const canReview = can(user, 'request.review');

  async function decide() {
    if (!pending || !r || busy) return;
    if (pending === 'Rejected' && notes.trim().length < 3) { setError('A reason is required to reject a request.'); return; }
    setBusy(true); setError(null);
    try { await requestsService.decide(r.requestId, pending, notes, keyRef.current); keyRef.current = newKey(); setPending(null); setNotes(''); detail.silent(); }
    catch (e) { const d = describeError(e); setError(`${d.title}. ${d.detail}`); detail.silent(); }
    finally { setBusy(false); }
  }

  return (
    <Screen refreshing={detail.refreshing} onRefresh={detail.refresh}>
      <ScreenCaptureGuard />
      <AppHeader title="Request" back />
      {detail.loading && !r ? <LoadingView /> : null}
      {detail.error && !r ? <ErrorState error={detail.error} onRetry={detail.reload} /> : null}
      {r ? (
        <>
          <Card>
            <Text style={[t.sectionTitle, { color: colors.text }]}>{r.visitorName}</Text>
            <Text style={[t.support, { color: colors.textSecondary }]}>{r.requestId}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs }}>
              <StatusBadge status={r.requestStatus} /><CategoryBadge value={r.visitorCategory} /><ClassificationBadge value={r.identityClassification} /><OtpBadge value={r.otpStatus} />
              {r.presence ? <PresenceBadge value={r.presence} /> : null}
            </View>
            {r.identityClassification === 'Unknown' ? <Text style={[t.support, { color: colors.textSecondary }]}>“Unknown” does not imply unauthorized or malicious intent.</Text> : null}
          </Card>

          {canVerifyOtp(r.requestStatus, r.otpStatus) ? (
            <Card>
              <Text style={[t.cardTitle, { color: colors.text }]}>OTP verification pending</Text>
              <Text style={[t.support, { color: colors.textSecondary }]}>The request cannot go for approval until the visitor’s OTP is verified.</Text>
              <PrimaryButton label="Enter OTP" icon="keypad-outline" onPress={() => router.push({ pathname: '/otp/[requestId]', params: { requestId: r.requestId } })} />
            </Card>
          ) : null}

          <Card>
            <InfoRow label="Meeting with" value={r.personToMeet} />
            <InfoRow label="Department" value={r.department} />
            <InfoRow label="Reason for meeting" value={r.reasonForMeeting} />
            <InfoRow label="Visit mode" value={r.visitMode} />
            <InfoRow label="Requested for" value={[r.requestedDate, r.requestedTime].filter(Boolean).join(' ')} />
            <InfoRow label="Appointment details" value={r.appointmentDetails} />
            <InfoRow label="Phone" value={r.phoneNumber ? (can(user, 'visitor.search_phone') ? r.phoneNumber : maskPhone(r.phoneNumber)) : undefined} />
            <InfoRow label="Gate / entry location" value={r.gateOrLocation} />
            <InfoRow label="Submitted by" value={r.submittedBy} />
            <InfoRow label="Staff notes" value={r.staffNotes} />
            <InfoRow label="Created" value={formatDateTime(r.createdAt)} />
          </Card>

          {r.reviews.length > 0 ? (
            <View style={{ gap: spacing.sm }}>
              <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Review history</Text>
              {r.reviews.map((rv, i) => (
                <Card key={`${rv.at ?? i}-${i}`}>
                  <Text style={[t.cardTitle, { color: colors.text }]}>{rv.decision}</Text>
                  <Text style={[t.support, { color: colors.textSecondary }]}>{[rv.by, rv.at ? formatDateTime(rv.at) : undefined].filter(Boolean).join('  •  ')}</Text>
                  {canReview && rv.notes ? <Text style={[t.body, { color: colors.text }]}>{rv.notes}</Text> : null}
                </Card>
              ))}
            </View>
          ) : null}

          {error ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.critical.fg }]}>{error}</Text> : null}
          {canReview && canReviewRequest(r.requestStatus) ? (
            <View style={{ gap: spacing.sm }}>
              <PrimaryButton label="Approve" icon="checkmark-circle-outline" onPress={() => { setError(null); setPending('Approved'); }} />
              <SecondaryButton label="Request more information" icon="information-circle-outline" onPress={() => { setError(null); setPending('Additional Information Required'); }} />
              <SecondaryButton label="Reject" icon="close-circle-outline" onPress={() => { setError(null); setPending('Rejected'); }} />
            </View>
          ) : !canReview && canReviewRequest(r.requestStatus) ? <Text style={[t.support, { color: colors.textSecondary }]}>Approval decisions are made by administrators.</Text> : null}
          {r.visitorId ? <SecondaryButton label="Open visitor record" icon="person-outline" onPress={() => router.push({ pathname: '/visitors/[visitorId]', params: { visitorId: r.visitorId! } })} /> : null}

          <ConfirmationSheet visible={pending !== null} busy={busy} onCancel={() => { setPending(null); setNotes(''); }} onConfirm={() => { void decide(); }}
            title={pending === 'Approved' ? 'Approve this request?' : pending === 'Rejected' ? 'Reject this request?' : 'Ask for more information?'}
            message={pending === 'Approved' ? 'The visitor will be allowed to check in. Final decisions cannot be reversed.' : pending === 'Rejected' ? 'This cannot be undone. A reason is required.' : 'The request stays open until the details are provided.'}
            confirmLabel={pending === 'Approved' ? 'Approve' : pending === 'Rejected' ? 'Reject' : 'Send request'}>
            {pending !== 'Approved' ? <FormField label={pending === 'Rejected' ? 'Reason (required)' : 'What is needed? (optional)'} value={notes} onChangeText={setNotes} multiline /> : <FormField label="Notes (optional)" value={notes} onChangeText={setNotes} multiline />}
            {error ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.critical.fg }]}>{error}</Text> : null}
          </ConfirmationSheet>
        </>
      ) : null}
    </Screen>
  );
}
