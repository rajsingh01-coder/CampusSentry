import { useRouter } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { Chips } from '../../components/ui/Chips';
import { FormField } from '../../components/ui/FormField';
import { EmptyState, ErrorState, LoadingView } from '../../components/ui/States';
import { VisitorCard } from '../../components/visitors/VisitorCard';
import { REQUEST_STATUSES, type RequestStatus } from '../../domain/types';
import { useDebounced } from '../../hooks/useDebounced';
import { usePagedList } from '../../hooks/usePagedList';
import { requestsService } from '../../services/requests.service';
import type { RequestSummary } from '../../services/parsers-ops';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { formatDateTime } from '../../utils/ids';

export default function Requests() {
  const { colors } = useTheme();
  const router = useRouter();
  const [status, setStatus] = useState<RequestStatus | null>(null);
  const [query, setQuery] = useState('');
  const q = useDebounced(query, 350);
  const filters = useMemo(() => ({ status, query: q }), [status, q]);
  const list = usePagedList<RequestSummary>((page, signal) => requestsService.list(filters, page, signal), (r) => r.requestId, JSON.stringify(filters));

  const header = (
    <View style={{ gap: spacing.md, paddingBottom: spacing.md }}>
      <AppHeader title="Visit requests" back />
      <FormField label="Search" value={query} onChangeText={setQuery} placeholder="Visitor name or request ID" autoCapitalize="none" returnKeyType="search" />
      <Chips label="Status" options={[{ value: null, label: 'All' }, ...REQUEST_STATUSES.map((s) => ({ value: s as RequestStatus | null, label: s }))]} value={status} onChange={setStatus} />
    </View>
  );
  return (
    <View style={{ flex: 1, backgroundColor: colors.background, paddingTop: 48, paddingHorizontal: spacing.lg }}>
      <FlatList
        data={list.items} keyExtractor={(r) => r.requestId} ListHeaderComponent={header} keyboardShouldPersistTaps="handled"
        refreshing={list.refreshing} onRefresh={list.refresh} onEndReached={list.loadMore} onEndReachedThreshold={0.4}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        renderItem={({ item }) => (
          <VisitorCard name={item.visitorName} category={item.visitorCategory} classification={item.identityClassification} status={item.requestStatus}
            subtitle={`${item.requestId}  •  ${formatDateTime(item.createdAt)}`} onPress={() => router.push({ pathname: '/requests/[requestId]', params: { requestId: item.requestId } })} />
        )}
        ListEmptyComponent={list.loading ? <LoadingView label="Loading requests" /> : list.error ? <ErrorState error={list.error} onRetry={list.reload} /> : <EmptyState icon="documents-outline" title="No requests found" detail={status || q ? 'Try a different status or search.' : 'New visit requests will appear here.'} />}
        ListFooterComponent={list.loadingMore ? <ActivityIndicator color={colors.primary} style={{ margin: spacing.lg }} /> : list.loadMoreError ? <ErrorState error={list.loadMoreError} onRetry={list.loadMore} /> : <View style={{ height: spacing.xxl }} />}
      />
    </View>
  );
}
