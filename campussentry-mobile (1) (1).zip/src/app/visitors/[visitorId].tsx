import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useRef, useState } from 'react';
import { Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { ConfirmationSheet } from '../../components/ui/ConfirmationSheet';
import { InfoRow } from '../../components/ui/InfoRow';
import { Screen } from '../../components/ui/Screen';
import { ScreenCaptureGuard } from '../../components/ui/ScreenCaptureGuard';
import { CategoryBadge, ClassificationBadge, PresenceBadge, StatusBadge } from '../../components/ui/StatusBadge';
import { ErrorState, LoadingView } from '../../components/ui/States';
import { can } from '../../domain/permissions';
import { getAllowedActions } from '../../domain/presence';
import { maskPhone } from '../../domain/validation';
import { useStaff } from '../../features/auth/AuthProvider';
import { useAsync } from '../../hooks/useAsync';
import { usePagedList } from '../../hooks/usePagedList';
import { describeError } from '../../services/errors';
import type { HistoryEvent } from '../../services/parsers-ops';
import { visitorService } from '../../services/visitor.service';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { formatDateTime, newKey } from '../../utils/ids';

export default function VisitorDetailScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const { visitorId } = useLocalSearchParams<{ visitorId: string }>();
  const detail = useAsync((signal) => visitorService.detail(visitorId, signal));
  const showHistory = can(user, 'history.view');
  const history = usePagedList<HistoryEvent>((page, signal) => (showHistory ? visitorService.history(visitorId, page, signal) : Promise.resolve({ data: [], total: 0, page: 1, pageSize: 20, totalPages: 1 })), (e) => e.id, visitorId);
  const [action, setAction] = useState<'in' | 'out' | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const keyRef = useRef(newKey());

  const v = detail.data;
  const gate = user.assignedGate ?? '';

  async function run() {
    if (!action || !v || busy) return;
    setBusy(true); setError(null);
    try {
      if (action === 'in') await visitorService.checkIn(v.visitorId, gate, keyRef.current);
      else await visitorService.checkOut(v.visitorId, gate, keyRef.current);
      keyRef.current = newKey();
      setAction(null);
      detail.silent(); history.refresh(); // the server decides the resulting state: re-read it
    } catch (e) { const d = describeError(e); setError(`${d.title}. ${d.detail}`); detail.silent(); } // a 409 means someone else changed it: show fresh state
    finally { setBusy(false); }
  }

  return (
    <Screen refreshing={detail.refreshing} onRefresh={() => { detail.refresh(); history.refresh(); }}>
      <ScreenCaptureGuard />
      <AppHeader title="Visitor" back />
      {detail.loading && !v ? <LoadingView /> : null}
      {detail.error && !v ? <ErrorState error={detail.error} onRetry={detail.reload} /> : null}
      {v ? (() => {
        const allowed = getAllowedActions({ requestStatus: v.requestStatus ?? 'Pending Approval', presence: v.presence ?? 'Not Checked In' });
        const hasRequest = !!v.requestStatus;
        return (
          <>
            <Card>
              <Text style={[t.sectionTitle, { color: colors.text }]}>{v.visitorName}</Text>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs }}>
                <CategoryBadge value={v.visitorCategory} /><ClassificationBadge value={v.identityClassification} />
                {v.requestStatus ? <StatusBadge status={v.requestStatus} /> : null}{v.presence ? <PresenceBadge value={v.presence} /> : null}
              </View>
              <InfoRow label="Visitor ID" value={v.visitorId} />
              <InfoRow label="Phone" value={v.phoneNumber ? (can(user, 'visitor.search_phone') ? v.phoneNumber : maskPhone(v.phoneNumber)) : undefined} />
              <InfoRow label="Last activity" value={v.lastActivityAt ? formatDateTime(v.lastActivityAt) : undefined} />
            </Card>

            {error ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.critical.fg }]}>{error}</Text> : null}
            {hasRequest ? (
              <View style={{ gap: spacing.sm }}>
                {can(user, 'visitor.checkin') ? <PrimaryButton label="Check in" icon="log-in-outline" disabled={!allowed.canCheckIn} onPress={() => setAction('in')} /> : null}
                {can(user, 'visitor.checkin') && !allowed.canCheckIn && allowed.checkInBlockedReason ? <Text style={[t.support, { color: colors.textSecondary }]}>{allowed.checkInBlockedReason}</Text> : null}
                {can(user, 'visitor.checkout') ? <SecondaryButton label="Check out" icon="log-out-outline" disabled={!allowed.canCheckOut} onPress={() => setAction('out')} /> : null}
              </View>
            ) : <Text style={[t.support, { color: colors.textSecondary }]}>This visitor has no request yet. Register one first.</Text>}

            <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Requests</Text>
            {v.requests.length === 0 ? <Text style={[t.support, { color: colors.textSecondary }]}>No requests on record.</Text> : v.requests.map((r) => (
              <Card key={r.requestId}>
                <Text style={[t.cardTitle, { color: colors.text }]}>{r.requestId}</Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs }}><StatusBadge status={r.requestStatus} /></View>
                <Text style={[t.support, { color: colors.textSecondary }]}>{formatDateTime(r.createdAt)}{r.personToMeet ? `  •  ${r.personToMeet}` : ''}</Text>
                <SecondaryButton label="Open request" onPress={() => router.push({ pathname: '/requests/[requestId]', params: { requestId: r.requestId } })} />
              </Card>
            ))}

            {showHistory ? (
              <>
                <Text accessibilityRole="header" style={[t.sectionTitle, { color: colors.text }]}>Entry / exit history</Text>
                {history.loading ? <LoadingView label="Loading history" /> : history.error ? <ErrorState error={history.error} onRetry={history.reload} /> : history.items.length === 0 ? <Text style={[t.support, { color: colors.textSecondary }]}>No entries or exits recorded.</Text> : (
                  <Card>
                    {history.items.map((e) => (
                      <View key={e.id} style={{ gap: 2 }} accessible>
                        <Text style={[t.body, { color: colors.text, fontWeight: '600' }]}>{e.kind === 'check_in' ? 'Checked in' : 'Checked out'}</Text>
                        <Text style={[t.support, { color: colors.textSecondary }]}>{formatDateTime(e.at)}{e.gate ? `  •  ${e.gate}` : ''}{e.staffName ? `  •  ${e.staffName}` : ''}</Text>
                      </View>
                    ))}
                    {history.hasMore ? <SecondaryButton label="Load more" onPress={history.loadMore} loading={history.loadingMore} /> : null}
                  </Card>
                )}
              </>
            ) : null}

            <ConfirmationSheet visible={action !== null} busy={busy} onCancel={() => setAction(null)} onConfirm={() => { void run(); }}
              title={action === 'in' ? `Check in ${v.visitorName}?` : `Check out ${v.visitorName}?`}
              message={`${action === 'in' ? 'Records an entry' : 'Records an exit'}${gate ? ` at ${gate}` : ''}. This is saved in the entry/exit log.`}
              confirmLabel={action === 'in' ? 'Confirm check-in' : 'Confirm check-out'} />
          </>
        );
      })() : null}
    </Screen>
  );
}
