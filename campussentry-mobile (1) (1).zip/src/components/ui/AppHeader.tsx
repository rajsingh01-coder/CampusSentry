import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MIN_TOUCH, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

type Icon = React.ComponentProps<typeof Ionicons>['name'];
interface Props { title: string; back?: boolean; actions?: { icon: Icon; label: string; onPress: () => void }[] }

export function AppHeader({ title, back, actions }: Props) {
  const { colors } = useTheme();
  const router = useRouter();
  return (
    <View style={styles.row}>
      {back ? (
        <Pressable onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))} accessibilityRole="button" accessibilityLabel="Go back" style={styles.icon}>
          <Ionicons name="chevron-back" size={26} color={colors.text} />
        </Pressable>
      ) : null}
      <Text accessibilityRole="header" numberOfLines={1} style={[t.screenTitle, { color: colors.text, flex: 1 }]}>{title}</Text>
      {actions?.map((a) => (
        <Pressable key={a.label} onPress={a.onPress} accessibilityRole="button" accessibilityLabel={a.label} style={styles.icon}>
          <Ionicons name={a.icon} size={24} color={colors.text} />
        </Pressable>
      ))}
    </View>
  );
}
const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, minHeight: MIN_TOUCH },
  icon: { width: MIN_TOUCH, height: MIN_TOUCH, alignItems: 'center', justifyContent: 'center' },
});
