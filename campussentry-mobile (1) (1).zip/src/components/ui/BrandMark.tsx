import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

/** Admin brand: shield on a blue rounded square, "CampusSentry / Campus operations". */
export function BrandMark({ size = 40, showText = true }: { size?: number; showText?: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={styles.row} accessible accessibilityLabel="CampusSentry, Campus operations">
      <View style={{ width: size, height: size, borderRadius: size * 0.28, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center' }}>
        <Ionicons name="shield-checkmark" size={size * 0.55} color={colors.onPrimary} />
      </View>
      {showText ? (
        <View>
          <Text style={[t.cardTitle, { color: colors.text }]}>CampusSentry</Text>
          <Text style={[t.support, { color: colors.textSecondary }]}>Campus operations</Text>
        </View>
      ) : null}
    </View>
  );
}
const styles = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md } });
