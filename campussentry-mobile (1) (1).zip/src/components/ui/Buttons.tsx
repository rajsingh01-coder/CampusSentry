import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { MIN_TOUCH, radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export type IconName = React.ComponentProps<typeof Ionicons>['name'];
interface Props { label: string; onPress: () => void; loading?: boolean; disabled?: boolean; icon?: IconName; accessibilityHint?: string }

function Base({ label, onPress, loading, disabled, icon, accessibilityHint, variant }: Props & { variant: 'primary' | 'secondary' }) {
  const { colors } = useTheme();
  const inactive = disabled || loading;
  const bg = variant === 'primary' ? colors.primary : colors.surface;
  const fg = variant === 'primary' ? colors.onPrimary : colors.text;
  return (
    <Pressable
      onPress={inactive ? undefined : onPress} accessibilityRole="button" accessibilityLabel={label} accessibilityHint={accessibilityHint}
      accessibilityState={{ disabled: !!inactive, busy: !!loading }}
      style={({ pressed }) => [styles.btn, { backgroundColor: bg, borderColor: variant === 'primary' ? bg : colors.border, opacity: inactive ? 0.5 : pressed ? 0.85 : 1 }]}
    >
      {loading ? <ActivityIndicator color={fg} /> : (
        <View style={styles.row}>
          {icon ? <Ionicons name={icon} size={20} color={fg} /> : null}
          <Text style={[t.button, { color: fg }]}>{label}</Text>
        </View>
      )}
    </Pressable>
  );
}
export const PrimaryButton = (p: Props) => <Base {...p} variant="primary" />;
export const SecondaryButton = (p: Props) => <Base {...p} variant="secondary" />;

const styles = StyleSheet.create({
  btn: { minHeight: MIN_TOUCH, borderRadius: radius.md, borderWidth: 1, paddingHorizontal: spacing.lg, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
});
