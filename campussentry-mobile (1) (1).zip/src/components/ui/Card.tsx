import React from 'react';
import { StyleSheet, View, type ViewStyle } from 'react-native';
import { radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';

export function Card({ children, style }: { children: React.ReactNode; style?: ViewStyle }) {
  const { colors } = useTheme();
  return <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>{children}</View>;
}
const styles = StyleSheet.create({ card: { borderWidth: 1, borderRadius: radius.lg, padding: spacing.lg, gap: spacing.sm } });
