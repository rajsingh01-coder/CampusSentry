import React from 'react';
import { Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { PrimaryButton, SecondaryButton } from './Buttons';

interface Props { visible: boolean; title: string; message?: string; confirmLabel: string; onConfirm: () => void; onCancel: () => void; busy?: boolean; confirmDisabled?: boolean; children?: React.ReactNode }

/** Bottom sheet used before every consequential action. Android back button cancels. */
export function ConfirmationSheet({ visible, title, message, confirmLabel, onConfirm, onCancel, busy, confirmDisabled, children }: Props) {
  const { colors } = useTheme();
  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={busy ? undefined : onCancel} statusBarTranslucent>
      <Pressable style={styles.backdrop} onPress={busy ? undefined : onCancel} accessibilityLabel="Dismiss" />
      <View style={[styles.sheet, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityViewIsModal>
        <Text style={[t.sectionTitle, { color: colors.text }]}>{title}</Text>
        {message ? <Text style={[t.body, { color: colors.textSecondary }]}>{message}</Text> : null}
        {children}
        <PrimaryButton label={confirmLabel} onPress={onConfirm} loading={busy} disabled={confirmDisabled} />
        <SecondaryButton label="Cancel" onPress={onCancel} disabled={busy} />
      </View>
    </Modal>
  );
}
const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.45)' },
  sheet: { padding: spacing.lg, paddingBottom: spacing.xl, gap: spacing.md, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, borderWidth: 1 },
});
