import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { DEMO_MODE } from '../../services/endpoints';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

/** Permanent, unmissable label so demo data can never be mistaken for live records. */
export function DemoBanner() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  if (!DEMO_MODE) return null;
  return (
    <View accessibilityRole="alert" style={[styles.bar, { backgroundColor: colors.status.critical.bg, paddingTop: insets.top + spacing.xs }]}>
      <Text style={[t.support, { color: colors.status.critical.fg, fontWeight: '700', textAlign: 'center' }]}>DEMO MODE: fake data, not real visitors</Text>
    </View>
  );
}
const styles = StyleSheet.create({ bar: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xs } });
