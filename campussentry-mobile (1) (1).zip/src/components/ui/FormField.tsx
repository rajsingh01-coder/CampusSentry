import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View, type TextInputProps } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { MIN_TOUCH, radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

interface Props extends Omit<TextInputProps, 'style'> { label: string; error?: string; secureToggle?: boolean }

export const FormField = React.forwardRef<TextInput, Props>(function FormField({ label, error, secureToggle, secureTextEntry, ...rest }, ref) {
  const { colors } = useTheme();
  const [hidden, setHidden] = useState(true);
  const isSecure = secureToggle ? hidden : secureTextEntry;
  return (
    <View style={{ gap: spacing.xs }}>
      <Text style={[t.support, { color: colors.textSecondary, fontWeight: '600' }]}>{label}</Text>
      <View style={[styles.box, { backgroundColor: colors.surface, borderColor: error ? colors.status.critical.solid : colors.border }]}>
        <TextInput ref={ref} {...rest} secureTextEntry={isSecure} accessibilityLabel={label} placeholderTextColor={colors.textSecondary} style={[t.body, styles.input, { color: colors.text }]} />
        {secureToggle ? (
          <Pressable onPress={() => setHidden((h) => !h)} accessibilityRole="button" accessibilityLabel={hidden ? 'Show password' : 'Hide password'} style={styles.toggle}>
            <Ionicons name={hidden ? 'eye-outline' : 'eye-off-outline'} size={22} color={colors.textSecondary} />
          </Pressable>
        ) : null}
      </View>
      {error ? <Text accessibilityLiveRegion="polite" style={[t.support, { color: colors.status.critical.fg }]}>{error}</Text> : null}
    </View>
  );
});
const styles = StyleSheet.create({
  box: { minHeight: MIN_TOUCH, borderWidth: 1, borderRadius: radius.md, flexDirection: 'row', alignItems: 'center' },
  input: { flex: 1, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, minHeight: MIN_TOUCH },
  toggle: { width: MIN_TOUCH, height: MIN_TOUCH, alignItems: 'center', justifyContent: 'center' },
});
