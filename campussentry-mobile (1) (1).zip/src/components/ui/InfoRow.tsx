import React from 'react';
import { Text, View } from 'react-native';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export function InfoRow({ label, value }: { label: string; value?: string | null }) {
  const { colors } = useTheme();
  if (!value) return null;
  return (
    <View style={{ gap: 2 }} accessible accessibilityLabel={`${label}: ${value}`}>
      <Text style={[t.support, { color: colors.textSecondary }]}>{label}</Text>
      <Text selectable style={[t.body, { color: colors.text }]}>{value}</Text>
    </View>
  );
}
