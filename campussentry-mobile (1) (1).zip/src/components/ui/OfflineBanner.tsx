import { Ionicons } from '@expo/vector-icons';
import React, { useSyncExternalStore } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { connectivity } from '../../services/connectivity';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export function OfflineBanner() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const offline = useSyncExternalStore(connectivity.subscribe, connectivity.isOffline);
  if (!offline) return null;
  const c = colors.status.warning;
  return (
    <View accessibilityRole="alert" accessibilityLiveRegion="polite" style={[styles.bar, { backgroundColor: c.bg, paddingTop: insets.top + spacing.sm }]}>
      <Ionicons name="cloud-offline-outline" size={18} color={c.fg} />
      <Text style={[t.support, { color: c.fg, flex: 1, fontWeight: '600' }]}>Can’t reach the server. Nothing can be saved until the connection is back.</Text>
    </View>
  );
}
const styles = StyleSheet.create({ bar: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingHorizontal: spacing.lg, paddingBottom: spacing.sm } });
