import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Linking, StyleSheet, Text, View } from 'react-native';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { PrimaryButton, SecondaryButton } from './Buttons';

interface Props {
  icon?: React.ComponentProps<typeof Ionicons>['name']; title: string; message: string;
  /** false once the OS will no longer show the permission dialog; the only route is system settings */
  canAskAgain: boolean; onAllow: () => void; allowLabel?: string;
}
export function PermissionPrompt({ icon = 'camera-outline', title, message, canAskAgain, onAllow, allowLabel = 'Allow access' }: Props) {
  const { colors } = useTheme();
  return (
    <View style={styles.wrap}>
      <Ionicons name={icon} size={40} color={colors.textSecondary} />
      <Text style={[t.sectionTitle, { color: colors.text, textAlign: 'center' }]}>{title}</Text>
      <Text style={[t.body, { color: colors.textSecondary, textAlign: 'center' }]}>{message}</Text>
      <View style={{ alignSelf: 'stretch', gap: spacing.sm }}>
        {canAskAgain ? <PrimaryButton label={allowLabel} onPress={onAllow} /> : <PrimaryButton label="Open settings" icon="settings-outline" onPress={() => { void Linking.openSettings(); }} />}
        {canAskAgain ? null : <SecondaryButton label="Check again" onPress={onAllow} />}
      </View>
    </View>
  );
}
const styles = StyleSheet.create({ wrap: { alignItems: 'center', gap: spacing.md, padding: spacing.xl } });
