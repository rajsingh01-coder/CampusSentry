import React from 'react';
import { KeyboardAvoidingView, Platform, RefreshControl, ScrollView, StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';

interface Props { children: React.ReactNode; scroll?: boolean; refreshing?: boolean; onRefresh?: () => void; padded?: boolean }

export function Screen({ children, scroll = true, refreshing, onRefresh, padded = true }: Props) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const pad = padded ? spacing.lg : 0;
  const base = { backgroundColor: colors.background };
  if (!scroll) return <View style={[styles.flex, base, { paddingTop: insets.top + spacing.sm, paddingHorizontal: pad }]}>{children}</View>;
  return (
    <KeyboardAvoidingView style={[styles.flex, base]} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingTop: insets.top + spacing.sm, paddingBottom: spacing.xxl, paddingHorizontal: pad, gap: spacing.lg }}
        refreshControl={onRefresh ? <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} tintColor={colors.primary} /> : undefined}
      >
        {children}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({ flex: { flex: 1 } });
