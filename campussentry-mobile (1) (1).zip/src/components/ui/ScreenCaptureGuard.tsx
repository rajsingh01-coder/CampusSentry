import { usePreventScreenCapture } from 'expo-screen-capture';

/** Render while a screen shows personal data: blocks screenshots/recents thumbnails on Android (FLAG_SECURE). */
export function ScreenCaptureGuard(): null {
  usePreventScreenCapture();
  return null;
}
