import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { Chips } from './Chips';

/** Labelled single-choice chips with inline error. Options come from the server config when available. */
export function SelectField<T extends string>({ label, options, value, onChange, error }: { label: string; options: readonly T[]; value: T | null; onChange: (v: T) => void; error?: string }) {
  const { colors } = useTheme();
  return (
    <View style={styles.wrap}>
      <Text style={[t.support, { color: colors.textSecondary, fontWeight: '600' }]}>{label}</Text>
      <Chips label={label} options={options.map((o) => ({ value: o, label: o }))} value={value} onChange={(v) => { if (v) onChange(v); }} />
      {error ? <Text accessibilityLiveRegion="polite" style={[t.support, { color: colors.status.critical.fg }]}>{error}</Text> : null}
    </View>
  );
}
const styles = StyleSheet.create({ wrap: { gap: spacing.xs } });
