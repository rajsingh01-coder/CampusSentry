import React from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { describeError } from '../../services/errors';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { SecondaryButton } from './Buttons';

export function LoadingView({ label = 'Loading' }: { label?: string }) {
  const { colors } = useTheme();
  return (
    <View style={styles.center} accessibilityLiveRegion="polite" accessibilityLabel={label}>
      <ActivityIndicator color={colors.primary} />
      <Text style={[t.support, { color: colors.textSecondary }]}>{label}</Text>
    </View>
  );
}
export function EmptyState({ icon = 'file-tray-outline', title, detail }: { icon?: React.ComponentProps<typeof Ionicons>['name']; title: string; detail?: string }) {
  const { colors } = useTheme();
  return (
    <View style={styles.center}>
      <Ionicons name={icon} size={36} color={colors.textSecondary} />
      <Text style={[t.cardTitle, { color: colors.text, textAlign: 'center' }]}>{title}</Text>
      {detail ? <Text style={[t.support, { color: colors.textSecondary, textAlign: 'center' }]}>{detail}</Text> : null}
    </View>
  );
}
export function ErrorState({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const { colors } = useTheme();
  const d = describeError(error);
  return (
    <View style={styles.center} accessibilityRole="alert">
      <Ionicons name="alert-circle-outline" size={36} color={colors.status.critical.fg} />
      <Text style={[t.cardTitle, { color: colors.text, textAlign: 'center' }]}>{d.title}</Text>
      <Text style={[t.support, { color: colors.textSecondary, textAlign: 'center' }]}>{d.detail}</Text>
      {d.retryable && onRetry ? <View style={{ alignSelf: 'stretch' }}><SecondaryButton label="Try again" onPress={onRetry} icon="refresh-outline" /></View> : null}
    </View>
  );
}
const styles = StyleSheet.create({ center: { alignItems: 'center', justifyContent: 'center', gap: spacing.sm, padding: spacing.xl } });
