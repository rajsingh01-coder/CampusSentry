import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { IdentityClassification, OtpStatus, PresenceState, RequestStatus, VisitorCategory } from '../../domain/types';
import { radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

export type Tone = 'success' | 'warning' | 'critical' | 'info' | 'neutral' | 'indigo' | 'purple' | 'teal';
type Icon = React.ComponentProps<typeof Ionicons>['name'];
interface BadgeSpec { tone: Tone; icon: Icon }

// Same mapping as the admin badge-status.tsx. Status is always icon + text + color, never color alone.
export const REQUEST_BADGE: Record<RequestStatus, BadgeSpec> = {
  'Approved': { tone: 'success', icon: 'checkmark-circle-outline' },
  'Pending Approval': { tone: 'warning', icon: 'time-outline' },
  'Pending Verification': { tone: 'indigo', icon: 'shield-checkmark-outline' },
  'Additional Information Required': { tone: 'purple', icon: 'information-circle-outline' },
  'Rejected': { tone: 'critical', icon: 'close-circle-outline' },
  'Cancelled': { tone: 'neutral', icon: 'ban-outline' },
  'Expired': { tone: 'neutral', icon: 'hourglass-outline' },
};
// "Unknown" is deliberately neutral. It must never look like a rejection or a threat.
export const CLASSIFICATION_BADGE: Record<IdentityClassification, BadgeSpec> = {
  'Known': { tone: 'success', icon: 'person-circle-outline' },
  'Unknown': { tone: 'neutral', icon: 'help-circle-outline' },
  'Verification Required': { tone: 'warning', icon: 'shield-checkmark-outline' },
};
export const OTP_BADGE: Record<OtpStatus, BadgeSpec> = {
  'Verified': { tone: 'success', icon: 'checkmark-circle-outline' },
  'Pending': { tone: 'warning', icon: 'time-outline' },
  'Failed': { tone: 'critical', icon: 'close-circle-outline' },
  'Not Applicable': { tone: 'neutral', icon: 'remove-circle-outline' },
};
export const PRESENCE_BADGE: Record<PresenceState, BadgeSpec> = {
  'Inside Campus': { tone: 'info', icon: 'enter-outline' },
  'Exited': { tone: 'neutral', icon: 'exit-outline' },
  'Not Checked In': { tone: 'neutral', icon: 'walk-outline' },
};
const CATEGORY_TONE: Record<VisitorCategory, Tone> = {
  'Student': 'info', 'Parent/Guardian': 'purple', 'Guest/External Visitor': 'indigo', 'Teaching Staff': 'teal',
  'Non-Teaching Staff': 'teal', 'Vendor': 'warning', 'Other': 'neutral', 'Not specified': 'neutral',
};

export function Badge({ label, tone, icon, prefix = 'Status' }: { label: string; tone: Tone; icon?: Icon; prefix?: string }) {
  const { colors } = useTheme();
  const c = colors.tones[tone];
  return (
    <View style={[styles.badge, { backgroundColor: c.bg }]} accessible accessibilityLabel={`${prefix}: ${label}`}>
      {icon ? <Ionicons name={icon} size={14} color={c.fg} /> : null}
      <Text style={[t.support, { color: c.fg, fontWeight: '600', fontSize: 13 }]}>{label}</Text>
    </View>
  );
}
export const StatusBadge = ({ status }: { status: RequestStatus }) => <Badge label={status} {...REQUEST_BADGE[status]} />;
export const ClassificationBadge = ({ value }: { value: IdentityClassification }) => <Badge label={value} prefix="Identity" {...CLASSIFICATION_BADGE[value]} />;
export const OtpBadge = ({ value }: { value: OtpStatus }) => <Badge label={value === 'Not Applicable' ? 'OTP not required' : `OTP ${value}`} prefix="OTP" {...OTP_BADGE[value]} />;
export const PresenceBadge = ({ value }: { value: PresenceState }) => <Badge label={value} prefix="Presence" {...PRESENCE_BADGE[value]} />;
export const CategoryBadge = ({ value }: { value: VisitorCategory }) => <Badge label={value} prefix="Category" tone={CATEGORY_TONE[value]} />;
const styles = StyleSheet.create({ badge: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, alignSelf: 'flex-start', paddingVertical: 3, paddingHorizontal: spacing.sm, borderRadius: radius.pill } });
