import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import type { ActivityEntry } from '../../services/parsers';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { StatusBadge } from '../ui/StatusBadge';

const META: Record<ActivityEntry['kind'], { label: string; icon: React.ComponentProps<typeof Ionicons>['name'] }> = {
  check_in: { label: 'Checked in', icon: 'log-in-outline' }, check_out: { label: 'Checked out', icon: 'log-out-outline' },
  registered: { label: 'Request registered', icon: 'person-add-outline' }, status_changed: { label: 'Status changed', icon: 'swap-horizontal-outline' },
};
function formatTime(iso: string): string { const d = new Date(iso); return Number.isNaN(d.getTime()) ? iso : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }

export function ActivityItem({ item }: { item: ActivityEntry }) {
  const { colors } = useTheme();
  const m = META[item.kind];
  return (
    <View style={styles.row} accessible accessibilityLabel={`${item.visitorName}, ${m.label}, ${formatTime(item.at)}`}>
      <Ionicons name={m.icon} size={22} color={colors.textSecondary} />
      <View style={{ flex: 1, gap: 2 }}>
        <Text style={[t.body, { color: colors.text, fontWeight: '600' }]} numberOfLines={1}>{item.visitorName}</Text>
        <Text style={[t.support, { color: colors.textSecondary }]}>{m.label} at {formatTime(item.at)}</Text>
      </View>
      {item.status ? <StatusBadge status={item.status} /> : null}
    </View>
  );
}
const styles = StyleSheet.create({ row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, minHeight: 48 } });
