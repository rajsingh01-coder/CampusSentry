import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { IdentityClassification, PresenceState, RequestStatus, VisitorCategory } from '../../domain/types';
import { radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';
import { CategoryBadge, ClassificationBadge, PresenceBadge, StatusBadge } from '../ui/StatusBadge';

interface Props { name: string; category: VisitorCategory; classification?: IdentityClassification; subtitle?: string; status?: RequestStatus; presence?: PresenceState; onPress: () => void }

export function VisitorCard({ name, category, classification, subtitle, status, presence, onPress }: Props) {
  const { colors } = useTheme();
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={`${name}, ${category}${status ? `, ${status}` : ''}`}
      style={({ pressed }) => [styles.card, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.85 : 1 }]}>
      <View style={{ flex: 1, gap: spacing.xs }}>
        <Text style={[t.cardTitle, { color: colors.text }]} numberOfLines={1}>{name}</Text>
        {subtitle ? <Text style={[t.support, { color: colors.textSecondary }]} numberOfLines={1}>{subtitle}</Text> : null}
        <View style={styles.badges}>
          <CategoryBadge value={category} />
          {classification ? <ClassificationBadge value={classification} /> : null}
          {status ? <StatusBadge status={status} /> : null}
          {presence ? <PresenceBadge value={presence} /> : null}
        </View>
      </View>
      <Ionicons name="chevron-forward" size={20} color={colors.textSecondary} />
    </Pressable>
  );
}
const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, borderWidth: 1, borderRadius: radius.lg, padding: spacing.lg, minHeight: 72 },
  badges: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
});
