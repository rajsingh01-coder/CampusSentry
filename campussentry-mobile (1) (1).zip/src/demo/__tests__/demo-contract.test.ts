import assert from 'node:assert/strict';
import { test } from 'node:test';
import { parseConfig, parseCreatedRequest, parseDashboard, parseLogin } from '../../services/parsers.ts';
import { parseHistoryEvent, parseNotification, parsePage, parseRecognition, parseRequestDetail, parseRequestSummary, parseVisitorDetail, parseVisitorRecord } from '../../services/parsers-ops.ts';
import { createDemoBackend, DEMO_OTP_CODE, DEMO_PASSWORD } from '../demo-backend.ts';

const fixed = () => new Date(2026, 9, 18, 10, 0, 0);
function setup() {
  const be = createDemoBackend({ now: fixed });
  const call = (method: string, path: string, token: string | null, body?: unknown) => be.handle({ method, path, token, body });
  const login = (id: string) => parseLogin(call('POST', '/api/auth/login', null, { identifier: id, password: DEMO_PASSWORD }).body);
  return { call, login };
}
const guest = { visitorName: 'Neha Kapoor', phoneNumber: '+91 98000 11122', visitorCategory: 'Guest/External Visitor', identityClassification: 'Unknown', personToMeet: 'Dean/HOD', reasonForMeeting: 'Alumni talk', visitMode: 'Walk-in', gateOrLocation: 'Main Gate 1' };

test('every demo response satisfies the app parsers (frontend/backend contract)', () => {
  const { call, login } = setup();
  const s = login('SEC-101');
  assert.equal(s.user.role, 'Security/Staff');
  parseConfig(call('GET', '/api/config', s.accessToken).body);
  parseDashboard(call('GET', '/api/dashboard', s.accessToken).body);
  const reqs = parsePage(call('GET', '/api/requests?page=1&pageSize=3', s.accessToken).body, parseRequestSummary, 'requests');
  assert.equal(reqs.data.length, 3); assert.ok(reqs.totalPages >= 2);
  const first = reqs.data[0]!;
  parseRequestDetail(call('GET', `/api/requests/${first.requestId}`, s.accessToken).body);
  const vis = parsePage(call('GET', '/api/visitors', s.accessToken).body, parseVisitorRecord, 'visitors');
  parseVisitorDetail(call('GET', `/api/visitors/${vis.data[0]!.visitorId}`, s.accessToken).body);
  const notifs = parsePage(call('GET', '/api/notifications', s.accessToken).body, parseNotification, 'notifications');
  assert.ok(notifs.data.length > 0);
  for (let i = 0; i < 3; i++) parseRecognition(call('POST', '/api/recognition', s.accessToken).body);
});

test('auth: bad password is 401, no token is 401', () => {
  const { call } = setup();
  assert.equal(call('POST', '/api/auth/login', null, { identifier: 'SEC-101', password: 'nope' }).status, 401);
  assert.equal(call('GET', '/api/me', null).status, 401);
});

test('guest flow: OTP gate -> approval is admin-only -> check-in/out rules', () => {
  const { call, login } = setup();
  const sec = login('SEC-101').accessToken, adm = login('ADM-001').accessToken;

  assert.equal(call('POST', '/api/requests', sec, { ...guest, phoneNumber: undefined }).status, 422); // guest needs a phone for the OTP
  const created = parseCreatedRequest(call('POST', '/api/requests', sec, guest).body);
  assert.equal(created.requestStatus, 'Pending Verification'); assert.equal(created.otpStatus, 'Pending');
  const id = created.requestId, vid = created.visitorId!;

  assert.equal(call('POST', `/api/requests/${id}/decision`, adm, { decision: 'Approved' }).status, 409); // not reviewable before OTP
  const wrong = call('POST', `/api/requests/${id}/otp/verify`, sec, { code: '000000' });
  assert.equal(wrong.status, 400); assert.equal((wrong.body as { code: string }).code, 'otp_incorrect');
  assert.equal(parseRequestDetail(call('GET', `/api/requests/${id}`, sec).body).otpStatus, 'Failed');
  assert.equal(call('POST', `/api/requests/${id}/otp/verify`, sec, { code: DEMO_OTP_CODE }).status, 200);
  assert.equal(parseRequestDetail(call('GET', `/api/requests/${id}`, sec).body).requestStatus, 'Pending Approval');
  assert.equal(call('POST', `/api/requests/${id}/otp/verify`, sec, { code: DEMO_OTP_CODE }).status, 409); // cannot re-verify

  assert.equal(call('POST', `/api/visitors/${vid}/check-in`, sec, { gate: 'Main Gate 1' }).status, 409); // not approved yet
  assert.equal(call('POST', `/api/requests/${id}/decision`, sec, { decision: 'Approved' }).status, 403); // gate staff cannot approve
  assert.equal(call('POST', `/api/requests/${id}/decision`, adm, { decision: 'Rejected' }).status, 422); // reason required
  assert.equal(call('POST', `/api/requests/${id}/decision`, adm, { decision: 'Approved' }).status, 200);
  assert.equal(call('POST', `/api/requests/${id}/decision`, adm, { decision: 'Rejected', notes: 'x' }).status, 409); // terminal

  assert.equal(call('POST', `/api/visitors/${vid}/check-out`, sec, { gate: 'g' }).status, 409); // not inside
  assert.equal(call('POST', `/api/visitors/${vid}/check-in`, sec, { gate: 'Main Gate 1' }).status, 200);
  assert.equal(call('POST', `/api/visitors/${vid}/check-in`, sec, { gate: 'Main Gate 1' }).status, 409); // already inside
  assert.equal(call('POST', `/api/visitors/${vid}/check-out`, sec, { gate: 'Main Gate 1' }).status, 200);
  assert.equal(call('POST', `/api/visitors/${vid}/check-in`, sec, { gate: 'Main Gate 1' }).status, 200); // re-entry allowed
  assert.equal(call('GET', `/api/visitors/${vid}/history`, sec).status, 403); // gate staff: no history by default
  const hist = parsePage(call('GET', `/api/visitors/${vid}/history`, adm).body, parseHistoryEvent, 'history');
  assert.equal(hist.data.length, 3);
});

test('OTP lockout after 5 wrong codes returns 429 with retryAfterSeconds', () => {
  const { call, login } = setup();
  const sec = login('SEC-101').accessToken;
  const id = parseCreatedRequest(call('POST', '/api/requests', sec, guest).body).requestId;
  let last = call('POST', `/api/requests/${id}/otp/verify`, sec, { code: '1' });
  for (let i = 0; i < 4; i++) last = call('POST', `/api/requests/${id}/otp/verify`, sec, { code: '1' });
  assert.equal(last.status, 429); assert.equal((last.body as { retryAfterSeconds: number }).retryAfterSeconds, 30);
  assert.equal(call('POST', `/api/requests/${id}/otp/verify`, sec, { code: DEMO_OTP_CODE }).status, 429); // locked even for the right code
});

test('non-guest request skips OTP; known identity names are auto-classified Known', () => {
  const { call, login } = setup();
  const sec = login('SEC-101').accessToken;
  const c = parseCreatedRequest(call('POST', '/api/requests', sec, { ...guest, visitorName: 'Aditi Verma', visitorCategory: 'Student', phoneNumber: undefined }).body);
  assert.equal(c.requestStatus, 'Pending Approval'); assert.equal(c.otpStatus, 'Not Applicable');
  assert.equal(parseRequestDetail(call('GET', `/api/requests/${c.requestId}`, sec).body).identityClassification, 'Known');
});

test('phone search is permission-gated; unknown route is 404', () => {
  const { call, login } = setup();
  assert.equal(call('GET', '/api/visitors?q=987&field=phone', login('SEC-101').accessToken).status, 403);
  assert.equal(call('GET', '/api/visitors?q=987&field=phone', login('SUP-201').accessToken).status, 200);
  assert.equal(call('GET', '/api/nope', login('SEC-101').accessToken).status, 404);
});

test('notifications: mark one and all as read', () => {
  const { call, login } = setup();
  const t = login('SEC-101').accessToken;
  const list = () => parsePage(call('GET', '/api/notifications', t).body, parseNotification, 'n').data;
  const unread = list().filter((n) => !n.isRead);
  assert.ok(unread.length > 1);
  call('POST', `/api/notifications/${unread[0]!.id}/read`, t);
  assert.equal(list().filter((n) => !n.isRead).length, unread.length - 1);
  call('POST', '/api/notifications/read-all', t);
  assert.equal(list().filter((n) => !n.isRead).length, 0);
});

test('assistant proposes, and only the confirm call changes data', () => {
  const { call, login } = setup();
  const t = login('SEC-101').accessToken;
  const r = call('POST', '/api/assistant/chat', t, { message: 'check out Keshav' }).body as { proposal?: { id: string } };
  assert.ok(r.proposal);
  assert.equal(parseVisitorDetail(call('GET', `/api/visitors/${r.proposal!.id}`, t).body).presence, 'Inside Campus');
  assert.equal(call('POST', '/api/assistant/confirm', t, { proposalId: r.proposal!.id }).status, 200);
  assert.equal(parseVisitorDetail(call('GET', `/api/visitors/${r.proposal!.id}`, t).body).presence, 'Exited');
});
