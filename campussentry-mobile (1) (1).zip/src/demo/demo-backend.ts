// DEMO ONLY: an in-app fake backend that mimics the Admin Web App's semantics (src/lib/workflow.ts, demo-store.ts).
// It exists so the staff app can be tried end to end before the real backend is integrated. All data is invented.
// Pure TypeScript (no React Native imports) so it is unit-tested with node. Reset on every app start.
import { ROLE_DEFAULT_PERMISSIONS } from '../domain/role-permissions.ts';
import { ADMIN_DEFAULT_AUTHORITIES, VISITOR_CATEGORIES, type IdentityClassification, type OtpStatus, type PresenceState, type RequestStatus, type StaffRole, type VisitMode, type VisitorCategory } from '../domain/types.ts';
import { canReviewRequest, requiresOtp } from '../domain/workflow.ts';
import { ENDPOINTS, type EndpointName } from '../services/endpoints.ts';

export const DEMO_OTP_CODE = '123456';
export const DEMO_PASSWORD = 'demo1234';
export const DEMO_ACCOUNTS = [
  { identifier: 'SEC-101', label: 'Security/Staff', role: 'Security/Staff' },
  { identifier: 'SUP-201', label: 'Supervisor', role: 'Supervisor' },
  { identifier: 'ADM-001', label: 'Admin', role: 'Admin' },
] as const;
const KNOWN_IDENTITIES = ['keshav', 'praveen', 'raj', 'aditi', 'supriya']; // names the admin demo auto-classifies as Known

interface Staff { staffId: string; name: string; email: string; department: string; role: StaffRole; assignedGate: string }
const STAFF: Staff[] = [
  { staffId: 'SEC-101', name: 'Ramesh Kumar', email: 'ramesh.kumar@campus.example', department: 'Security', role: 'Security/Staff', assignedGate: 'Main Gate 1' },
  { staffId: 'SUP-201', name: 'Anita Verma', email: 'anita.verma@campus.example', department: 'Security', role: 'Supervisor', assignedGate: 'North Gate 2' },
  { staffId: 'ADM-001', name: 'Dr. Rohit Mehra', email: 'rohit.mehra@campus.example', department: 'Administration', role: 'Admin', assignedGate: 'Main Gate 1' },
];
const GATES = ['Main Gate 1', 'North Gate 2', 'South Service Gate 3'];

interface Visitor { visitorId: string; name: string; phone?: string; category: VisitorCategory; classification: IdentityClassification; presence: PresenceState }
interface Review { decision: string; by: string; at: string; notes?: string }
interface Req {
  requestId: string; visitorId: string; visitorName: string; phoneNumber?: string; visitorCategory: VisitorCategory; identityClassification: IdentityClassification;
  personToMeet: string; department?: string; reasonForMeeting: string; visitMode: VisitMode; requestedDate: string; requestedTime: string; appointmentDetails?: string;
  gateOrLocation: string; staffNotes?: string; submittedBy: string; requestStatus: RequestStatus; otpStatus: OtpStatus; otpAttempts: number; lockedUntil: number;
  priority: 'Normal' | 'High' | 'Urgent'; createdAt: string; reviews: Review[];
}
interface Ev { id: string; visitorId: string; kind: 'check_in' | 'check_out'; at: string; gate: string; staffName: string; source: string }
interface Notif { id: string; requestId: string; createdAt: string; isRead: boolean }

export interface DemoRequest { method: string; path: string; token?: string | null; body?: unknown }
export interface DemoResponse { status: number; body: unknown }

type Json = Record<string, unknown>;
const isObj = (v: unknown): v is Json => typeof v === 'object' && v !== null && !Array.isArray(v);
const s = (v: unknown): string | undefined => (typeof v === 'string' && v.trim() ? v.trim() : undefined);

export function createDemoBackend(opts: { now?: () => Date } = {}) {
  const now = opts.now ?? (() => new Date());
  const iso = (offsetMin = 0) => new Date(now().getTime() + offsetMin * 60000).toISOString();
  let seq = 1040, evSeq = 0, notifSeq = 0, recogCount = 0;
  const visitors: Visitor[] = [];
  const requests: Req[] = [];
  const events: Ev[] = [];
  const notifs: Notif[] = [];

  const localDate = () => { const d = now(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
  const visitorOf = (id: string) => visitors.find((v) => v.visitorId === id);
  const latestRequest = (visitorId: string) => requests.filter((r) => r.visitorId === visitorId).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  const staffOf = (token?: string | null) => STAFF.find((u) => token === `demo-token-${u.staffId}`);
  const permsOf = (u: Staff) => ROLE_DEFAULT_PERMISSIONS[u.role];

  function seedVisitor(name: string, category: VisitorCategory, classification: IdentityClassification, phone?: string): Visitor {
    const v: Visitor = { visitorId: `VIS-${String(visitors.length + 1).padStart(4, '0')}`, name, phone, category, classification, presence: 'Not Checked In' };
    visitors.push(v); return v;
  }
  function seedRequest(v: Visitor, p: Partial<Req> & Pick<Req, 'personToMeet' | 'reasonForMeeting' | 'requestStatus' | 'otpStatus'>, minutesAgo: number): Req {
    const r: Req = {
      requestId: `REQ-${++seq}`, visitorId: v.visitorId, visitorName: v.name, phoneNumber: v.phone, visitorCategory: v.category, identityClassification: v.classification,
      visitMode: 'Walk-in', requestedDate: localDate(), requestedTime: 'Now', gateOrLocation: 'Main Gate 1', submittedBy: 'SEC-101', otpAttempts: 0, lockedUntil: 0,
      priority: 'Normal', createdAt: iso(-minutesAgo), reviews: [], ...p,
    };
    requests.push(r);
    notifs.push({ id: `N-${++notifSeq}`, requestId: r.requestId, createdAt: r.createdAt, isRead: minutesAgo > 120 });
    return r;
  }
  function logEvent(v: Visitor, kind: Ev['kind'], gate: string, staffName: string, minutesAgo = 0) {
    events.push({ id: `EV-${++evSeq}`, visitorId: v.visitorId, kind, at: iso(-minutesAgo), gate, staffName, source: 'Staff Mobile Manual (Simulated)' });
    v.presence = kind === 'check_in' ? 'Inside Campus' : 'Exited';
  }

  // Seed data: invented, but shaped like the admin demo (known identities, one request per status).
  const keshav = seedVisitor('Keshav Sharma', 'Student', 'Known', '+91 98765 43210');
  seedRequest(keshav, { personToMeet: 'Dr. Sandeep Chawla', department: 'Computer Science', reasonForMeeting: 'Project submission', requestStatus: 'Approved', otpStatus: 'Not Applicable', reviews: [{ decision: 'Approved', by: 'Dr. Rohit Mehra', at: iso(-200) }] }, 240);
  logEvent(keshav, 'check_in', 'Main Gate 1', 'Ramesh Kumar', 90);
  const meenakshi = seedVisitor('Meenakshi Iyer', 'Parent/Guardian', 'Known', '+91 91234 56780');
  seedRequest(meenakshi, { personToMeet: 'Principal/Director', reasonForMeeting: 'Parent-teacher meeting', requestStatus: 'Approved', otpStatus: 'Not Applicable', reviews: [{ decision: 'Approved', by: 'Dr. Rohit Mehra', at: iso(-150) }] }, 180);
  const sandeep = seedVisitor('Vikas Nambiar', 'Vendor', 'Unknown', '+91 90000 11122');
  seedRequest(sandeep, { personToMeet: 'Administrator', reasonForMeeting: 'Lab equipment delivery', requestStatus: 'Pending Approval', otpStatus: 'Not Applicable', priority: 'High' }, 45);
  const guest = seedVisitor('Ritu Malhotra', 'Guest/External Visitor', 'Verification Required', '+91 98111 22233');
  seedRequest(guest, { personToMeet: 'Dean/HOD', reasonForMeeting: 'Guest lecture coordination', requestStatus: 'Pending Verification', otpStatus: 'Pending', priority: 'Urgent' }, 20);
  const raj = seedVisitor('Raj Patel', 'Student', 'Known', '+91 97000 33344');
  seedRequest(raj, { personToMeet: 'Dean/HOD', reasonForMeeting: 'Bonafide certificate', requestStatus: 'Additional Information Required', otpStatus: 'Not Applicable', reviews: [{ decision: 'Additional Information Required', by: 'Dr. Rohit Mehra', at: iso(-30), notes: 'Please add the student ID number.' }] }, 90);
  const aditi = seedVisitor('Aditi Rao', 'Teaching Staff', 'Known');
  seedRequest(aditi, { personToMeet: 'Administrator', reasonForMeeting: 'Equipment pickup', requestStatus: 'Rejected', otpStatus: 'Not Applicable', reviews: [{ decision: 'Rejected', by: 'Dr. Rohit Mehra', at: iso(-300), notes: 'Duplicate request.' }] }, 330);

  const err = (status: number, message: string, code?: string, extra: Json = {}): DemoResponse => ({ status, body: { message, code, ...extra } });
  const ok = (body: unknown, status = 200): DemoResponse => ({ status, body });
  const page = <T,>(all: T[], q: Record<string, string>, map: (x: T) => unknown): DemoResponse => {
    const pageSize = Math.max(1, Number(q.pageSize) || 20), p = Math.max(1, Number(q.page) || 1);
    return ok({ data: all.slice((p - 1) * pageSize, p * pageSize).map(map), total: all.length, page: p, pageSize, totalPages: Math.max(1, Math.ceil(all.length / pageSize)) });
  };

  const reqSummary = (r: Req) => ({ requestId: r.requestId, visitorId: r.visitorId, visitorName: r.visitorName, visitorCategory: r.visitorCategory, identityClassification: r.identityClassification, requestStatus: r.requestStatus, otpStatus: r.otpStatus, createdAt: r.createdAt, personToMeet: r.personToMeet, priority: r.priority });
  const reqDetail = (r: Req) => ({ ...reqSummary(r), phoneNumber: r.phoneNumber, department: r.department, reasonForMeeting: r.reasonForMeeting, visitMode: r.visitMode, requestedDate: r.requestedDate, requestedTime: r.requestedTime, appointmentDetails: r.appointmentDetails, gateOrLocation: r.gateOrLocation, submittedBy: r.submittedBy, staffNotes: r.staffNotes, presence: visitorOf(r.visitorId)?.presence, reviews: r.reviews });
  const visRecord = (v: Visitor) => { const l = latestRequest(v.visitorId); const last = events.filter((e) => e.visitorId === v.visitorId).sort((a, b) => b.at.localeCompare(a.at))[0]; return { visitorId: v.visitorId, visitorName: v.name, phoneNumber: v.phone, visitorCategory: v.category, identityClassification: v.classification, latestRequestId: l?.requestId, requestStatus: l?.requestStatus, presence: v.presence, lastActivityAt: last?.at ?? l?.createdAt }; };
  const sortedDesc = <T extends { createdAt: string }>(l: T[]) => [...l].sort((a, b) => b.createdAt.localeCompare(a.createdAt));

  function matchRoute(method: string, path: string): { name: EndpointName; params: Record<string, string> } | null {
    for (const [name, r] of Object.entries(ENDPOINTS)) {
      if (r.method !== method) continue;
      const names: string[] = [];
      const re = new RegExp('^' + r.path.replace(/:([A-Za-z_]\w*)/g, (_m, k: string) => { names.push(k); return '([^/]+)'; }) + '$');
      const m = re.exec(path);
      if (m) return { name: name as EndpointName, params: Object.fromEntries(names.map((n, i) => [n, decodeURIComponent(m[i + 1] ?? '')])) };
    }
    return null;
  }

  function handle(req: DemoRequest): DemoResponse {
    const [rawPath = '', qs = ''] = req.path.split('?');
    const query: Record<string, string> = {};
    new URLSearchParams(qs).forEach((v, k) => { query[k] = v; });
    const route = matchRoute(req.method.toUpperCase(), rawPath);
    if (!route) return err(404, 'Unknown demo route.');
    const body: Json = isObj(req.body) ? req.body : {};
    const { name, params } = route;

    if (name === 'login') {
      const id = (s(body.identifier) ?? '').toLowerCase();
      const user = STAFF.find((u) => u.staffId.toLowerCase() === id || u.email === id);
      if (!user || body.password !== DEMO_PASSWORD) return err(401, 'Staff ID or password is incorrect.', 'invalid_credentials');
      return ok({ accessToken: `demo-token-${user.staffId}`, user: { ...user, permissions: permsOf(user) } });
    }
    const me = staffOf(req.token);
    if (!me) return err(401, 'Your session has expired.', 'unauthenticated');
    const has = (p: ReturnType<typeof permsOf>[number]) => permsOf(me).includes(p);
    const deny = () => err(403, 'Your account is not allowed to do this.', 'forbidden');

    switch (name) {
      case 'logout': return ok({});
      case 'me': return ok({ ...me, permissions: permsOf(me) });
      case 'config': return ok({ visitorCategories: [...VISITOR_CATEGORIES], authorizedMeetingAuthorities: [...ADMIN_DEFAULT_AUTHORITIES], requireOtpForGuests: true, gates: GATES });
      case 'dashboard': {
        const today = localDate();
        const recent = [
          ...requests.map((r) => ({ id: `reg-${r.requestId}`, visitorName: r.visitorName, kind: 'registered', at: r.createdAt, requestStatus: r.requestStatus })),
          ...events.map((e) => ({ id: e.id, visitorName: visitorOf(e.visitorId)?.name ?? 'Visitor', kind: e.kind, at: e.at })),
        ].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 8);
        return ok({ totalToday: requests.filter((r) => r.createdAt.slice(0, 10) === today || r.requestedDate === today).length, insideNow: visitors.filter((v) => v.presence === 'Inside Campus').length, pendingApproval: requests.filter((r) => r.requestStatus === 'Pending Approval').length, recent });
      }
      case 'requestsList': {
        const q = (query.q ?? '').toLowerCase();
        let l = sortedDesc(requests);
        if (query.status) l = l.filter((r) => r.requestStatus === query.status);
        if (query.classification) l = l.filter((r) => r.identityClassification === query.classification);
        if (q) l = l.filter((r) => r.visitorName.toLowerCase().includes(q) || r.requestId.toLowerCase().includes(q));
        return page(l, query, reqSummary);
      }
      case 'requestDetail': { const r = requests.find((x) => x.requestId === params.requestId); return r ? ok(reqDetail(r)) : err(404, 'Request not found.'); }
      case 'requestCreate': {
        if (!has('request.create')) return deny();
        const visitorName = s(body.visitorName), category = VISITOR_CATEGORIES.find((c) => c === body.visitorCategory), personToMeet = s(body.personToMeet), reason = s(body.reasonForMeeting), gate = s(body.gateOrLocation);
        const classification = (['Known', 'Unknown', 'Verification Required'] as const).find((c) => c === body.identityClassification);
        const mode = body.visitMode === 'Scheduled' ? 'Scheduled' : body.visitMode === 'Walk-in' ? 'Walk-in' : undefined;
        if (!visitorName || !category || !personToMeet || !reason || !gate || !classification || !mode) return err(422, 'Some required fields are missing or invalid.', 'validation');
        const phone = s(body.phoneNumber);
        const otp = requiresOtp(category, true);
        if (otp && !phone) return err(422, 'A mobile number is required to send the OTP.', 'validation');
        const date = mode === 'Walk-in' ? localDate() : s(body.requestedDate) ?? localDate();
        const time = mode === 'Walk-in' ? 'Now' : s(body.requestedTime) ?? 'Now';
        let v = visitors.find((x) => x.name.toLowerCase() === visitorName.toLowerCase() && (x.phone ?? '') === (phone ?? ''));
        const finalClass: IdentityClassification = KNOWN_IDENTITIES.includes(visitorName.split(/\s+/)[0]?.toLowerCase() ?? '') ? 'Known' : classification;
        if (!v) v = seedVisitor(visitorName, category, finalClass, phone);
        const r = seedRequest(v, {
          personToMeet, reasonForMeeting: reason, department: s(body.department), appointmentDetails: s(body.appointmentDetails), staffNotes: s(body.staffNotes), visitMode: mode, requestedDate: date, requestedTime: time,
          gateOrLocation: gate, submittedBy: me.staffId, identityClassification: finalClass, visitorCategory: category,
          requestStatus: otp ? 'Pending Verification' : 'Pending Approval', otpStatus: otp ? 'Pending' : 'Not Applicable',
        }, 0);
        return ok({ requestId: r.requestId, visitorId: v.visitorId, requestStatus: r.requestStatus, otpStatus: r.otpStatus }, 201);
      }
      case 'requestDecision': {
        if (!has('request.review')) return deny();
        const r = requests.find((x) => x.requestId === params.requestId);
        if (!r) return err(404, 'Request not found.');
        const decision = (['Approved', 'Rejected', 'Additional Information Required'] as const).find((d) => d === body.decision);
        if (!decision) return err(422, 'Unknown decision.', 'validation');
        if (!canReviewRequest(r.requestStatus) || decision === r.requestStatus) return err(409, `A request that is “${r.requestStatus}” cannot be changed this way.`, 'conflict');
        const notes = s(body.notes);
        if (decision === 'Rejected' && !notes) return err(422, 'A reason is required to reject a request.', 'validation');
        r.requestStatus = decision; r.reviews.push({ decision, by: me.name, at: iso(), notes });
        return ok(reqDetail(r));
      }
      case 'otpVerify': case 'otpResend': {
        const r = requests.find((x) => x.requestId === params.requestId);
        if (!r) return err(404, 'Request not found.');
        if (!(r.requestStatus === 'Pending Verification' && (r.otpStatus === 'Pending' || r.otpStatus === 'Failed'))) return err(409, 'This request is not waiting for an OTP.', 'conflict');
        if (r.lockedUntil > now().getTime()) return err(429, 'Too many wrong codes. Wait before trying again.', 'rate_limited', { retryAfterSeconds: Math.ceil((r.lockedUntil - now().getTime()) / 1000) });
        if (name === 'otpResend') { r.otpAttempts = 0; return ok({ sent: true }); }
        if (s(body.code) === DEMO_OTP_CODE) { r.otpStatus = 'Verified'; r.requestStatus = 'Pending Approval'; return ok({ verified: true, requestStatus: r.requestStatus }); }
        r.otpStatus = 'Failed'; r.otpAttempts += 1;
        if (r.otpAttempts >= 5) { r.lockedUntil = now().getTime() + 30000; r.otpAttempts = 0; return err(429, 'Too many wrong codes. Wait before trying again.', 'rate_limited', { retryAfterSeconds: 30 }); }
        return err(400, 'That code is incorrect.', 'otp_incorrect');
      }
      case 'visitorsList': {
        if (query.field === 'phone' && query.q && !has('visitor.search_phone')) return deny();
        const q = (query.q ?? '').toLowerCase();
        let l = visitors.map(visRecord);
        if (query.category) l = l.filter((v) => v.visitorCategory === query.category);
        if (query.classification) l = l.filter((v) => v.identityClassification === query.classification);
        if (query.status) l = l.filter((v) => v.requestStatus === query.status);
        if (query.presence) l = l.filter((v) => v.presence === query.presence);
        if (q) l = l.filter((v) => (query.field === 'phone' ? (v.phoneNumber ?? '').replace(/\D/g, '').includes(q.replace(/\D/g, '')) : query.field === 'id' ? v.visitorId.toLowerCase().includes(q) || (v.latestRequestId ?? '').toLowerCase().includes(q) : v.visitorName.toLowerCase().includes(q)));
        if (query.from) l = l.filter((v) => (v.lastActivityAt ?? '') >= query.from!);
        if (query.to) l = l.filter((v) => (v.lastActivityAt ?? '') <= query.to!);
        l.sort((a, b) => (b.lastActivityAt ?? '').localeCompare(a.lastActivityAt ?? ''));
        return page(l, query, (x) => x);
      }
      case 'visitorDetail': { const v = visitorOf(params.visitorId ?? ''); return v ? ok({ ...visRecord(v), requests: sortedDesc(requests.filter((r) => r.visitorId === v.visitorId)).map(reqSummary) }) : err(404, 'Visitor not found.'); }
      case 'visitorHistory': {
        if (!has('history.view')) return deny();
        const l = events.filter((e) => e.visitorId === params.visitorId).sort((a, b) => b.at.localeCompare(a.at));
        return page(l, query, (e) => e);
      }
      case 'visitorCheckIn': case 'visitorCheckOut': {
        const isIn = name === 'visitorCheckIn';
        if (!has(isIn ? 'visitor.checkin' : 'visitor.checkout')) return deny();
        const v = visitorOf(params.visitorId ?? '');
        if (!v) return err(404, 'Visitor not found.');
        const gate = s(body.gate) ?? me.assignedGate;
        if (isIn) {
          if (v.presence === 'Inside Campus') return err(409, 'Visitor is already inside campus.', 'conflict');
          if (latestRequest(v.visitorId)?.requestStatus !== 'Approved') return err(409, 'Only visitors with an approved request can check in.', 'conflict');
        } else if (v.presence !== 'Inside Campus') return err(409, 'Visitor is not recorded as inside campus.', 'conflict');
        logEvent(v, isIn ? 'check_in' : 'check_out', gate, me.name);
        return ok(visRecord(v));
      }
      case 'notificationsList': {
        return page(sortedDesc(notifs), query, (n) => {
          const r = requests.find((x) => x.requestId === n.requestId)!;
          return { id: n.id, requestId: n.requestId, visitorName: r.visitorName, visitorCategory: r.visitorCategory, identityClassification: r.identityClassification, personToMeet: r.personToMeet, reasonForMeeting: r.reasonForMeeting, requestStatus: r.requestStatus, otpStatus: r.otpStatus, priority: r.priority, createdAt: n.createdAt, isRead: n.isRead };
        });
      }
      case 'notificationRead': { const n = notifs.find((x) => x.id === params.notificationId); if (!n) return err(404, 'Notification not found.'); n.isRead = true; return ok({}); }
      case 'notificationsReadAll': notifs.forEach((n) => { n.isRead = true; }); return ok({});
      case 'recognize': {
        const step = recogCount++ % 3;
        if (step === 0) { const v = keshav; return ok({ classification: 'Known', sessionId: `demo-${recogCount}`, match: { visitorId: v.visitorId, name: v.name, confidence: 0.93 } }); }
        if (step === 1) return ok({ classification: 'Unknown', sessionId: `demo-${recogCount}` });
        return ok({ classification: 'Verification Required', sessionId: `demo-${recogCount}`, match: { confidence: 0.58 } });
      }
      case 'assistantChat': {
        const text = (s(body.message) ?? '').toLowerCase();
        const outM = /check\s*out\s+(.+)/.exec(text);
        if (outM) {
          const target = visitors.find((v) => v.presence === 'Inside Campus' && v.name.toLowerCase().includes((outM[1] ?? '').trim()));
          if (!target) return ok({ reply: 'I could not find an inside visitor with that name.' });
          if (!has('visitor.checkout')) return ok({ reply: 'Your account is not allowed to check visitors out.' });
          return ok({ reply: `Found ${target.name}. Confirm to record the check-out.`, proposal: { id: target.visitorId, title: `Check out ${target.name}`, description: `Records an exit at ${me.assignedGate}.` } });
        }
        if (/inside|how many/.test(text)) return ok({ reply: `${visitors.filter((v) => v.presence === 'Inside Campus').length} visitor(s) are recorded as inside campus right now.` });
        if (/pending/.test(text)) return ok({ reply: `${requests.filter((r) => r.requestStatus === 'Pending Approval').length} request(s) are waiting for approval.` });
        return ok({ reply: 'Demo assistant. Try “how many visitors are inside?”, “pending requests” or “check out Keshav”.' });
      }
      case 'assistantConfirm': {
        if (!has('visitor.checkout')) return deny();
        const v = visitorOf(s(body.proposalId) ?? '');
        if (!v || v.presence !== 'Inside Campus') return err(409, 'That visitor is no longer inside campus.', 'conflict');
        logEvent(v, 'check_out', me.assignedGate, me.name);
        return ok({ reply: `${v.name} is now checked out.` });
      }
      default: return err(404, 'Unknown demo route.');
    }
  }
  return { handle };
}
export type DemoBackend = ReturnType<typeof createDemoBackend>;
