import { createDemoBackend } from './demo-backend';

// fetch-compatible transport for demo mode. State lives in memory and resets when the app restarts.
let backend: ReturnType<typeof createDemoBackend> | null = null;
const LATENCY_MS = 200;

export async function demoFetch(url: string, init: { method?: string; headers?: Record<string, string>; body?: unknown; signal?: AbortSignal } = {}): Promise<Response> {
  backend ??= createDemoBackend();
  await new Promise<void>((resolve, reject) => {
    const t = setTimeout(resolve, LATENCY_MS);
    init.signal?.addEventListener('abort', () => { clearTimeout(t); reject(new Error('aborted')); });
  });
  const auth = init.headers?.Authorization;
  let body: unknown;
  if (typeof init.body === 'string') { try { body = JSON.parse(init.body); } catch { body = undefined; } }
  const path = url.replace(/^https?:\/\/[^/]+/, '');
  const res = backend.handle({ method: init.method ?? 'GET', path, token: auth?.startsWith('Bearer ') ? auth.slice(7) : null, body });
  return new Response(JSON.stringify(res.body), { status: res.status, headers: { 'Content-Type': 'application/json' } });
}
