import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ApiError } from '../../services/errors.ts';
import { classifyOtpError, isOtpSubmittable, sanitizeOtp } from '../otp.ts';
import { mergePage } from '../pagination.ts';
import { can } from '../permissions.ts';
import { nextActionsFor, registerLabelFor } from '../recognition.ts';
import { DEFAULT_FILTERS, filtersAreDefault } from '../records-filters.ts';
import { ROLE_DEFAULT_PERMISSIONS } from '../role-permissions.ts';

test('otp error classification', () => {
  assert.equal(classifyOtpError(new ApiError('validation', 'x', 400, undefined, { code: 'otp_incorrect' })).kind, 'incorrect');
  assert.equal(classifyOtpError(new ApiError('validation', 'x', 400, undefined, { code: 'otp_expired' })).kind, 'expired');
  const r = classifyOtpError(new ApiError('rate_limited', 'x', 429, undefined, { retryAfterSeconds: 30 }));
  assert.deepEqual(r, { kind: 'rate_limited', retryAfterSeconds: 30 });
  assert.equal(classifyOtpError(new Error('boom')).kind, 'other');
});
test('otp input', () => { assert.equal(sanitizeOtp('12-34 56ab789'), '12345678'); assert.equal(isOtpSubmittable('123'), false); assert.equal(isOtpSubmittable('1234'), true); });
test('mergePage drops duplicates', () => { assert.deepEqual(mergePage([{ id: 'a' }, { id: 'b' }], [{ id: 'b' }, { id: 'c' }], (x) => x.id).map((x) => x.id), ['a', 'b', 'c']); });
test('recognition never blocks: every classification can register, Unknown included', () => {
  for (const c of ['Known', 'Unknown', 'Verification Required'] as const) { assert.ok(nextActionsFor(c).includes('register_visit')); assert.ok(registerLabelFor(c)); }
});
test('filters default detection', () => { assert.equal(filtersAreDefault(DEFAULT_FILTERS), true); assert.equal(filtersAreDefault({ ...DEFAULT_FILTERS, status: 'Approved' }), false); });
test('role defaults: approval is Admin-only, phone search is not for gate staff', () => {
  const mk = (role: keyof typeof ROLE_DEFAULT_PERMISSIONS) => ({ staffId: 's', name: 'n', role, permissions: ROLE_DEFAULT_PERMISSIONS[role], permissionSource: 'role-default' as const });
  assert.equal(can(mk('Security/Staff'), 'request.review'), false);
  assert.equal(can(mk('Supervisor'), 'request.review'), false);
  assert.equal(can(mk('Admin'), 'request.review'), true);
  assert.equal(can(mk('Security/Staff'), 'visitor.checkin'), true);
  assert.equal(can(mk('Security/Staff'), 'visitor.search_phone'), false);
  assert.equal(can(null, 'visitor.checkin'), false);
});
