import assert from 'node:assert/strict';
import { test } from 'node:test';
import { getAllowedActions } from '../presence.ts';

test('approved and not inside: can check in, cannot check out', () => {
  const a = getAllowedActions({ requestStatus: 'Approved', presence: 'Not Checked In' });
  assert.equal(a.canCheckIn, true); assert.equal(a.canCheckOut, false);
});
test('re-entry after exit is allowed (admin rule)', () => { assert.equal(getAllowedActions({ requestStatus: 'Approved', presence: 'Exited' }).canCheckIn, true); });
test('inside: cannot check in again, can check out', () => {
  const a = getAllowedActions({ requestStatus: 'Approved', presence: 'Inside Campus' });
  assert.equal(a.canCheckIn, false); assert.equal(a.canCheckOut, true); assert.ok(a.checkInBlockedReason);
});
test('non-approved requests never check in, and say why', () => {
  for (const s of ['Pending Approval', 'Pending Verification', 'Rejected', 'Additional Information Required', 'Cancelled', 'Expired'] as const) {
    const a = getAllowedActions({ requestStatus: s, presence: 'Not Checked In' });
    assert.equal(a.canCheckIn, false, s); assert.match(a.checkInBlockedReason ?? '', new RegExp(s));
  }
});
