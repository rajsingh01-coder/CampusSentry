import assert from 'node:assert/strict';
import { test } from 'node:test';
import { hasErrors, maskPhone, normalizePhone, validatePhone, validateRegistration, type RegistrationInput } from '../validation.ts';

const base: RegistrationInput = { fullName: 'Ritu Malhotra', phone: '', category: 'Student', classification: 'Unknown', personToMeet: 'Dean/HOD', department: '', reason: 'Bonafide', visitMode: 'Walk-in', requestedDate: '', requestedTime: '', appointmentDetails: '', gate: 'Main Gate 1', staffNotes: '' };
const now = new Date(2026, 9, 18, 10, 0);

test('a minimal walk-in is valid and phone is optional', () => { assert.deepEqual(validateRegistration(base, { now }), {}); });
test('phone becomes mandatory when OTP is required', () => {
  const e = validateRegistration({ ...base, category: 'Guest/External Visitor' }, { otpRequired: true, now });
  assert.match(e.phone ?? '', /OTP/);
});
test('phone format', () => {
  assert.equal(validatePhone('+91 98765 43210'), undefined);
  assert.ok(validatePhone('12345'));
  assert.ok(validatePhone('98765abc43'));
  assert.equal(validatePhone('', undefined, false), undefined);
  assert.equal(normalizePhone('+91 98765-43210'), '+919876543210');
});
test('required fields are reported', () => {
  const e = validateRegistration({ ...base, fullName: ' ', category: null, personToMeet: '', reason: 'ab', gate: '' }, { now });
  for (const k of ['fullName', 'category', 'personToMeet', 'reason', 'gate'] as const) assert.ok(e[k], k);
});
test('scheduled visits need a valid, non-past date and a 24h time; walk-ins ignore them', () => {
  const sched = { ...base, visitMode: 'Scheduled' as const };
  assert.ok(validateRegistration({ ...sched, requestedDate: '2026-10-17', requestedTime: '10:00' }, { now }).requestedDate);
  assert.ok(validateRegistration({ ...sched, requestedDate: '2026-02-31', requestedTime: '10:00' }, { now }).requestedDate);
  assert.ok(validateRegistration({ ...sched, requestedDate: '2026-10-20', requestedTime: '25:00' }, { now }).requestedTime);
  assert.equal(hasErrors(validateRegistration({ ...sched, requestedDate: '2026-10-20', requestedTime: '14:30' }, { now })), false);
  assert.equal(hasErrors(validateRegistration({ ...base, requestedDate: 'garbage', requestedTime: 'x' }, { now })), false);
});
test('phone masking shows only the last 4 digits', () => { assert.equal(maskPhone('+91 98765 43210'), '••••• 3210'); assert.equal(maskPhone(undefined), undefined); });
