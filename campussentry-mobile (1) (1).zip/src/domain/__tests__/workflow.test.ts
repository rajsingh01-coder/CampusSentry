import assert from 'node:assert/strict';
import { test } from 'node:test';
import { canReviewRequest, canTransitionRequest, canVerifyOtp, getLocalDateRange, getLocalDateInputValue, isOpenRequest, requiresOtp } from '../workflow.ts';

test('only Pending Approval and Additional Information Required are reviewable', () => {
  assert.equal(canReviewRequest('Pending Approval'), true);
  assert.equal(canReviewRequest('Additional Information Required'), true);
  for (const s of ['Pending Verification', 'Approved', 'Rejected', 'Cancelled', 'Expired'] as const) assert.equal(canReviewRequest(s), false, s);
});
test('terminal decisions cannot be reversed and same-status is not a transition', () => {
  assert.equal(canTransitionRequest('Approved', 'Rejected'), false);
  assert.equal(canTransitionRequest('Pending Approval', 'Approved'), true);
  assert.equal(canTransitionRequest('Additional Information Required', 'Additional Information Required'), false);
});
test('OTP is required only for external guests when the setting is on', () => {
  assert.equal(requiresOtp('Guest/External Visitor', true), true);
  assert.equal(requiresOtp('Guest/External Visitor', false), false);
  assert.equal(requiresOtp('Student', true), false);
  assert.equal(requiresOtp(null, true), false);
});
test('OTP can be verified only while Pending Verification and Pending/Failed', () => {
  assert.equal(canVerifyOtp('Pending Verification', 'Pending'), true);
  assert.equal(canVerifyOtp('Pending Verification', 'Failed'), true);
  assert.equal(canVerifyOtp('Pending Verification', 'Verified'), false);
  assert.equal(canVerifyOtp('Pending Approval', 'Pending'), false);
});
test('open requests', () => { assert.equal(isOpenRequest('Pending Approval'), true); assert.equal(isOpenRequest('Approved'), false); });
test('week starts on Monday; month on the 1st; today is the local day', () => {
  const sun = new Date(2026, 9, 18, 15, 0); // Sunday 18 Oct 2026
  const week = getLocalDateRange('week', sun);
  assert.equal(week.start.getDay(), 1); assert.equal(week.start.getDate(), 12);
  assert.equal(getLocalDateRange('month', sun).start.getDate(), 1);
  const today = getLocalDateRange('today', sun);
  assert.equal(today.start.getHours(), 0); assert.equal(today.end.getHours(), 23);
  assert.equal(getLocalDateInputValue(sun), '2026-10-18');
});
