import { ApiError } from '../services/errors.ts';

export type OtpFailure = { kind: 'incorrect' } | { kind: 'expired' } | { kind: 'rate_limited'; retryAfterSeconds?: number } | { kind: 'other'; error: unknown };

/**
 * Maps a failed verify/resend call to a UI state. Relies on the PROPOSED error codes 'otp_incorrect' / 'otp_expired'.
 * Unknown failures fall through to 'other' (never to 'verified').
 */
export function classifyOtpError(e: unknown): OtpFailure {
  if (e instanceof ApiError) {
    if (e.kind === 'rate_limited') return { kind: 'rate_limited', retryAfterSeconds: e.retryAfterSeconds };
    if (e.code === 'otp_expired') return { kind: 'expired' };
    if (e.code === 'otp_incorrect') return { kind: 'incorrect' };
  }
  return { kind: 'other', error: e };
}
export const OTP_MIN = 4;
export const OTP_MAX = 8;
export const sanitizeOtp = (raw: string): string => raw.replace(/\D/g, '').slice(0, OTP_MAX);
export const isOtpSubmittable = (code: string): boolean => code.length >= OTP_MIN && code.length <= OTP_MAX;
