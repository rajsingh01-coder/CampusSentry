/** Appends a page to existing items, dropping items whose id is already present (page overlap protection). */
export function mergePage<T>(existing: T[], incoming: T[], idOf: (item: T) => string): T[] {
  const seen = new Set(existing.map(idOf));
  return [...existing, ...incoming.filter((i) => !seen.has(idOf(i)))];
}
