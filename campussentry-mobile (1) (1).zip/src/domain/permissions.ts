import type { Permission, StaffUser } from './types.ts';
/** UI gating only. The server must reject unauthorized actions regardless. */
export function can(user: StaffUser | null | undefined, permission: Permission): boolean {
  return !!user && user.permissions.includes(permission);
}
