import type { PresenceState, RequestStatus } from './types.ts';

export interface VisitorSnapshot { requestStatus: RequestStatus; presence: PresenceState }
export interface AllowedActions { canCheckIn: boolean; canCheckOut: boolean; checkInBlockedReason?: string; checkOutBlockedReason?: string }

/**
 * Same guards as admin recordCheckIn/recordCheckOut:
 *  - check-in needs an Approved request and the visitor must not already be inside (re-entry after Exit is allowed);
 *  - check-out needs the visitor to be Inside Campus.
 * Decided from the LATEST server snapshot. A UI guard only; the backend stays the authority and may answer 409.
 */
export function getAllowedActions(s: VisitorSnapshot): AllowedActions {
  const out: AllowedActions = { canCheckIn: false, canCheckOut: false };
  if (s.presence === 'Inside Campus') out.checkInBlockedReason = 'Visitor is already inside campus.';
  else if (s.requestStatus !== 'Approved') out.checkInBlockedReason = `Request status is “${s.requestStatus}”. Only approved requests can check in.`;
  else out.canCheckIn = true;

  if (s.presence === 'Inside Campus') out.canCheckOut = true;
  else out.checkOutBlockedReason = 'Visitor is not recorded as inside campus.';
  return out;
}
