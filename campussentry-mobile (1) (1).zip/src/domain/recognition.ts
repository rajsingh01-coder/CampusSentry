import type { IdentityClassification } from './types.ts';

export type NextAction = 'register_visit' | 'search_records' | 'retake';

/**
 * Next steps after a recognition result. A result never grants or denies entry: every classification leads to a normal
 * visit request that the admin reviews. "Unknown" is neutral and offers the same way forward as the others.
 */
export const nextActionsFor = (_classification: IdentityClassification): NextAction[] => ['register_visit', 'search_records', 'retake'];

export function registerLabelFor(classification: IdentityClassification): string {
  switch (classification) {
    case 'Known': return 'Register this visit';
    case 'Unknown': return 'Register as walk-in';
    case 'Verification Required': return 'Register for verification';
  }
}

export const CONFIRM_MATCH_NOTICE = 'An AI match never independently authorizes access. Confirm the person in front of you.';
