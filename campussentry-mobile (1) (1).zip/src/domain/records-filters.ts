import type { IdentityClassification, PresenceState, RequestStatus, VisitorCategory } from './types.ts';
import type { DatePeriod } from './workflow.ts';

export type RecordSearchField = 'name' | 'phone' | 'id';
export interface RecordFilters {
  query: string; field: RecordSearchField;
  category: VisitorCategory | null; classification: IdentityClassification | null;
  status: RequestStatus | null; presence: PresenceState | null; period: DatePeriod;
}
export const DEFAULT_FILTERS: RecordFilters = { query: '', field: 'name', category: null, classification: null, status: null, presence: null, period: 'all' };

export const filtersAreDefault = (f: RecordFilters): boolean =>
  f.query.trim() === '' && f.field === 'name' && f.category === null && f.classification === null && f.status === null && f.presence === null && f.period === 'all';
