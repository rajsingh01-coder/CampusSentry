import type { Permission, StaffRole } from './types.ts';

/**
 * FRONTEND DEFAULTS ONLY: used when the backend sends a role but no explicit `permissions` list.
 * The admin README says administrators make approval decisions, so Security/Staff and Supervisor cannot review here.
 * Least privilege on purpose; the backend team should confirm or replace this with an explicit list per user.
 */
export const ROLE_DEFAULT_PERMISSIONS: Record<StaffRole, Permission[]> = {
  Admin: ['request.create', 'request.review', 'visitor.checkin', 'visitor.checkout', 'visitor.search_phone', 'history.view'],
  Supervisor: ['request.create', 'visitor.checkin', 'visitor.checkout', 'visitor.search_phone', 'history.view'],
  'Security/Staff': ['request.create', 'visitor.checkin', 'visitor.checkout'],
};
