// Domain vocabulary copied from the Admin Web App (admin/src/types/index.ts). The web app is the source of truth:
// string values are shown to users exactly as written there, so do not rename them here.

export const VISITOR_CATEGORIES = ['Student', 'Parent/Guardian', 'Guest/External Visitor', 'Teaching Staff', 'Non-Teaching Staff', 'Vendor', 'Other', 'Not specified'] as const;
export type VisitorCategory = (typeof VISITOR_CATEGORIES)[number];

/** HOW the visitor's identity is classified. "Unknown" is neutral: never dangerous, never an automatic denial. */
export const IDENTITY_CLASSIFICATIONS = ['Known', 'Unknown', 'Verification Required'] as const;
export type IdentityClassification = (typeof IDENTITY_CLASSIFICATIONS)[number];

export const REQUEST_STATUSES = ['Pending Verification', 'Pending Approval', 'Approved', 'Rejected', 'Cancelled', 'Expired', 'Additional Information Required'] as const;
export type RequestStatus = (typeof REQUEST_STATUSES)[number];

export const VISIT_MODES = ['Walk-in', 'Scheduled'] as const;
export type VisitMode = (typeof VISIT_MODES)[number];

export const OTP_STATUSES = ['Verified', 'Pending', 'Failed', 'Not Applicable'] as const;
export type OtpStatus = (typeof OTP_STATUSES)[number];

/** Campus presence comes from backend entry/exit records only, never from the request status. */
export const PRESENCE_STATES = ['Inside Campus', 'Exited', 'Not Checked In'] as const;
export type PresenceState = (typeof PRESENCE_STATES)[number];

export const STAFF_ROLES = ['Admin', 'Security/Staff', 'Supervisor'] as const;
export type StaffRole = (typeof STAFF_ROLES)[number];

export type NotificationPriority = 'Normal' | 'High' | 'Urgent';

/** Defaults of the admin "System Settings" (INITIAL_SETTINGS). Used only if the server does not send its own configuration. */
export const ADMIN_DEFAULT_AUTHORITIES = ['Principal/Director', 'Dean/HOD', 'Administrator', 'Other Authority/Office'] as const;
export const ADMIN_DEFAULT_REQUIRE_OTP_FOR_GUESTS = true;

// Capability keys the app checks before showing an action. The server must still reject unauthorized calls.
export type Permission = 'request.create' | 'request.review' | 'visitor.checkin' | 'visitor.checkout' | 'visitor.search_phone' | 'history.view';

export interface StaffUser {
  staffId: string;
  name: string;
  email?: string;
  department?: string;
  role: StaffRole;
  assignedGate?: string;
  permissions: Permission[];
  /** 'server' when the backend sent an explicit list, 'role-default' when derived from the role (see role-permissions.ts) */
  permissionSource: 'server' | 'role-default';
}

export interface AppConfig {
  visitorCategories: string[];
  authorizedMeetingAuthorities: string[];
  requireOtpForGuests: boolean;
  gates: string[];
  source: 'server' | 'admin-defaults';
}
