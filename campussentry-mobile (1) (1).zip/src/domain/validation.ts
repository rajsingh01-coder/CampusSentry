import { IDENTITY_CLASSIFICATIONS, VISIT_MODES, type IdentityClassification, type VisitMode, type VisitorCategory } from './types.ts';
import { getLocalDateInputValue } from './workflow.ts';

export interface PhoneRule { minDigits: number; maxDigits: number }
// Admin shows "+91 98765 43210". Bounds stay configurable (env) until the backend confirms the numbering rule.
export const DEFAULT_PHONE_RULE: PhoneRule = { minDigits: 10, maxDigits: 15 };

export interface RegistrationInput {
  fullName: string;
  phone: string;
  category: VisitorCategory | null;
  classification: IdentityClassification;
  personToMeet: string;
  department: string;
  reason: string;
  visitMode: VisitMode;
  requestedDate: string; // YYYY-MM-DD, used when Scheduled
  requestedTime: string; // HH:mm, used when Scheduled
  appointmentDetails: string;
  gate: string;
  staffNotes: string;
}
export type RegistrationField = 'fullName' | 'phone' | 'category' | 'personToMeet' | 'reason' | 'requestedDate' | 'requestedTime' | 'gate' | 'classification' | 'visitMode';
export type RegistrationErrors = Partial<Record<RegistrationField, string>>;

export function normalizePhone(raw: string): string {
  const trimmed = raw.trim();
  return (trimmed.startsWith('+') ? '+' : '') + trimmed.replace(/\D/g, '');
}

export function validatePhone(raw: string, rule: PhoneRule = DEFAULT_PHONE_RULE, required = true): string | undefined {
  if (!raw.trim()) return required ? 'Enter a mobile number.' : undefined;
  if (/[^\d\s+\-()]/.test(raw)) return 'Use digits only (spaces, +, - and () are allowed).';
  const digits = raw.replace(/\D/g, '');
  if (digits.length < rule.minDigits || digits.length > rule.maxDigits) {
    return rule.minDigits === rule.maxDigits ? `Mobile number must have ${rule.minDigits} digits.` : `Mobile number must have ${rule.minDigits}–${rule.maxDigits} digits.`;
  }
  return undefined;
}

export function isValidLocalDate(value: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!m) return false;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return d.getFullYear() === Number(m[1]) && d.getMonth() === Number(m[2]) - 1 && d.getDate() === Number(m[3]);
}
export const isValidTime = (value: string): boolean => /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

export interface ValidationContext { phoneRule?: PhoneRule; otpRequired?: boolean; now?: Date }

/** `otpRequired` makes the phone number mandatory: the OTP is sent to it. Otherwise the phone stays optional (as in admin). */
export function validateRegistration(input: RegistrationInput, ctx: ValidationContext = {}): RegistrationErrors {
  const e: RegistrationErrors = {};
  const name = input.fullName.trim();
  if (name.length < 2) e.fullName = 'Enter the visitor’s full name.';
  else if (name.length > 100) e.fullName = 'Name is too long (100 characters max).';
  const phoneErr = validatePhone(input.phone, ctx.phoneRule, !!ctx.otpRequired);
  if (phoneErr) e.phone = ctx.otpRequired && !input.phone.trim() ? 'Enter a mobile number. The OTP is sent to it.' : phoneErr;
  if (!input.category) e.category = 'Choose a visitor category.';
  if (!IDENTITY_CLASSIFICATIONS.includes(input.classification)) e.classification = 'Choose an identity classification.';
  if (!input.personToMeet.trim()) e.personToMeet = 'Choose whom the visitor wants to meet.';
  if (input.reason.trim().length < 3) e.reason = 'Enter the reason for the meeting.';
  if (!VISIT_MODES.includes(input.visitMode)) e.visitMode = 'Choose a visit mode.';
  if (!input.gate.trim()) e.gate = 'Enter the gate or entry location.';
  if (input.visitMode === 'Scheduled') {
    const today = getLocalDateInputValue(ctx.now);
    if (!isValidLocalDate(input.requestedDate)) e.requestedDate = 'Use the format YYYY-MM-DD.';
    else if (input.requestedDate < today) e.requestedDate = 'The date cannot be in the past.';
    if (!isValidTime(input.requestedTime)) e.requestedTime = 'Use 24-hour time, for example 14:30.';
  }
  return e;
}
export const hasErrors = (e: object): boolean => Object.keys(e).length > 0;

export function maskPhone(phone?: string): string | undefined {
  if (!phone) return undefined;
  const digits = phone.replace(/\D/g, '');
  return digits.length <= 4 ? '••••' : `••••• ${digits.slice(-4)}`;
}
