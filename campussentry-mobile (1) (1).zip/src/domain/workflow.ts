import type { OtpStatus, RequestStatus, VisitorCategory } from './types.ts';

// Ported from admin/src/lib/workflow.ts so both apps apply the same rules.
const REVIEWABLE: readonly RequestStatus[] = ['Pending Approval', 'Additional Information Required'];
export const canReviewRequest = (status: RequestStatus): boolean => REVIEWABLE.includes(status);

export type RequestDecision = 'Approved' | 'Rejected' | 'Additional Information Required';
export function canTransitionRequest(status: RequestStatus, next: RequestDecision): boolean {
  return canReviewRequest(status) && next !== status; // terminal decisions (Approved/Rejected/...) cannot be reversed
}

/** OTP is only required for external guests, and only when the system setting is on (admin: requiresDemoOtp). */
export const requiresOtp = (category: VisitorCategory | string | null, requireOtpForGuests: boolean): boolean =>
  requireOtpForGuests && category === 'Guest/External Visitor';

/** The visitor can enter an OTP only while the request waits for verification and the last attempt is not yet verified. */
export const canVerifyOtp = (status: RequestStatus, otp: OtpStatus): boolean =>
  status === 'Pending Verification' && (otp === 'Pending' || otp === 'Failed');

/** Requests that still need action before the visitor can enter. Used for the "Pending" metric and quick filter. */
export const isOpenRequest = (status: RequestStatus): boolean =>
  status === 'Pending Verification' || status === 'Pending Approval' || status === 'Additional Information Required';

export type DateRange = { start: Date; end: Date };
export type DatePeriod = 'all' | 'today' | 'week' | 'month';

/** Admin convention: weeks start on Monday, ranges use the device's local calendar day. */
export function getLocalDateRange(period: Exclude<DatePeriod, 'all'>, now = new Date()): DateRange {
  const end = new Date(now); end.setHours(23, 59, 59, 999);
  const start = new Date(now); start.setHours(0, 0, 0, 0);
  if (period === 'week') start.setDate(start.getDate() - ((start.getDay() + 6) % 7));
  else if (period === 'month') start.setDate(1);
  return { start, end };
}

export function periodToQuery(period: DatePeriod, now = new Date()): { from?: string; to?: string } {
  if (period === 'all') return {};
  const r = getLocalDateRange(period, now);
  return { from: r.start.toISOString(), to: r.end.toISOString() };
}

export function getLocalDateInputValue(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
