import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import type { StaffUser } from '../../domain/types';
import { setUnauthorizedHandler } from '../../services/api-client';
import { authService } from '../../services/auth.service';
import { config } from '../../services/config';
import { ApiError } from '../../services/errors';
import { sessionStore } from '../../services/session-store';

type Status = 'loading' | 'signedOut' | 'signedIn';
interface AuthCtx { status: Status; user: StaffUser | null; signIn: (identifier: string, password: string) => Promise<void>; signOut: () => Promise<void>; notice: string | null }
const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [status, setStatus] = useState<Status>('loading');
  const [user, setUser] = useState<StaffUser | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const backgroundedAt = useRef<number | null>(null);

  const clear = useCallback(async (why?: string) => { await sessionStore.clear(); setUser(null); setStatus('signedOut'); setNotice(why ?? null); }, []);

  useEffect(() => { setUnauthorizedHandler(() => { void clear('Your session expired. Sign in again.'); }); return () => setUnauthorizedHandler(null); }, [clear]);

  // Restore: show the stored profile only after the server confirms the token (permissions may have changed).
  useEffect(() => {
    (async () => {
      const stored = await sessionStore.load();
      if (!stored) { setStatus('signedOut'); return; }
      try {
        const fresh = await authService.fetchMe();
        setUser(fresh); setStatus('signedIn');
        await sessionStore.save({ ...stored, user: fresh });
      } catch (e) {
        if (e instanceof ApiError && e.kind === 'unauthorized') { await clear('Your session expired. Sign in again.'); return; }
        setUser(stored.user); setStatus('signedIn'); // offline start: keep the last known profile; the server still decides each action
      }
    })();
  }, [clear]);

  // Optional idle logout (EXPO_PUBLIC_IDLE_LOGOUT_MINUTES): measured while the app was in the background.
  useEffect(() => {
    if (!config.idleLogoutMinutes) return undefined;
    const sub = AppState.addEventListener('change', (s) => {
      if (s !== 'active') { backgroundedAt.current = Date.now(); return; }
      const t = backgroundedAt.current; backgroundedAt.current = null;
      if (t && Date.now() - t > config.idleLogoutMinutes * 60000) void clear('Signed out after inactivity.');
    });
    return () => sub.remove();
  }, [clear]);

  const signIn = useCallback(async (identifier: string, password: string) => {
    const res = await authService.login(identifier, password);
    await sessionStore.save(res);
    setNotice(null); setUser(res.user); setStatus('signedIn');
  }, []);

  const signOut = useCallback(async () => {
    try { await authService.logoutRemote(); } catch { /* the local session is cleared regardless */ }
    await clear();
  }, [clear]);

  const value = useMemo(() => ({ status, user, signIn, signOut, notice }), [status, user, signIn, signOut, notice]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside AuthProvider');
  return v;
}
/** For screens that only render when signed in. */
export function useStaff(): StaffUser {
  const { user } = useAuth();
  if (!user) throw new Error('useStaff used while signed out');
  return user;
}
