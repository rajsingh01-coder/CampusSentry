import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { AppConfig } from '../../domain/types';
import { configService } from '../../services/config.service';
import { ADMIN_DEFAULT_CONFIG } from '../../services/parsers';
import { useAuth } from '../auth/AuthProvider';

const Ctx = createContext<AppConfig>(ADMIN_DEFAULT_CONFIG);

/** Loads the admin-managed lists (categories, authorities, OTP rule) once signed in. Falls back to admin defaults, flagged by `source`. */
export function ConfigProvider({ children }: { children: React.ReactNode }) {
  const { status } = useAuth();
  const [cfg, setCfg] = useState<AppConfig>(ADMIN_DEFAULT_CONFIG);
  useEffect(() => {
    if (status !== 'signedIn') return undefined;
    const ctl = new AbortController();
    configService.get(ctl.signal).then((c) => { if (!ctl.signal.aborted) setCfg(c); }).catch(() => undefined);
    return () => ctl.abort();
  }, [status]);
  const value = useMemo(() => cfg, [cfg]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
export const useAppConfig = (): AppConfig => useContext(Ctx);
