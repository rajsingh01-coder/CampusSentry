import { CameraView, useCameraPermissions } from 'expo-camera';
import { useRouter } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { AppHeader } from '../../components/ui/AppHeader';
import { PrimaryButton, SecondaryButton } from '../../components/ui/Buttons';
import { Card } from '../../components/ui/Card';
import { PermissionPrompt } from '../../components/ui/PermissionPrompt';
import { Screen } from '../../components/ui/Screen';
import { ScreenCaptureGuard } from '../../components/ui/ScreenCaptureGuard';
import { ClassificationBadge } from '../../components/ui/StatusBadge';
import { LoadingView } from '../../components/ui/States';
import { can } from '../../domain/permissions';
import { CONFIRM_MATCH_NOTICE, registerLabelFor } from '../../domain/recognition';
import { useFocused } from '../../hooks/useFocused';
import { describeError } from '../../services/errors';
import type { Recognition } from '../../services/parsers-ops';
import { recognitionService } from '../../services/recognition.service';
import { useStaff } from '../auth/AuthProvider';
import { radius, spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { type as t } from '../../theme/typography';

type Phase = { kind: 'ready' } | { kind: 'uploading' } | { kind: 'result'; result: Recognition } | { kind: 'error'; error: unknown };

export function IdentifyFlow() {
  const { colors } = useTheme();
  const router = useRouter();
  const user = useStaff();
  const focused = useFocused();
  const [permission, requestPermission] = useCameraPermissions();
  const camRef = useRef<CameraView>(null);
  const [cameraReady, setCameraReady] = useState(false);
  const [phase, setPhase] = useState<Phase>({ kind: 'ready' });
  const ctl = useRef<AbortController | null>(null);
  useEffect(() => () => ctl.current?.abort(), []);

  async function capture() {
    if (!camRef.current || phase.kind === 'uploading') return;
    setPhase({ kind: 'uploading' });
    ctl.current = new AbortController();
    try {
      const photo = await camRef.current.takePictureAsync({ quality: 0.6, skipProcessing: true });
      if (!photo?.uri) throw new Error('No photo was captured.');
      const result = await recognitionService.recognize(photo.uri, ctl.current.signal); // file is deleted by the service
      setPhase({ kind: 'result', result });
    } catch (e) { setPhase({ kind: 'error', error: e }); }
  }
  const retake = () => setPhase({ kind: 'ready' });

  if (!permission) return <Screen><AppHeader title="Identify" /><LoadingView /></Screen>;
  if (!permission.granted) {
    return (
      <Screen>
        <AppHeader title="Identify" />
        <PermissionPrompt title="Camera access needed" message="The camera is used only to identify the visitor in front of you. Photos are not kept on this phone." canAskAgain={permission.canAskAgain} onAllow={() => { void requestPermission(); }} />
      </Screen>
    );
  }

  if (phase.kind === 'result') {
    const { result } = phase;
    return (
      <Screen>
        <ScreenCaptureGuard />
        <AppHeader title="Result" />
        <Card>
          <ClassificationBadge value={result.classification} />
          {result.match?.name ? <Text style={[t.sectionTitle, { color: colors.text }]}>{result.match.name}</Text> : <Text style={[t.body, { color: colors.text }]}>{result.classification === 'Unknown' ? 'No match on record.' : 'A possible match needs confirmation.'}</Text>}
          {typeof result.match?.confidence === 'number' ? <Text style={[t.support, { color: colors.textSecondary }]}>Match confidence (indicative): {Math.round(result.match.confidence * 100)}%</Text> : null}
          <Text style={[t.support, { color: colors.textSecondary }]}>{CONFIRM_MATCH_NOTICE}</Text>
          {result.classification === 'Unknown' ? <Text style={[t.support, { color: colors.textSecondary }]}>“Unknown” does not imply unauthorized or malicious intent. Register the visit as usual.</Text> : null}
        </Card>
        {can(user, 'request.create') ? <PrimaryButton label={registerLabelFor(result.classification)} icon="person-add-outline" onPress={() => router.push({ pathname: '/(tabs)/register', params: { name: result.match?.name ?? '', classification: result.classification } })} /> : null}
        {result.match?.visitorId ? <SecondaryButton label="Open visitor record" icon="person-outline" onPress={() => router.push({ pathname: '/visitors/[visitorId]', params: { visitorId: result.match!.visitorId! } })} /> : null}
        <SecondaryButton label="Search records" icon="search-outline" onPress={() => router.push('/(tabs)/records')} />
        <SecondaryButton label="Retake" icon="camera-reverse-outline" onPress={retake} />
      </Screen>
    );
  }

  const d = phase.kind === 'error' ? describeError(phase.error) : null;
  return (
    <Screen>
      <AppHeader title="Identify" />
      <Text style={[t.body, { color: colors.textSecondary }]}>Frame the visitor’s face and capture. Only with their awareness, at the gate.</Text>
      <View style={[styles.frame, { borderColor: colors.border, backgroundColor: colors.surfaceAlt }]}>
        {focused ? <CameraView ref={camRef} style={StyleSheet.absoluteFill} facing="front" onCameraReady={() => setCameraReady(true)} /> : null}
        {phase.kind === 'uploading' ? <View style={[StyleSheet.absoluteFill, styles.overlay]}><LoadingView label="Identifying" /></View> : null}
      </View>
      {d ? <Text accessibilityRole="alert" style={[t.support, { color: colors.status.critical.fg }]}>{d.title}. {d.detail}</Text> : null}
      <PrimaryButton label="Capture and identify" icon="scan-outline" onPress={() => { void capture(); }} loading={phase.kind === 'uploading'} disabled={!cameraReady} />
      <SecondaryButton label="Register without photo" onPress={() => router.push('/(tabs)/register')} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  frame: { height: 380, borderRadius: radius.lg, borderWidth: 1, overflow: 'hidden' },
  overlay: { backgroundColor: 'rgba(0,0,0,0.5)', alignItems: 'center', justifyContent: 'center' },
});
