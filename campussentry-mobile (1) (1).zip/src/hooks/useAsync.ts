import { useCallback, useEffect, useRef, useState } from 'react';

export interface AsyncState<T> {
  data: T | null; error: unknown; loading: boolean; refreshing: boolean;
  reload: () => void;   // full reload with spinner
  refresh: () => void;  // pull-to-refresh
  silent: () => void;   // background refetch: keeps current data on screen, ignores failures
}
type Mode = 'load' | 'refresh' | 'silent';

/** Loads on mount, cancels stale requests, exposes explicit loading/error/refresh states. */
export function useAsync<T>(load: (signal: AbortSignal) => Promise<T>): AsyncState<T> {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tick, setTick] = useState(0);
  const mode = useRef<Mode>('load');
  const loadRef = useRef(load);
  loadRef.current = load;

  useEffect(() => {
    const controller = new AbortController();
    const m = mode.current;
    if (m === 'load') { setLoading(true); setError(null); } else if (m === 'refresh') { setRefreshing(true); setError(null); }
    loadRef.current(controller.signal)
      .then((d) => { if (!controller.signal.aborted) { setData(d); setError(null); } })
      .catch((e) => { if (!controller.signal.aborted && m !== 'silent') setError(e); })
      .finally(() => { if (!controller.signal.aborted) { setLoading(false); setRefreshing(false); } });
    return () => controller.abort();
  }, [tick]);

  const go = useCallback((m: Mode) => { mode.current = m; setTick((t) => t + 1); }, []);
  return { data, error, loading, refreshing, reload: useCallback(() => go('load'), [go]), refresh: useCallback(() => go('refresh'), [go]), silent: useCallback(() => go('silent'), [go]) };
}
