import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';

/** true only while the screen is focused. Tab screens stay mounted, so use this to release the camera on blur. */
export function useFocused(): boolean {
  const [focused, setFocused] = useState(false);
  useFocusEffect(useCallback(() => { setFocused(true); return () => setFocused(false); }, []));
  return focused;
}
