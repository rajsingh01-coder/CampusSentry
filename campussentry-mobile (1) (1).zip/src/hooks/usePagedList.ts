import { useCallback, useEffect, useRef, useState } from 'react';
import { mergePage } from '../domain/pagination.ts';
import { hasMorePages, type Page } from '../services/parsers-ops.ts';

export interface PagedList<T> {
  items: T[]; total: number; loading: boolean; refreshing: boolean; loadingMore: boolean; hasMore: boolean;
  error: unknown; loadMoreError: unknown; refresh: () => void; reload: () => void; loadMore: () => void;
}

/**
 * Page-number pagination (admin PaginatedResult). `resetKey` must change whenever filters change; that discards old
 * results and aborts in-flight requests so a slow old response can never overwrite a newer one.
 */
export function usePagedList<T>(fetchPage: (page: number, signal: AbortSignal) => Promise<Page<T>>, idOf: (item: T) => string, resetKey: string): PagedList<T> {
  const [items, setItems] = useState<T[]>([]);
  const [total, setTotal] = useState(0);
  const [pageNo, setPageNo] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<unknown>(null);
  const [loadMoreError, setLoadMoreError] = useState<unknown>(null);
  const [tick, setTick] = useState(0);
  const mode = useRef<'load' | 'refresh'>('load');
  const fetchRef = useRef(fetchPage); fetchRef.current = fetchPage;
  const idRef = useRef(idOf); idRef.current = idOf;
  const moreCtl = useRef<AbortController | null>(null);

  useEffect(() => {
    moreCtl.current?.abort();
    const ctl = new AbortController();
    if (mode.current === 'load') { setLoading(true); setItems([]); } else setRefreshing(true);
    mode.current = 'load';
    setError(null); setLoadMoreError(null); setLoadingMore(false);
    fetchRef.current(1, ctl.signal)
      .then((p) => { if (ctl.signal.aborted) return; setItems(p.data); setTotal(p.total); setPageNo(p.page); setHasMore(hasMorePages(p)); })
      .catch((e) => { if (!ctl.signal.aborted) setError(e); })
      .finally(() => { if (!ctl.signal.aborted) { setLoading(false); setRefreshing(false); } });
    return () => ctl.abort();
  }, [resetKey, tick]);

  const loadMore = useCallback(() => {
    if (!hasMore || loading || refreshing || loadingMore) return;
    const ctl = new AbortController(); moreCtl.current = ctl;
    setLoadingMore(true); setLoadMoreError(null);
    fetchRef.current(pageNo + 1, ctl.signal)
      .then((p) => { if (ctl.signal.aborted) return; setItems((prev) => mergePage(prev, p.data, idRef.current)); setTotal(p.total); setPageNo(p.page); setHasMore(hasMorePages(p)); })
      .catch((e) => { if (!ctl.signal.aborted) setLoadMoreError(e); })
      .finally(() => { if (!ctl.signal.aborted) setLoadingMore(false); });
  }, [hasMore, loading, refreshing, loadingMore, pageNo]);

  return {
    items, total, loading, refreshing, loadingMore, hasMore, error, loadMoreError, loadMore,
    refresh: useCallback(() => { mode.current = 'refresh'; setTick((t) => t + 1); }, []),
    reload: useCallback(() => { mode.current = 'load'; setTick((t) => t + 1); }, []),
  };
}
