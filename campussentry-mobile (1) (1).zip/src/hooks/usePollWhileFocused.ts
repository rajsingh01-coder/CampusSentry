import { useFocusEffect } from 'expo-router';
import { useCallback, useRef } from 'react';

/** Calls `fn` every `ms` while the screen is focused. Stops on blur/unmount. */
export function usePollWhileFocused(fn: () => void, ms: number, enabled: boolean): void {
  const ref = useRef(fn); ref.current = fn;
  useFocusEffect(useCallback(() => {
    if (!enabled) return undefined;
    const id = setInterval(() => ref.current(), ms);
    return () => clearInterval(id);
  }, [ms, enabled]));
}
