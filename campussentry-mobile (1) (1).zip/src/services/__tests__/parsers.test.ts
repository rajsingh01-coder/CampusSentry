import assert from 'node:assert/strict';
import { test } from 'node:test';
import { ApiError } from '../errors.ts';
import { buildPath } from '../path.ts';
import { parseConfig, parseCreatedRequest, parseDashboard, parseLogin, parseStaffUser } from '../parsers.ts';
import { hasMorePages, parseNotification, parsePage, parseRecognition, parseRequestDetail, parseRequestSummary, parseVisitorRecord } from '../parsers-ops.ts';

const req = { requestId: 'REQ-1', visitorName: 'A', visitorCategory: 'Student', identityClassification: 'Known', requestStatus: 'Approved', otpStatus: 'Not Applicable', createdAt: '2026-10-18T05:00:00Z' };

test('staff user: role defaults apply only when the server sends no permissions', () => {
  const noPerms = parseStaffUser({ staffId: 'S1', name: 'N', role: 'Security/Staff' });
  assert.equal(noPerms.permissionSource, 'role-default'); assert.ok(noPerms.permissions.includes('visitor.checkin'));
  const explicit = parseStaffUser({ staffId: 'S1', name: 'N', role: 'Admin', permissions: ['request.review', 'bogus'] });
  assert.equal(explicit.permissionSource, 'server'); assert.deepEqual(explicit.permissions, ['request.review']);
  assert.throws(() => parseStaffUser({ staffId: 'S1', name: 'N', role: 'Janitor' }), ApiError);
});
test('login requires a token', () => { assert.throws(() => parseLogin({ user: {} }), ApiError); });
test('config falls back per-field to admin defaults', () => {
  const c = parseConfig({});
  assert.equal(c.visitorCategories.length, 8); assert.equal(c.authorizedMeetingAuthorities[0], 'Principal/Director'); assert.equal(c.requireOtpForGuests, true);
  assert.equal(parseConfig({ requireOtpForGuests: false, gates: ['G1'] }).requireOtpForGuests, false);
});
test('created request must carry a backend-issued id and valid statuses', () => {
  assert.throws(() => parseCreatedRequest({ requestStatus: 'Pending Approval', otpStatus: 'Pending' }), ApiError);
  assert.throws(() => parseCreatedRequest({ requestId: 'R', requestStatus: 'Made up', otpStatus: 'Pending' }), ApiError);
  assert.equal(parseCreatedRequest({ requestId: 'R', requestStatus: 'Pending Verification', otpStatus: 'Pending' }).requestId, 'R');
});
test('page: admin shape, malformed rows dropped, never invented', () => {
  const p = parsePage({ data: [req, { nope: 1 }], total: 5, page: 1, pageSize: 2, totalPages: 3 }, parseRequestSummary, 'x');
  assert.equal(p.data.length, 1); assert.equal(hasMorePages(p), true);
  assert.equal(hasMorePages({ page: 3, totalPages: 3 }), false);
  assert.throws(() => parsePage({ items: [] }, parseRequestSummary, 'x'), ApiError);
});
test('request summary rejects unknown enum values', () => { assert.equal(parseRequestSummary({ ...req, requestStatus: 'approved' }), null); assert.equal(parseRequestSummary({ ...req, identityClassification: 'Dangerous' }), null); });
test('request detail needs a reason and keeps review notes', () => {
  assert.throws(() => parseRequestDetail(req), ApiError);
  const d = parseRequestDetail({ ...req, reasonForMeeting: 'Why', reviews: [{ decision: 'Rejected', notes: 'dup' }, {}] });
  assert.equal(d.reviews.length, 1);
});
test('visitor record + notification + recognition + dashboard', () => {
  assert.equal(parseVisitorRecord({ visitorId: 'V', visitorName: 'N', visitorCategory: 'Vendor', identityClassification: 'Unknown', presence: 'Inside Campus' })?.presence, 'Inside Campus');
  assert.equal(parseNotification({ id: 'n', requestId: 'r', visitorName: 'v', createdAt: 't', isRead: false })?.priority, 'Normal');
  assert.equal(parseNotification({ id: 'n', requestId: 'r', visitorName: 'v', createdAt: 't' }), null);
  assert.equal(parseRecognition({ classification: 'Unknown' }).match, undefined);
  assert.throws(() => parseRecognition({ classification: 'known' }), ApiError);
  assert.equal(parseDashboard({ totalToday: 1, insideNow: 2, pendingApproval: 3, recent: [{ id: 'a', visitorName: 'x', kind: 'check_in', at: 't' }, { id: 'b' }] }).recent.length, 1);
  assert.throws(() => parseDashboard({ totalToday: -1 }), ApiError);
});
test('buildPath encodes params and skips empty queries', () => {
  assert.equal(buildPath('/api/requests/:requestId', { requestId: 'a b/c' }, { page: 2, q: '', status: undefined }), '/api/requests/a%20b%2Fc?page=2');
  assert.throws(() => buildPath('/x/:id', {}), ApiError);
});
