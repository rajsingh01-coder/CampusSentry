import { config } from './config';
import { connectivity } from './connectivity';
import { demoFetch } from '../demo/demo-fetch';
import { DEMO_MODE, ENDPOINTS, type EndpointName } from './endpoints';
import { ApiError, type ApiErrorKind } from './errors';
import { buildPath, type Query } from './path.ts';
import { sessionStore } from './session-store';

type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export interface RequestOptions {
  /** Defaults to the method of the route table in endpoints.ts. */
  method?: Method;
  body?: unknown;
  /** multipart upload; Content-Type is set by the runtime */
  formData?: FormData;
  params?: Record<string, string>;
  query?: Query;
  signal?: AbortSignal;
  /** Sent as `Idempotency-Key` only when EXPO_PUBLIC_SEND_IDEMPOTENCY_KEY=true (backend support unconfirmed). */
  idempotencyKey?: string;
  /** Skip the Authorization header (login). */
  anonymous?: boolean;
  timeoutMs?: number;
}

let onUnauthorized: (() => void) | null = null;
export const setUnauthorizedHandler = (fn: (() => void) | null) => { onUnauthorized = fn; };

export async function apiRequest<T>(endpoint: EndpointName, opts: RequestOptions = {}): Promise<T> {
  const route = ENDPOINTS[endpoint];
  const path = buildPath(route.path, opts.params, opts.query);
  if (!DEMO_MODE && !config.apiBaseUrl) throw new ApiError('contract_missing', 'EXPO_PUBLIC_API_BASE_URL is not set. Copy .env.example to .env.');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort('timeout'), opts.timeoutMs ?? config.requestTimeoutMs);
  opts.signal?.addEventListener('abort', () => controller.abort('cancelled'));

  const headers: Record<string, string> = { Accept: 'application/json' };
  if (opts.body !== undefined) headers['Content-Type'] = 'application/json';
  if (!opts.anonymous) {
    const token = await sessionStore.getAccessToken();
    if (token) headers.Authorization = `Bearer ${token}`; // ASSUMED bearer scheme
  }
  if (opts.idempotencyKey && config.sendIdempotencyKey) headers['Idempotency-Key'] = opts.idempotencyKey;

  let res: Response;
  try {
    res = await (DEMO_MODE ? demoFetch : fetch)(`${config.apiBaseUrl}${path}`, {
      method: opts.method ?? route.method, headers,
      body: opts.formData ?? (opts.body !== undefined ? JSON.stringify(opts.body) : undefined),
      signal: controller.signal,
    });
  } catch (e) {
    if (controller.signal.reason === 'timeout') throw new ApiError('timeout', 'Request timed out.');
    if (controller.signal.reason === 'cancelled') throw new ApiError('unknown', 'Request cancelled.');
    connectivity.set(true);
    throw new ApiError('network', e instanceof Error ? e.message : 'Network error');
  } finally { clearTimeout(timer); }

  connectivity.set(false); // we reached the server (any HTTP status)

  if (res.ok) {
    if (res.status === 204) return undefined as T;
    const text = await res.text();
    if (!text) return undefined as T;
    try { return JSON.parse(text) as T; } catch { throw new ApiError('bad_response', 'The server sent a response the app could not read.', res.status); }
  }

  const detail = await res.json().catch(() => null) as { message?: unknown; code?: unknown; retryAfterSeconds?: unknown } | null;
  const message = typeof detail?.message === 'string' ? detail.message : `Request failed (${res.status}).`;
  const retryHeader = Number(res.headers.get('Retry-After'));
  const extra = {
    code: typeof detail?.code === 'string' ? detail.code : undefined,
    retryAfterSeconds: typeof detail?.retryAfterSeconds === 'number' ? detail.retryAfterSeconds : Number.isFinite(retryHeader) && retryHeader > 0 ? retryHeader : undefined,
  };
  const make = (kind: ApiErrorKind) => new ApiError(kind, message, res.status, undefined, extra);
  switch (res.status) {
    case 400: case 422: throw make('validation');
    case 401: if (!opts.anonymous) onUnauthorized?.(); throw make('unauthorized');
    case 403: throw make('forbidden');
    case 404: throw make('not_found');
    case 409: throw make('conflict');
    case 429: throw make('rate_limited');
    default: throw make(res.status >= 500 ? 'server' : 'unknown');
  }
}
