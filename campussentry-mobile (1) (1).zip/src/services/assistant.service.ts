import { apiRequest } from './api-client';
import { parseAssistantReply, type AssistantReply } from './parsers-ops.ts';

// The assistant acts with the signed-in staff member's own token. Consequential actions run only via `confirm`,
// triggered from a confirmation sheet. The server must enforce this too.
export const assistantService = {
  send: async (message: string, conversationId?: string, signal?: AbortSignal): Promise<AssistantReply> =>
    parseAssistantReply(await apiRequest<unknown>('assistantChat', { body: { message, conversationId }, signal, timeoutMs: 30000 })),
  confirm: async (proposalId: string, conversationId: string | undefined, idempotencyKey: string): Promise<AssistantReply> =>
    parseAssistantReply(await apiRequest<unknown>('assistantConfirm', { body: { proposalId, conversationId }, idempotencyKey, timeoutMs: 30000 })),
};
