import { apiRequest } from './api-client';
import { parseLogin, parseStaffUser, type LoginResult } from './parsers';
import type { StaffUser } from '../domain/types';

export const authService = {
  // PROPOSED body: staff ID or email + password. Confirm with backend.
  login: async (identifier: string, password: string): Promise<LoginResult> =>
    parseLogin(await apiRequest<unknown>('login', { body: { identifier: identifier.trim(), password }, anonymous: true })),
  fetchMe: async (): Promise<StaffUser> => parseStaffUser(await apiRequest<unknown>('me')),
  logoutRemote: async (): Promise<void> => { await apiRequest<void>('logout'); },
};
