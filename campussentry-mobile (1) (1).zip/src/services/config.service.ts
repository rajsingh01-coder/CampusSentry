import type { AppConfig } from '../domain/types';
import { apiRequest } from './api-client';
import { ApiError } from './errors';
import { ADMIN_DEFAULT_CONFIG, parseConfig } from './parsers';

export const configService = {
  /**
   * Categories, authorities and the OTP rule come from the server (the admin "System Settings"). If the config route is
   * unreachable or malformed we fall back to the admin defaults and mark `source: 'admin-defaults'`, so the UI can say so.
   * Auth failures are NOT swallowed.
   */
  get: async (signal?: AbortSignal): Promise<AppConfig> => {
    try { return parseConfig(await apiRequest<unknown>('config', { signal })); }
    catch (e) {
      if (e instanceof ApiError && (e.kind === 'unauthorized' || e.kind === 'forbidden')) throw e;
      return ADMIN_DEFAULT_CONFIG;
    }
  },
};
