import type { PhoneRule } from '../domain/validation';

const num = (v: string | undefined, d: number) => { const n = Number(v); return Number.isFinite(n) && v !== undefined && v !== '' ? n : d; };

export const config = {
  apiBaseUrl: (process.env.EXPO_PUBLIC_API_BASE_URL ?? '').replace(/\/+$/, ''),
  sendIdempotencyKey: process.env.EXPO_PUBLIC_SEND_IDEMPOTENCY_KEY === 'true',
  requestTimeoutMs: 15000,
  idleLogoutMinutes: num(process.env.EXPO_PUBLIC_IDLE_LOGOUT_MINUTES, 0),
  phoneRule: { minDigits: num(process.env.EXPO_PUBLIC_PHONE_MIN_DIGITS, 10), maxDigits: num(process.env.EXPO_PUBLIC_PHONE_MAX_DIGITS, 15) } satisfies PhoneRule,
};
