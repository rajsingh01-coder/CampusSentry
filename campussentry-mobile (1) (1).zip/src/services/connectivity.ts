// Tiny external store: the API client reports reachability, the OfflineBanner subscribes.
let offline = false;
const listeners = new Set<() => void>();
export const connectivity = {
  isOffline: () => offline,
  set(v: boolean) { if (v !== offline) { offline = v; listeners.forEach((l) => l()); } },
  subscribe(l: () => void) { listeners.add(l); return () => { listeners.delete(l); }; },
};
