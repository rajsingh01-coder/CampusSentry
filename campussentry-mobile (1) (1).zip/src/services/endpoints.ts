/**
 * BACKEND ROUTES: PROPOSED.
 * The Admin Web App is a frontend-only demo (localStorage + Zustand) and exposes no REST paths, so these routes are this
 * app's proposal. The backend partner can change any path here (one place) without touching screens.
 * `:name` is a path parameter. Request/response shapes are documented in docs/BACKEND_CONTRACT.md.
 */
export const ENDPOINTS = {
  login: { method: 'POST', path: '/api/auth/login' },
  logout: { method: 'POST', path: '/api/auth/logout' },
  me: { method: 'GET', path: '/api/me' },
  config: { method: 'GET', path: '/api/config' },
  dashboard: { method: 'GET', path: '/api/dashboard' },
  requestsList: { method: 'GET', path: '/api/requests' },
  requestCreate: { method: 'POST', path: '/api/requests' },
  requestDetail: { method: 'GET', path: '/api/requests/:requestId' },
  requestDecision: { method: 'POST', path: '/api/requests/:requestId/decision' },
  otpVerify: { method: 'POST', path: '/api/requests/:requestId/otp/verify' },
  otpResend: { method: 'POST', path: '/api/requests/:requestId/otp/resend' },
  visitorsList: { method: 'GET', path: '/api/visitors' },
  visitorDetail: { method: 'GET', path: '/api/visitors/:visitorId' },
  visitorCheckIn: { method: 'POST', path: '/api/visitors/:visitorId/check-in' },
  visitorCheckOut: { method: 'POST', path: '/api/visitors/:visitorId/check-out' },
  visitorHistory: { method: 'GET', path: '/api/visitors/:visitorId/history' },
  notificationsList: { method: 'GET', path: '/api/notifications' },
  notificationRead: { method: 'POST', path: '/api/notifications/:notificationId/read' },
  notificationsReadAll: { method: 'POST', path: '/api/notifications/read-all' },
  recognize: { method: 'POST', path: '/api/recognition' },
  assistantChat: { method: 'POST', path: '/api/assistant/chat' },
  assistantConfirm: { method: 'POST', path: '/api/assistant/confirm' },
} as const;

export type EndpointName = keyof typeof ENDPOINTS;

/** Demo mode runs an in-app fake backend (src/demo). A permanent banner is shown. Never enable for production. */
export const DEMO_MODE = process.env.EXPO_PUBLIC_DEMO_MODE === 'true';
