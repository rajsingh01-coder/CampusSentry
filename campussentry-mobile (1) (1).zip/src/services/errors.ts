export type ApiErrorKind =
  | 'contract_missing' // endpoint/response shape not provided by backend yet
  | 'network' | 'timeout' | 'unauthorized' | 'forbidden' | 'not_found'
  | 'conflict' | 'validation' | 'rate_limited' | 'server' | 'bad_response' | 'unknown';

export class ApiError extends Error {
  readonly kind: ApiErrorKind;
  readonly status?: number;
  readonly fieldErrors?: Record<string, string>;
  /** Machine-readable code from the response body, when the backend provides one (ASSUMED field: `code`). */
  readonly code?: string;
  readonly retryAfterSeconds?: number;
  constructor(kind: ApiErrorKind, message: string, status?: number, fieldErrors?: Record<string, string>, extra?: { code?: string; retryAfterSeconds?: number }) {
    super(message);
    this.name = 'ApiError';
    this.kind = kind;
    this.status = status;
    this.fieldErrors = fieldErrors;
    this.code = extra?.code;
    this.retryAfterSeconds = extra?.retryAfterSeconds;
  }
}

export function describeError(e: unknown): { title: string; detail: string; retryable: boolean } {
  if (!(e instanceof ApiError)) return { title: 'Something went wrong', detail: 'Try again. If it keeps happening, tell your supervisor.', retryable: true };
  switch (e.kind) {
    case 'contract_missing': return { title: 'Backend not connected', detail: e.message, retryable: false };
    case 'network': return { title: 'No connection', detail: 'Check the phone’s network and try again. Nothing was submitted.', retryable: true };
    case 'timeout': return { title: 'The server took too long', detail: 'The request may or may not have gone through. Check the record before trying again.', retryable: true };
    case 'unauthorized': return { title: 'Session expired', detail: 'Sign in again to continue.', retryable: false };
    case 'forbidden': return { title: 'Not permitted', detail: 'Your account is not allowed to do this.', retryable: false };
    case 'conflict': return { title: 'Record changed', detail: 'This record was updated elsewhere. Refresh it and check its current state.', retryable: true };
    case 'rate_limited': return { title: 'Too many attempts', detail: 'Wait a moment before trying again.', retryable: true };
    case 'validation': return { title: 'Check the details', detail: e.message, retryable: false };
    case 'server': return { title: 'Server problem', detail: 'The server returned an error. Try again shortly.', retryable: true };
    case 'bad_response': return { title: 'Unexpected response', detail: e.message, retryable: false };
    default: return { title: 'Request failed', detail: e.message, retryable: true };
  }
}
