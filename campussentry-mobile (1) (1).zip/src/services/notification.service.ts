import { apiRequest } from './api-client';
import { parseNotification, parsePage, type AppNotification, type Page } from './parsers-ops.ts';
import { PAGE_SIZE } from './requests.service';

// Mirrors the admin operations markAsRead / markAllAsRead. (Archive is an admin action and is not offered here.)
export const notificationService = {
  list: async (page: number, signal?: AbortSignal): Promise<Page<AppNotification>> =>
    parsePage(await apiRequest<unknown>('notificationsList', { query: { page, pageSize: PAGE_SIZE }, signal }), parseNotification, 'notification list'),
  markRead: async (notificationId: string): Promise<void> => { await apiRequest<unknown>('notificationRead', { params: { notificationId } }); },
  markAllRead: async (): Promise<void> => { await apiRequest<unknown>('notificationsReadAll'); },
};
