import {
  IDENTITY_CLASSIFICATIONS, OTP_STATUSES, PRESENCE_STATES, REQUEST_STATUSES, VISIT_MODES, VISITOR_CATEGORIES,
  type IdentityClassification, type NotificationPriority, type OtpStatus, type PresenceState, type RequestStatus, type VisitMode, type VisitorCategory,
} from '../domain/types.ts';
import { bad, bool, isObj, oneOf, str, strOr } from './parsers.ts';

/** Admin PaginatedResult: page-based. */
export interface Page<T> { data: T[]; total: number; page: number; pageSize: number; totalPages: number }
export function parsePage<T>(v: unknown, parseItem: (x: unknown) => T | null, what: string): Page<T> {
  if (!isObj(v) || !Array.isArray(v.data)) throw bad(what);
  const num = (x: unknown, d: number) => (typeof x === 'number' && Number.isFinite(x) ? x : d);
  const data = v.data.flatMap((x) => { const p = parseItem(x); return p ? [p] : []; }); // drop malformed rows, never invent
  const page = num(v.page, 1), pageSize = num(v.pageSize, data.length);
  return { data, total: num(v.total, data.length), page, pageSize, totalPages: num(v.totalPages, page) };
}
export const hasMorePages = (p: { page: number; totalPages: number }): boolean => p.page < p.totalPages;

const PRIORITIES: readonly NotificationPriority[] = ['Normal', 'High', 'Urgent'];

export interface RequestSummary {
  requestId: string; visitorId?: string; visitorName: string; visitorCategory: VisitorCategory; identityClassification: IdentityClassification;
  requestStatus: RequestStatus; otpStatus: OtpStatus; createdAt: string; personToMeet?: string; priority?: NotificationPriority;
}
export function parseRequestSummary(x: unknown): RequestSummary | null {
  if (!isObj(x)) return null;
  const requestId = str(x.requestId), visitorName = str(x.visitorName), createdAt = str(x.createdAt);
  const visitorCategory = oneOf(VISITOR_CATEGORIES, x.visitorCategory), requestStatus = oneOf(REQUEST_STATUSES, x.requestStatus);
  const identityClassification = oneOf(IDENTITY_CLASSIFICATIONS, x.identityClassification), otpStatus = oneOf(OTP_STATUSES, x.otpStatus);
  if (!requestId || !visitorName || !createdAt || !visitorCategory || !requestStatus || !identityClassification || !otpStatus) return null;
  return { requestId, visitorId: str(x.visitorId), visitorName, visitorCategory, identityClassification, requestStatus, otpStatus, createdAt, personToMeet: str(x.personToMeet), priority: oneOf(PRIORITIES, x.priority) };
}

export interface ReviewEntry { decision: string; by?: string; at?: string; notes?: string }
export interface RequestDetail extends RequestSummary {
  phoneNumber?: string; department?: string; reasonForMeeting: string; visitMode?: VisitMode; requestedDate?: string; requestedTime?: string;
  appointmentDetails?: string; gateOrLocation?: string; submittedBy?: string; staffNotes?: string; presence?: PresenceState;
  reviews: ReviewEntry[];
}
export function parseRequestDetail(v: unknown): RequestDetail {
  const base = parseRequestSummary(v);
  if (!base || !isObj(v)) throw bad('request detail');
  const reasonForMeeting = strOr(v.reasonForMeeting);
  if (reasonForMeeting === undefined) throw bad('request detail');
  const reviews = Array.isArray(v.reviews) ? v.reviews.flatMap((r): ReviewEntry[] => (isObj(r) && str(r.decision) ? [{ decision: r.decision as string, by: str(r.by), at: str(r.at), notes: str(r.notes) }] : [])) : [];
  return {
    ...base, reasonForMeeting, phoneNumber: str(v.phoneNumber), department: str(v.department), visitMode: oneOf(VISIT_MODES, v.visitMode),
    requestedDate: str(v.requestedDate), requestedTime: str(v.requestedTime), appointmentDetails: str(v.appointmentDetails),
    gateOrLocation: str(v.gateOrLocation), submittedBy: str(v.submittedBy), staffNotes: str(v.staffNotes), presence: oneOf(PRESENCE_STATES, v.presence), reviews,
  };
}

/** A person on record: one entry per visitor with the status of their latest request. Check-in/out use `visitorId`. */
export interface VisitorRecord {
  visitorId: string; visitorName: string; phoneNumber?: string; visitorCategory: VisitorCategory; identityClassification: IdentityClassification;
  latestRequestId?: string; requestStatus?: RequestStatus; presence?: PresenceState; lastActivityAt?: string;
}
export function parseVisitorRecord(x: unknown): VisitorRecord | null {
  if (!isObj(x)) return null;
  const visitorId = str(x.visitorId), visitorName = str(x.visitorName);
  const visitorCategory = oneOf(VISITOR_CATEGORIES, x.visitorCategory), identityClassification = oneOf(IDENTITY_CLASSIFICATIONS, x.identityClassification);
  if (!visitorId || !visitorName || !visitorCategory || !identityClassification) return null;
  return { visitorId, visitorName, visitorCategory, identityClassification, phoneNumber: str(x.phoneNumber), latestRequestId: str(x.latestRequestId), requestStatus: oneOf(REQUEST_STATUSES, x.requestStatus), presence: oneOf(PRESENCE_STATES, x.presence), lastActivityAt: str(x.lastActivityAt) };
}

export interface VisitorDetail extends VisitorRecord { requests: RequestSummary[] }
export function parseVisitorDetail(v: unknown): VisitorDetail {
  const base = parseVisitorRecord(v);
  if (!base || !isObj(v) || !Array.isArray(v.requests)) throw bad('visitor detail');
  return { ...base, requests: v.requests.flatMap((r) => { const p = parseRequestSummary(r); return p ? [p] : []; }) };
}

export interface HistoryEvent { id: string; kind: 'check_in' | 'check_out'; at: string; gate?: string; staffName?: string; source?: string }
export function parseHistoryEvent(x: unknown): HistoryEvent | null {
  if (!isObj(x)) return null;
  const id = str(x.id), at = str(x.at);
  const kind = x.kind === 'check_in' || x.kind === 'check_out' ? x.kind : undefined;
  return id && at && kind ? { id, kind, at, gate: str(x.gate), staffName: str(x.staffName), source: str(x.source) } : null;
}

/** Mirrors the admin StaffNotification. */
export interface AppNotification {
  id: string; requestId: string; visitorName: string; visitorCategory?: VisitorCategory; identityClassification?: IdentityClassification;
  personToMeet?: string; reasonForMeeting?: string; requestStatus?: RequestStatus; otpStatus?: OtpStatus; priority: NotificationPriority; createdAt: string; isRead: boolean;
}
export function parseNotification(x: unknown): AppNotification | null {
  if (!isObj(x)) return null;
  const id = str(x.id), requestId = str(x.requestId), visitorName = str(x.visitorName), createdAt = str(x.createdAt), isRead = bool(x.isRead);
  if (!id || !requestId || !visitorName || !createdAt || isRead === undefined) return null;
  return {
    id, requestId, visitorName, createdAt, isRead, priority: oneOf(PRIORITIES, x.priority) ?? 'Normal',
    visitorCategory: oneOf(VISITOR_CATEGORIES, x.visitorCategory), identityClassification: oneOf(IDENTITY_CLASSIFICATIONS, x.identityClassification),
    personToMeet: str(x.personToMeet), reasonForMeeting: str(x.reasonForMeeting), requestStatus: oneOf(REQUEST_STATUSES, x.requestStatus), otpStatus: oneOf(OTP_STATUSES, x.otpStatus),
  };
}

export interface Recognition {
  classification: IdentityClassification; sessionId?: string;
  /** Only fields the backend chose to send. Nothing is derived or invented client-side. */
  match?: { visitorId?: string; name?: string; photoUrl?: string; confidence?: number };
}
export function parseRecognition(v: unknown): Recognition {
  if (!isObj(v)) throw bad('recognition');
  const classification = oneOf(IDENTITY_CLASSIFICATIONS, v.classification);
  if (!classification) throw bad('recognition');
  let match: Recognition['match'];
  if (isObj(v.match)) {
    const m = v.match;
    match = { visitorId: str(m.visitorId), name: str(m.name), photoUrl: str(m.photoUrl), confidence: typeof m.confidence === 'number' ? m.confidence : undefined };
  }
  return { classification, sessionId: str(v.sessionId), match };
}

export interface AssistantReply { conversationId?: string; reply: string; proposal?: { id: string; title: string; description: string } }
export function parseAssistantReply(v: unknown): AssistantReply {
  if (!isObj(v)) throw bad('assistant reply');
  const reply = strOr(v.reply);
  if (reply === undefined) throw bad('assistant reply');
  let proposal: AssistantReply['proposal'];
  if (isObj(v.proposal)) {
    const id = str(v.proposal.id), title = str(v.proposal.title);
    if (id && title) proposal = { id, title, description: strOr(v.proposal.description) ?? '' };
  }
  return { conversationId: str(v.conversationId), reply, proposal };
}
