import {
  ADMIN_DEFAULT_AUTHORITIES, ADMIN_DEFAULT_REQUIRE_OTP_FOR_GUESTS, REQUEST_STATUSES, STAFF_ROLES, VISITOR_CATEGORIES,
  type AppConfig, type OtpStatus, type Permission, type RequestStatus, type StaffUser,
} from '../domain/types.ts';
import { ROLE_DEFAULT_PERMISSIONS } from '../domain/role-permissions.ts';
import { ApiError } from './errors.ts';

// Hand-written validators: backend responses are untrusted until proven otherwise. Nothing is ever invented.
export const bad = (what: string) => new ApiError('bad_response', `Response did not match the expected ${what} shape. Compare it with docs/BACKEND_CONTRACT.md.`);
export const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v);
export const str = (v: unknown) => (typeof v === 'string' && v !== '' ? v : undefined);
export const strOr = (v: unknown) => (typeof v === 'string' ? v : undefined);
export const bool = (v: unknown): boolean | undefined => (typeof v === 'boolean' ? v : undefined);
export const nonNegInt = (v: unknown) => (typeof v === 'number' && Number.isInteger(v) && v >= 0 ? v : undefined);
export const oneOf = <T extends string>(list: readonly T[], v: unknown): T | undefined => list.find((x) => x === v);
const PERMISSIONS: readonly Permission[] = ['request.create', 'request.review', 'visitor.checkin', 'visitor.checkout', 'visitor.search_phone', 'history.view'];

export function parseStaffUser(v: unknown): StaffUser {
  if (!isObj(v)) throw bad('staff user');
  const staffId = str(v.staffId), name = str(v.name), role = oneOf(STAFF_ROLES, v.role);
  if (!staffId || !name || !role) throw bad('staff user');
  const explicit = Array.isArray(v.permissions);
  const permissions = explicit ? (v.permissions as unknown[]).flatMap((p) => { const x = oneOf(PERMISSIONS, p); return x ? [x] : []; }) : ROLE_DEFAULT_PERMISSIONS[role];
  return { staffId, name, role, email: str(v.email), department: str(v.department), assignedGate: str(v.assignedGate), permissions, permissionSource: explicit ? 'server' : 'role-default' };
}

export interface LoginResult { accessToken: string; refreshToken?: string; user: StaffUser }
export function parseLogin(v: unknown): LoginResult {
  if (!isObj(v)) throw bad('login');
  const accessToken = str(v.accessToken);
  if (!accessToken) throw bad('login');
  return { accessToken, refreshToken: str(v.refreshToken), user: parseStaffUser(v.user) };
}

const strList = (v: unknown): string[] => (Array.isArray(v) ? v.flatMap((x) => (str(x) ? [x as string] : [])) : []);

/** Parses the server configuration; every missing part falls back to the admin defaults and `source` says so. */
export function parseConfig(v: unknown): AppConfig {
  if (!isObj(v)) throw bad('config');
  const cats = strList(v.visitorCategories), auth = strList(v.authorizedMeetingAuthorities);
  return {
    visitorCategories: cats.length ? cats : [...VISITOR_CATEGORIES],
    authorizedMeetingAuthorities: auth.length ? auth : [...ADMIN_DEFAULT_AUTHORITIES],
    requireOtpForGuests: bool(v.requireOtpForGuests) ?? ADMIN_DEFAULT_REQUIRE_OTP_FOR_GUESTS,
    gates: strList(v.gates),
    source: 'server',
  };
}
export const ADMIN_DEFAULT_CONFIG: AppConfig = {
  visitorCategories: [...VISITOR_CATEGORIES], authorizedMeetingAuthorities: [...ADMIN_DEFAULT_AUTHORITIES],
  requireOtpForGuests: ADMIN_DEFAULT_REQUIRE_OTP_FOR_GUESTS, gates: [], source: 'admin-defaults',
};

export interface ActivityEntry { id: string; visitorName: string; kind: 'check_in' | 'check_out' | 'registered' | 'status_changed'; at: string; status?: RequestStatus }
export interface DashboardSummary { totalToday: number; insideNow: number; pendingApproval: number; recent: ActivityEntry[] }
export function parseDashboard(v: unknown): DashboardSummary {
  if (!isObj(v)) throw bad('dashboard');
  const totalToday = nonNegInt(v.totalToday), insideNow = nonNegInt(v.insideNow), pendingApproval = nonNegInt(v.pendingApproval);
  if (totalToday === undefined || insideNow === undefined || pendingApproval === undefined || !Array.isArray(v.recent)) throw bad('dashboard');
  const kinds = ['check_in', 'check_out', 'registered', 'status_changed'];
  const recent = v.recent.flatMap((r): ActivityEntry[] => {
    if (!isObj(r)) return [];
    const id = str(r.id), visitorName = str(r.visitorName), at = str(r.at), kind = str(r.kind);
    if (!id || !visitorName || !at || !kind || !kinds.includes(kind)) return [];
    return [{ id, visitorName, at, kind: kind as ActivityEntry['kind'], status: oneOf(REQUEST_STATUSES, r.requestStatus) }];
  });
  return { totalToday, insideNow, pendingApproval, recent };
}

export interface CreatedRequest { requestId: string; visitorId?: string; requestStatus: RequestStatus; otpStatus: OtpStatus }
export function parseCreatedRequest(v: unknown): CreatedRequest {
  if (!isObj(v)) throw bad('created request');
  const requestId = str(v.requestId), requestStatus = oneOf(REQUEST_STATUSES, v.requestStatus);
  const otpStatus = oneOf(['Verified', 'Pending', 'Failed', 'Not Applicable'] as const, v.otpStatus);
  if (!requestId || !requestStatus || !otpStatus) throw bad('created request'); // never show success without a backend-issued ID
  return { requestId, visitorId: str(v.visitorId), requestStatus, otpStatus };
}
