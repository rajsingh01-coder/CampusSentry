import { ApiError } from './errors.ts';

export type Query = Record<string, string | number | undefined | null>;

/** Fills `:name` placeholders (URL-encoded) and appends non-empty query params. */
export function buildPath(template: string, params: Record<string, string> = {}, query: Query = {}): string {
  let path = template.replace(/:([A-Za-z_]\w*)/g, (_m, key: string) => {
    const v = params[key];
    if (v === undefined) throw new ApiError('contract_missing', `Missing path parameter "${key}" for ${template}.`);
    return encodeURIComponent(v);
  });
  const qs = Object.entries(query)
    .filter((e): e is [string, string | number] => e[1] !== undefined && e[1] !== null && e[1] !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join('&');
  if (qs) path += (path.includes('?') ? '&' : '?') + qs;
  return path;
}
