import { apiRequest } from './api-client';
import { parseRecognition, type Recognition } from './parsers-ops.ts';

// Captured photos are biometric data. Delete the cache file as soon as the upload settles (success OR failure).
// expo-file-system moved `deleteAsync` to a "legacy" entry point in newer SDKs, so try both.
async function discardCapture(uri: string): Promise<void> {
  try { const m = await import('expo-file-system/legacy'); await m.deleteAsync(uri, { idempotent: true }); return; } catch { /* try next */ }
  try {
    const m = (await import('expo-file-system')) as unknown as { deleteAsync?: (u: string, o?: { idempotent?: boolean }) => Promise<void> };
    await m.deleteAsync?.(uri, { idempotent: true });
  } catch { /* nothing else we can do; documented in README */ }
}

export const recognitionService = {
  /** Uploads the capture to the recognition API and always deletes the local file afterwards. */
  recognize: async (photoUri: string, signal?: AbortSignal): Promise<Recognition> => {
    try {
      const form = new FormData();
      form.append('image', { uri: photoUri, name: 'capture.jpg', type: 'image/jpeg' } as unknown as Blob); // PROPOSED field name: image
      return parseRecognition(await apiRequest<unknown>('recognize', { formData: form, timeoutMs: 30000, signal }));
    } finally { await discardCapture(photoUri); }
  },
};
