import type { IdentityClassification, RequestStatus } from '../domain/types.ts';
import { normalizePhone, type RegistrationInput } from '../domain/validation.ts';
import type { RequestDecision } from '../domain/workflow.ts';
import { apiRequest } from './api-client';
import { ApiError } from './errors';
import { isObj, parseCreatedRequest, type CreatedRequest } from './parsers.ts';
import { parsePage, parseRequestDetail, parseRequestSummary, type Page, type RequestDetail, type RequestSummary } from './parsers-ops.ts';

export const PAGE_SIZE = 20;

export const requestsService = {
  // PROPOSED query: status, q, page, pageSize
  list: async (f: { status: RequestStatus | null; query: string; classification?: IdentityClassification | null }, page: number, signal?: AbortSignal): Promise<Page<RequestSummary>> =>
    parsePage(await apiRequest<unknown>('requestsList', { query: { status: f.status ?? undefined, q: f.query.trim() || undefined, classification: f.classification ?? undefined, page, pageSize: PAGE_SIZE }, signal }), parseRequestSummary, 'request list'),
  detail: async (requestId: string, signal?: AbortSignal): Promise<RequestDetail> => parseRequestDetail(await apiRequest<unknown>('requestDetail', { params: { requestId }, signal })),

  /** Body mirrors the admin SimulateRequestInput. The backend issues the requestId, status and OTP status. */
  create: async (input: RegistrationInput, staff: { staffId: string }, idempotencyKey: string): Promise<CreatedRequest> => {
    const walkIn = input.visitMode === 'Walk-in';
    const trim = (s: string) => s.trim() || undefined;
    return parseCreatedRequest(await apiRequest<unknown>('requestCreate', {
      idempotencyKey,
      body: {
        visitorName: input.fullName.trim(), phoneNumber: input.phone.trim() ? normalizePhone(input.phone) : undefined,
        visitorCategory: input.category, identityClassification: input.classification, personToMeet: input.personToMeet.trim(), department: trim(input.department),
        reasonForMeeting: input.reason.trim(), visitMode: input.visitMode, requestedDate: walkIn ? undefined : input.requestedDate, requestedTime: walkIn ? 'Now' : input.requestedTime,
        appointmentDetails: trim(input.appointmentDetails), submittingStaffId: staff.staffId, gateOrLocation: input.gate.trim(), staffNotes: trim(input.staffNotes),
      },
    }));
  },

  // For mutations a 2xx is the backend's confirmation. Callers re-fetch afterwards: the server decides the resulting state.
  decide: async (requestId: string, decision: RequestDecision, notes: string | undefined, idempotencyKey: string): Promise<void> => {
    await apiRequest<unknown>('requestDecision', { params: { requestId }, body: { decision, notes: notes?.trim() || undefined }, idempotencyKey });
  },

  /** Resolves only when the backend says `{ verified: true }`. Anything else throws. */
  verifyOtp: async (requestId: string, code: string): Promise<void> => {
    const res = await apiRequest<unknown>('otpVerify', { params: { requestId }, body: { code } });
    if (!(isObj(res) && res.verified === true)) throw new ApiError('bad_response', 'The server did not confirm the OTP. Check the code and try again.');
  },
  resendOtp: async (requestId: string): Promise<void> => { await apiRequest<unknown>('otpResend', { params: { requestId } }); },
};
