import * as SecureStore from 'expo-secure-store';
import type { StaffUser } from '../domain/types';

// Tokens and the profile snapshot live in SecureStore only (never AsyncStorage), under separate keys (value size limits).
const K = { access: 'cs.access', refresh: 'cs.refresh', user: 'cs.user' } as const;
export interface StoredSession { accessToken: string; refreshToken?: string; user: StaffUser }

export const sessionStore = {
  async save(s: StoredSession): Promise<void> {
    await SecureStore.setItemAsync(K.access, s.accessToken);
    if (s.refreshToken) await SecureStore.setItemAsync(K.refresh, s.refreshToken);
    else await SecureStore.deleteItemAsync(K.refresh);
    await SecureStore.setItemAsync(K.user, JSON.stringify(s.user));
  },
  async load(): Promise<StoredSession | null> {
    try {
      const [accessToken, refreshToken, userJson] = await Promise.all([SecureStore.getItemAsync(K.access), SecureStore.getItemAsync(K.refresh), SecureStore.getItemAsync(K.user)]);
      if (!accessToken || !userJson) return null;
      return { accessToken, refreshToken: refreshToken ?? undefined, user: JSON.parse(userJson) as StaffUser };
    } catch { return null; }
  },
  async clear(): Promise<void> { await Promise.all(Object.values(K).map((k) => SecureStore.deleteItemAsync(k).catch(() => undefined))); },
  async getAccessToken(): Promise<string | null> { try { return await SecureStore.getItemAsync(K.access); } catch { return null; } },
};
