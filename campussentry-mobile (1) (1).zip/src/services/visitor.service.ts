import type { RecordFilters } from '../domain/records-filters.ts';
import { periodToQuery } from '../domain/workflow.ts';
import { apiRequest } from './api-client';
import { parseDashboard, type DashboardSummary } from './parsers';
import { parseHistoryEvent, parsePage, parseVisitorDetail, parseVisitorRecord, type HistoryEvent, type Page, type VisitorDetail, type VisitorRecord } from './parsers-ops.ts';
import { PAGE_SIZE } from './requests.service';

export const visitorService = {
  getDashboard: async (signal?: AbortSignal): Promise<DashboardSummary> => parseDashboard(await apiRequest<unknown>('dashboard', { signal })),

  // PROPOSED query: q, field, category, classification, status, presence, from, to, page, pageSize
  search: async (f: RecordFilters, page: number, signal?: AbortSignal): Promise<Page<VisitorRecord>> => {
    const { from, to } = periodToQuery(f.period);
    const q = f.query.trim();
    return parsePage(await apiRequest<unknown>('visitorsList', {
      query: { q: q || undefined, field: q ? f.field : undefined, category: f.category ?? undefined, classification: f.classification ?? undefined, status: f.status ?? undefined, presence: f.presence ?? undefined, from, to, page, pageSize: PAGE_SIZE },
      signal,
    }), parseVisitorRecord, 'visitor search');
  },
  detail: async (visitorId: string, signal?: AbortSignal): Promise<VisitorDetail> => parseVisitorDetail(await apiRequest<unknown>('visitorDetail', { params: { visitorId }, signal })),
  history: async (visitorId: string, page: number, signal?: AbortSignal): Promise<Page<HistoryEvent>> =>
    parsePage(await apiRequest<unknown>('visitorHistory', { params: { visitorId }, query: { page, pageSize: PAGE_SIZE }, signal }), parseHistoryEvent, 'visitor history'),

  // Admin keys these by visitorId and records the gate. The 2xx is the confirmation; callers re-fetch the visitor afterwards.
  checkIn: async (visitorId: string, gate: string, idempotencyKey: string): Promise<void> => { await apiRequest<unknown>('visitorCheckIn', { params: { visitorId }, body: { gate: gate.trim() }, idempotencyKey }); },
  checkOut: async (visitorId: string, gate: string, idempotencyKey: string): Promise<void> => { await apiRequest<unknown>('visitorCheckOut', { params: { visitorId }, body: { gate: gate.trim() }, idempotencyKey }); },
};
