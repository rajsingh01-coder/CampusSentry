import AsyncStorage from '@react-native-async-storage/async-storage';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useColorScheme } from 'react-native';
import { darkPalette, lightPalette, type Palette } from './colors';

export type ThemePreference = 'light' | 'dark' | 'system';
const KEY = 'cs.theme.preference'; // not sensitive, so plain storage is fine

interface ThemeCtx { colors: Palette; scheme: 'light' | 'dark'; preference: ThemePreference; ready: boolean; setPreference: (p: ThemePreference) => void }
const Ctx = createContext<ThemeCtx | null>(null);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const system = useColorScheme();
  const [preference, setPref] = useState<ThemePreference>('system');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY)
      .then((v) => { if (v === 'light' || v === 'dark' || v === 'system') setPref(v); })
      .catch(() => undefined)
      .finally(() => setReady(true));
  }, []);

  const setPreference = useCallback((p: ThemePreference) => { setPref(p); AsyncStorage.setItem(KEY, p).catch(() => undefined); }, []);
  const scheme: 'light' | 'dark' = preference === 'system' ? (system === 'dark' ? 'dark' : 'light') : preference;
  const value = useMemo<ThemeCtx>(() => ({ colors: scheme === 'dark' ? darkPalette : lightPalette, scheme, preference, ready, setPreference }), [scheme, preference, ready, setPreference]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTheme(): ThemeCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error('useTheme must be used inside ThemeProvider');
  return v;
}
