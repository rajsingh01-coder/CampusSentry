export interface Palette {
  navy: string; primary: string; accent: string;
  background: string; surface: string; surfaceAlt: string; elevated: string;
  text: string; textSecondary: string; border: string; onPrimary: string; danger: string;
  status: Record<'success' | 'warning' | 'critical' | 'info' | 'neutral', { fg: string; bg: string; solid: string }>;
  /** status + admin category hues (indigo, purple, teal) */
  tones: Record<'success' | 'warning' | 'critical' | 'info' | 'neutral' | 'indigo' | 'purple' | 'teal', { fg: string; bg: string }>;
}

// Base values come from the supplied brand spec. Status `fg` shades are darker/lighter variants chosen for text
// contrast (raw status colors fail WCAG AA as small text on white). Base tokens match the Admin Web App (globals.css).
export const lightPalette: Palette = {
  navy: '#0B1528', primary: '#2563EB', accent: '#0D9488',
  background: '#F8FAFC', surface: '#FFFFFF', surfaceAlt: '#F1F5F9', elevated: '#FFFFFF',
  text: '#0F172A', textSecondary: '#64748B', border: '#E2E8F0', onPrimary: '#FFFFFF', danger: '#E11D48',
  status: {
    success: { fg: '#15803D', bg: '#DCFCE7', solid: '#16A34A' },
    warning: { fg: '#B45309', bg: '#FEF3C7', solid: '#D97706' },
    critical: { fg: '#BE123C', bg: '#FFE4E6', solid: '#E11D48' },
    info: { fg: '#1D4ED8', bg: '#DBEAFE', solid: '#2563EB' },
    neutral: { fg: '#475569', bg: '#F1F5F9', solid: '#64748B' },
  },
  tones: {
    success: { fg: '#15803D', bg: '#DCFCE7' }, warning: { fg: '#B45309', bg: '#FEF3C7' }, critical: { fg: '#BE123C', bg: '#FFE4E6' }, info: { fg: '#1D4ED8', bg: '#DBEAFE' }, neutral: { fg: '#475569', bg: '#F1F5F9' },
    indigo: { fg: '#4338CA', bg: '#E0E7FF' }, purple: { fg: '#7E22CE', bg: '#F3E8FF' }, teal: { fg: '#0F766E', bg: '#CCFBF1' },
  },
};

export const darkPalette: Palette = {
  navy: '#0B1528', primary: '#60A5FA', accent: '#2DD4BF',
  background: '#0B1220', surface: '#111C2E', surfaceAlt: '#172338', elevated: '#172338',
  text: '#F8FAFC', textSecondary: '#94A3B8', border: '#263449', onPrimary: '#0B1220', danger: '#FB7185',
  status: {
    success: { fg: '#4ADE80', bg: '#12301E', solid: '#16A34A' },
    warning: { fg: '#FBBF24', bg: '#33260A', solid: '#D97706' },
    critical: { fg: '#FB7185', bg: '#3A1420', solid: '#E11D48' },
    info: { fg: '#93C5FD', bg: '#13294B', solid: '#2563EB' },
    neutral: { fg: '#CBD5E1', bg: '#1E2B42', solid: '#94A3B8' },
  },
  tones: {
    success: { fg: '#4ADE80', bg: '#12301E' }, warning: { fg: '#FBBF24', bg: '#33260A' }, critical: { fg: '#FB7185', bg: '#3A1420' }, info: { fg: '#93C5FD', bg: '#13294B' }, neutral: { fg: '#CBD5E1', bg: '#1E2B42' },
    indigo: { fg: '#A5B4FC', bg: '#222A5C' }, purple: { fg: '#D8B4FE', bg: '#3B1F5C' }, teal: { fg: '#5EEAD4', bg: '#0F3B38' },
  },
};
