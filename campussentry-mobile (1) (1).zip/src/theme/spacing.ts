export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;
export const radius = { sm: 8, md: 10, lg: 16, pill: 999 } as const; // admin: control 10, card 16
export const MIN_TOUCH = 48;
