// System font only (per brief). Sizes follow the spec.
export const type = {
  screenTitle: { fontSize: 28, fontWeight: '700' as const, letterSpacing: -0.3 },
  sectionTitle: { fontSize: 20, fontWeight: '600' as const },
  cardTitle: { fontSize: 17, fontWeight: '600' as const },
  body: { fontSize: 16, fontWeight: '400' as const },
  support: { fontSize: 14, fontWeight: '400' as const },
  metric: { fontSize: 32, fontWeight: '700' as const, letterSpacing: -0.5 },
  button: { fontSize: 16, fontWeight: '600' as const },
};
