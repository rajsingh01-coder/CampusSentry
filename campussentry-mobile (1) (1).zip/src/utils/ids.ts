/** Client-generated key for a single logical action. Reused on retry, regenerated for a new action. */
export const newKey = (): string => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;

export function formatDateTime(iso?: string): string {
  if (!iso) return '–';
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
}
