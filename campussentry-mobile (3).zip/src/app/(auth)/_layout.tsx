import { Redirect, Stack } from 'expo-router';
import { useAuth } from '../../features/auth/AuthProvider';

export default function AuthLayout() {
  const { status } = useAuth();
  if (status === 'signedIn') return <Redirect href="/(tabs)" />;
  return <Stack screenOptions={{ headerShown: false }} />;
}
