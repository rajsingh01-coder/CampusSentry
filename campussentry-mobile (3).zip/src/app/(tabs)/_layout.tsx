import { Ionicons } from '@expo/vector-icons';
import { Redirect, Tabs } from 'expo-router';
import React from 'react';
import { useAuth } from '../../features/auth/AuthProvider';
import { useTheme } from '../../theme/ThemeProvider';

type Icon = React.ComponentProps<typeof Ionicons>['name'];
const tab = (title: string, icon: Icon, focusedIcon: Icon) => ({
  title,
  tabBarIcon: ({ color, size, focused }: { color: string; size: number; focused: boolean }) => <Ionicons name={focused ? focusedIcon : icon} size={size} color={color} />,
});

export default function TabsLayout() {
  const { colors } = useTheme();
  const { user } = useAuth();
  if (!user) return null; // signed out (e.g. session expired): render nothing while the gate redirects to login
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.primary, tabBarInactiveTintColor: colors.textSecondary, tabBarStyle: { backgroundColor: colors.surface, borderTopColor: colors.border }, tabBarLabelStyle: { fontSize: 12 } }}>
      <Tabs.Screen name="index" options={tab('Home', 'home-outline', 'home')} />
      <Tabs.Screen name="identify" options={tab('Identify', 'scan-outline', 'scan')} />
      <Tabs.Screen name="register" options={tab('Register', 'person-add-outline', 'person-add')} />
      <Tabs.Screen name="records" options={tab('Records', 'document-text-outline', 'document-text')} />
      <Tabs.Screen name="profile" options={tab('Profile', 'person-circle-outline', 'person-circle')} />
    </Tabs>
  );
}
