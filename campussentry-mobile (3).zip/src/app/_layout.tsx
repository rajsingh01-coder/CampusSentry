import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { DemoBanner } from '../components/ui/DemoBanner';
import { OfflineBanner } from '../components/ui/OfflineBanner';
import { TypingIntro } from '../components/ui/TypingIntro';
import { AuthProvider, useAuth } from '../features/auth/AuthProvider';
import { ConfigProvider } from '../features/config/ConfigProvider';
import { ThemeProvider, useTheme } from '../theme/ThemeProvider';

void SplashScreen.preventAutoHideAsync().catch(() => undefined);

function Gate() {
  const { status } = useAuth();
  const { colors, scheme, ready } = useTheme();
  const segments = useSegments();
  const router = useRouter();
  const [introDone, setIntroDone] = useState(false);

  // Hide the native splash as soon as the saved theme is known (no light/dark flash). The typing intro then covers the session check.
  useEffect(() => { if (ready) void SplashScreen.hideAsync().catch(() => undefined); }, [ready]);
  const appVisible = introDone && status !== 'loading';
  useEffect(() => {
    if (!appVisible) return;
    const inAuth = segments[0] === '(auth)';
    if (status === 'signedOut' && !inAuth) router.replace('/(auth)/login');
    else if (status === 'signedIn' && inAuth) router.replace('/(tabs)');
  }, [appVisible, status, segments, router]);

  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.background }} />;
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar style={scheme === 'dark' ? 'light' : 'dark'} />
      {appVisible ? (
        <>
          <DemoBanner />
          <OfflineBanner />
          <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.background } }} />
        </>
      ) : null}
      {!introDone ? <TypingIntro onDone={() => setIntroDone(true)} /> : null}
    </View>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <AuthProvider>
          <ConfigProvider>
            <Gate />
          </ConfigProvider>
        </AuthProvider>
      </ThemeProvider>
    </SafeAreaProvider>
  );
}
