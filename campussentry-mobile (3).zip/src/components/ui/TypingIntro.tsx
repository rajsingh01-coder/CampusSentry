import React, { useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { spacing } from '../../theme/spacing';
import { useTheme } from '../../theme/ThemeProvider';
import { BrandMark } from './BrandMark';

const TITLE = 'CampusSentry';
const SUBTITLE = 'Campus operations';
const PAUSE_TICKS = 5; // short beat between the two lines
const TICK_MS = 65;
const HOLD_MS = 700;
const TOTAL = TITLE.length + PAUSE_TICKS + SUBTITLE.length;

/** Pure helper (kept simple so it is easy to test): which text is visible after `n` ticks. */
export function typedLines(n: number): { title: string; subtitle: string; activeLine: 0 | 1 } {
  if (n <= TITLE.length) return { title: TITLE.slice(0, n), subtitle: '', activeLine: 0 };
  const m = n - TITLE.length - PAUSE_TICKS;
  return { title: TITLE, subtitle: m > 0 ? SUBTITLE.slice(0, m) : '', activeLine: m > 0 ? 1 : 0 };
}

/**
 * Typewriter intro shown once at app launch (also covers the session check, so there is no blank screen).
 * Tap to skip. Respects the system "reduce motion" setting by showing the final text without typing.
 */
export function TypingIntro({ onDone }: { onDone: () => void }) {
  const { colors } = useTheme();
  const [n, setN] = useState(0);
  const [cursorOn, setCursorOn] = useState(true);
  const fade = useRef(new Animated.Value(1)).current;
  const logo = useRef(new Animated.Value(0)).current;
  const finished = useRef(false);

  const finish = React.useCallback(() => {
    if (finished.current) return;
    finished.current = true;
    Animated.timing(fade, { toValue: 0, duration: 250, useNativeDriver: true }).start(() => onDone());
  }, [fade, onDone]);

  useEffect(() => { Animated.timing(logo, { toValue: 1, duration: 450, useNativeDriver: true }).start(); }, [logo]);

  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const tick = (i: number) => {
      if (cancelled) return;
      setN(i);
      if (i >= TOTAL) { timer = setTimeout(finish, HOLD_MS); return; }
      timer = setTimeout(() => tick(i + 1), TICK_MS);
    };
    AccessibilityInfo.isReduceMotionEnabled().then((reduce: boolean) => {
      if (cancelled) return;
      if (reduce) { setN(TOTAL); timer = setTimeout(finish, 500); } else tick(1);
    }).catch(() => { if (!cancelled) tick(1); });
    return () => { cancelled = true; if (timer) clearTimeout(timer); };
  }, [finish]);

  useEffect(() => { const id = setInterval(() => setCursorOn((c) => !c), 480); return () => clearInterval(id); }, []);

  const { title, subtitle, activeLine } = typedLines(n);
  const cursor = (line: 0 | 1) => (activeLine === line && cursorOn ? '▍' : ' ');
  return (
    <Animated.View style={[StyleSheet.absoluteFill, styles.wrap, { backgroundColor: colors.background, opacity: fade }]}>
      <Pressable style={styles.center} onPress={finish} accessibilityRole="button" accessibilityLabel="CampusSentry, Campus operations. Tap to skip the intro.">
        <Animated.View style={{ opacity: logo, transform: [{ scale: logo.interpolate({ inputRange: [0, 1], outputRange: [0.85, 1] }) }] }}>
          <BrandMark size={72} showText={false} />
        </Animated.View>
        <View style={styles.texts} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
          <Text style={[styles.title, { color: colors.text }]}>{title}<Text style={{ color: colors.primary }}>{cursor(0)}</Text></Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>{subtitle}<Text style={{ color: colors.primary }}>{cursor(1)}</Text></Text>
        </View>
      </Pressable>
    </Animated.View>
  );
}
const styles = StyleSheet.create({
  wrap: { zIndex: 10 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: spacing.xl },
  texts: { alignItems: 'center', gap: spacing.xs, minHeight: 80 },
  title: { fontSize: 34, fontWeight: '700', letterSpacing: -0.5, fontVariant: ['tabular-nums'] },
  subtitle: { fontSize: 18, fontWeight: '400' },
});
